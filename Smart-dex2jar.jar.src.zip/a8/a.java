package a8;

import java.util.Date;

public interface a {
  void a(Long paramLong);
  
  int b();
  
  void c(Date paramDate);
  
  void d(int paramInt1, int paramInt2, int paramInt3);
  
  Date e();
  
  String f();
  
  int g();
  
  int h();
  
  long i();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a8\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */