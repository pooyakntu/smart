package android.support.v4.media.session;

import android.media.session.PlaybackState;
import android.os.Bundle;

class i {
  public static Bundle a(Object paramObject) {
    return h.a((PlaybackState)paramObject);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\android\support\v4\media\session\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */