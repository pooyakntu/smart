package android.support.v4.media.session;

import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class PlaybackStateCompat implements Parcelable {
  public static final Parcelable.Creator<PlaybackStateCompat> CREATOR = new a();
  
  final int g;
  
  final long h;
  
  final long i;
  
  final float j;
  
  final long k;
  
  final int l;
  
  final CharSequence m;
  
  final long n;
  
  List<CustomAction> o;
  
  final long p;
  
  final Bundle q;
  
  private Object r;
  
  PlaybackStateCompat(int paramInt1, long paramLong1, long paramLong2, float paramFloat, long paramLong3, int paramInt2, CharSequence paramCharSequence, long paramLong4, List<CustomAction> paramList, long paramLong5, Bundle paramBundle) {
    this.g = paramInt1;
    this.h = paramLong1;
    this.i = paramLong2;
    this.j = paramFloat;
    this.k = paramLong3;
    this.l = paramInt2;
    this.m = paramCharSequence;
    this.n = paramLong4;
    this.o = new ArrayList<CustomAction>(paramList);
    this.p = paramLong5;
    this.q = paramBundle;
  }
  
  PlaybackStateCompat(Parcel paramParcel) {
    this.g = paramParcel.readInt();
    this.h = paramParcel.readLong();
    this.j = paramParcel.readFloat();
    this.n = paramParcel.readLong();
    this.i = paramParcel.readLong();
    this.k = paramParcel.readLong();
    this.m = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.o = paramParcel.createTypedArrayList(CustomAction.CREATOR);
    this.p = paramParcel.readLong();
    this.q = paramParcel.readBundle(MediaSessionCompat.class.getClassLoader());
    this.l = paramParcel.readInt();
  }
  
  public static PlaybackStateCompat a(Object paramObject) {
    PlaybackStateCompat playbackStateCompat;
    ArrayList<CustomAction> arrayList = null;
    Bundle bundle = null;
    if (paramObject != null) {
      List<Object> list = g.d(paramObject);
      if (list != null) {
        arrayList = new ArrayList(list.size());
        Iterator iterator = list.iterator();
        while (iterator.hasNext())
          arrayList.add(CustomAction.a(iterator.next())); 
      } else {
        arrayList = null;
      } 
      if (Build.VERSION.SDK_INT >= 22)
        bundle = i.a(paramObject); 
      playbackStateCompat = new PlaybackStateCompat(g.i(paramObject), g.h(paramObject), g.c(paramObject), g.g(paramObject), g.a(paramObject), 0, g.e(paramObject), g.f(paramObject), arrayList, g.b(paramObject), bundle);
      playbackStateCompat.r = paramObject;
    } 
    return playbackStateCompat;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder("PlaybackState {");
    stringBuilder.append("state=");
    stringBuilder.append(this.g);
    stringBuilder.append(", position=");
    stringBuilder.append(this.h);
    stringBuilder.append(", buffered position=");
    stringBuilder.append(this.i);
    stringBuilder.append(", speed=");
    stringBuilder.append(this.j);
    stringBuilder.append(", updated=");
    stringBuilder.append(this.n);
    stringBuilder.append(", actions=");
    stringBuilder.append(this.k);
    stringBuilder.append(", error code=");
    stringBuilder.append(this.l);
    stringBuilder.append(", error message=");
    stringBuilder.append(this.m);
    stringBuilder.append(", custom actions=");
    stringBuilder.append(this.o);
    stringBuilder.append(", active item id=");
    stringBuilder.append(this.p);
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeInt(this.g);
    paramParcel.writeLong(this.h);
    paramParcel.writeFloat(this.j);
    paramParcel.writeLong(this.n);
    paramParcel.writeLong(this.i);
    paramParcel.writeLong(this.k);
    TextUtils.writeToParcel(this.m, paramParcel, paramInt);
    paramParcel.writeTypedList(this.o);
    paramParcel.writeLong(this.p);
    paramParcel.writeBundle(this.q);
    paramParcel.writeInt(this.l);
  }
  
  public static final class CustomAction implements Parcelable {
    public static final Parcelable.Creator<CustomAction> CREATOR = new a();
    
    private final String g;
    
    private final CharSequence h;
    
    private final int i;
    
    private final Bundle j;
    
    private Object k;
    
    CustomAction(Parcel param1Parcel) {
      this.g = param1Parcel.readString();
      this.h = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(param1Parcel);
      this.i = param1Parcel.readInt();
      this.j = param1Parcel.readBundle(MediaSessionCompat.class.getClassLoader());
    }
    
    CustomAction(String param1String, CharSequence param1CharSequence, int param1Int, Bundle param1Bundle) {
      this.g = param1String;
      this.h = param1CharSequence;
      this.i = param1Int;
      this.j = param1Bundle;
    }
    
    public static CustomAction a(Object param1Object) {
      if (param1Object != null) {
        CustomAction customAction = new CustomAction(g.a.a(param1Object), g.a.d(param1Object), g.a.c(param1Object), g.a.b(param1Object));
        customAction.k = param1Object;
        return customAction;
      } 
      return null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Action:mName='");
      stringBuilder.append(this.h);
      stringBuilder.append(", mIcon=");
      stringBuilder.append(this.i);
      stringBuilder.append(", mExtras=");
      stringBuilder.append(this.j);
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeString(this.g);
      TextUtils.writeToParcel(this.h, param1Parcel, param1Int);
      param1Parcel.writeInt(this.i);
      param1Parcel.writeBundle(this.j);
    }
    
    static final class a implements Parcelable.Creator<CustomAction> {
      public PlaybackStateCompat.CustomAction a(Parcel param2Parcel) {
        return new PlaybackStateCompat.CustomAction(param2Parcel);
      }
      
      public PlaybackStateCompat.CustomAction[] b(int param2Int) {
        return new PlaybackStateCompat.CustomAction[param2Int];
      }
    }
  }
  
  static final class a implements Parcelable.Creator<CustomAction> {
    public PlaybackStateCompat.CustomAction a(Parcel param1Parcel) {
      return new PlaybackStateCompat.CustomAction(param1Parcel);
    }
    
    public PlaybackStateCompat.CustomAction[] b(int param1Int) {
      return new PlaybackStateCompat.CustomAction[param1Int];
    }
  }
  
  static final class a implements Parcelable.Creator<PlaybackStateCompat> {
    public PlaybackStateCompat a(Parcel param1Parcel) {
      return new PlaybackStateCompat(param1Parcel);
    }
    
    public PlaybackStateCompat[] b(int param1Int) {
      return new PlaybackStateCompat[param1Int];
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\android\support\v4\media\session\PlaybackStateCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */