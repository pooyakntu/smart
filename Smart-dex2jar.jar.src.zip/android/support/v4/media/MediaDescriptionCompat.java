package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;

public final class MediaDescriptionCompat implements Parcelable {
  public static final Parcelable.Creator<MediaDescriptionCompat> CREATOR = new a();
  
  private final String g;
  
  private final CharSequence h;
  
  private final CharSequence i;
  
  private final CharSequence j;
  
  private final Bitmap k;
  
  private final Uri l;
  
  private final Bundle m;
  
  private final Uri n;
  
  private Object o;
  
  MediaDescriptionCompat(String paramString, CharSequence paramCharSequence1, CharSequence paramCharSequence2, CharSequence paramCharSequence3, Bitmap paramBitmap, Uri paramUri1, Bundle paramBundle, Uri paramUri2) {
    this.g = paramString;
    this.h = paramCharSequence1;
    this.i = paramCharSequence2;
    this.j = paramCharSequence3;
    this.k = paramBitmap;
    this.l = paramUri1;
    this.m = paramBundle;
    this.n = paramUri2;
  }
  
  public static MediaDescriptionCompat a(Object paramObject) {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aconst_null
    //   3: astore_3
    //   4: aload_0
    //   5: ifnull -> 204
    //   8: getstatic android/os/Build$VERSION.SDK_INT : I
    //   11: istore_1
    //   12: new android/support/v4/media/MediaDescriptionCompat$b
    //   15: dup
    //   16: invokespecial <init> : ()V
    //   19: astore #5
    //   21: aload #5
    //   23: aload_0
    //   24: invokestatic f : (Ljava/lang/Object;)Ljava/lang/String;
    //   27: invokevirtual f : (Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   30: pop
    //   31: aload #5
    //   33: aload_0
    //   34: invokestatic h : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   37: invokevirtual i : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   40: pop
    //   41: aload #5
    //   43: aload_0
    //   44: invokestatic g : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   47: invokevirtual h : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   50: pop
    //   51: aload #5
    //   53: aload_0
    //   54: invokestatic b : (Ljava/lang/Object;)Ljava/lang/CharSequence;
    //   57: invokevirtual b : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   60: pop
    //   61: aload #5
    //   63: aload_0
    //   64: invokestatic d : (Ljava/lang/Object;)Landroid/graphics/Bitmap;
    //   67: invokevirtual d : (Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   70: pop
    //   71: aload #5
    //   73: aload_0
    //   74: invokestatic e : (Ljava/lang/Object;)Landroid/net/Uri;
    //   77: invokevirtual e : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   80: pop
    //   81: aload_0
    //   82: invokestatic c : (Ljava/lang/Object;)Landroid/os/Bundle;
    //   85: astore #4
    //   87: aload #4
    //   89: ifnull -> 111
    //   92: aload #4
    //   94: invokestatic a : (Landroid/os/Bundle;)V
    //   97: aload #4
    //   99: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   101: invokevirtual getParcelable : (Ljava/lang/String;)Landroid/os/Parcelable;
    //   104: checkcast android/net/Uri
    //   107: astore_2
    //   108: goto -> 113
    //   111: aconst_null
    //   112: astore_2
    //   113: aload_2
    //   114: ifnull -> 153
    //   117: aload #4
    //   119: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   121: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   124: ifeq -> 139
    //   127: aload #4
    //   129: invokevirtual size : ()I
    //   132: iconst_2
    //   133: if_icmpne -> 139
    //   136: goto -> 156
    //   139: aload #4
    //   141: ldc 'android.support.v4.media.description.MEDIA_URI'
    //   143: invokevirtual remove : (Ljava/lang/String;)V
    //   146: aload #4
    //   148: ldc 'android.support.v4.media.description.NULL_BUNDLE_FLAG'
    //   150: invokevirtual remove : (Ljava/lang/String;)V
    //   153: aload #4
    //   155: astore_3
    //   156: aload #5
    //   158: aload_3
    //   159: invokevirtual c : (Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   162: pop
    //   163: aload_2
    //   164: ifnull -> 177
    //   167: aload #5
    //   169: aload_2
    //   170: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   173: pop
    //   174: goto -> 193
    //   177: iload_1
    //   178: bipush #23
    //   180: if_icmplt -> 193
    //   183: aload #5
    //   185: aload_0
    //   186: invokestatic a : (Ljava/lang/Object;)Landroid/net/Uri;
    //   189: invokevirtual g : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$b;
    //   192: pop
    //   193: aload #5
    //   195: invokevirtual a : ()Landroid/support/v4/media/MediaDescriptionCompat;
    //   198: astore_2
    //   199: aload_2
    //   200: aload_0
    //   201: putfield o : Ljava/lang/Object;
    //   204: aload_2
    //   205: areturn
  }
  
  public Object b() {
    Object object2 = this.o;
    Object object1 = object2;
    if (object2 == null) {
      int i = Build.VERSION.SDK_INT;
      Object object = a.a.b();
      a.a.g(object, this.g);
      a.a.i(object, this.h);
      a.a.h(object, this.i);
      a.a.c(object, this.j);
      a.a.e(object, this.k);
      a.a.f(object, this.l);
      object2 = this.m;
      object1 = object2;
      if (i < 23) {
        object1 = object2;
        if (this.n != null) {
          object1 = object2;
          if (object2 == null) {
            object1 = new Bundle();
            object1.putBoolean("android.support.v4.media.description.NULL_BUNDLE_FLAG", true);
          } 
          object1.putParcelable("android.support.v4.media.description.MEDIA_URI", (Parcelable)this.n);
        } 
      } 
      a.a.d(object, (Bundle)object1);
      if (i >= 23)
        d.a.a(object, this.n); 
      object1 = a.a.a(object);
      this.o = object1;
    } 
    return object1;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.h);
    stringBuilder.append(", ");
    stringBuilder.append(this.i);
    stringBuilder.append(", ");
    stringBuilder.append(this.j);
    return stringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    a.i(b(), paramParcel, paramInt);
  }
  
  static final class a implements Parcelable.Creator<MediaDescriptionCompat> {
    public MediaDescriptionCompat a(Parcel param1Parcel) {
      return MediaDescriptionCompat.a(a.a(param1Parcel));
    }
    
    public MediaDescriptionCompat[] b(int param1Int) {
      return new MediaDescriptionCompat[param1Int];
    }
  }
  
  public static final class b {
    private String a;
    
    private CharSequence b;
    
    private CharSequence c;
    
    private CharSequence d;
    
    private Bitmap e;
    
    private Uri f;
    
    private Bundle g;
    
    private Uri h;
    
    public MediaDescriptionCompat a() {
      return new MediaDescriptionCompat(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h);
    }
    
    public b b(CharSequence param1CharSequence) {
      this.d = param1CharSequence;
      return this;
    }
    
    public b c(Bundle param1Bundle) {
      this.g = param1Bundle;
      return this;
    }
    
    public b d(Bitmap param1Bitmap) {
      this.e = param1Bitmap;
      return this;
    }
    
    public b e(Uri param1Uri) {
      this.f = param1Uri;
      return this;
    }
    
    public b f(String param1String) {
      this.a = param1String;
      return this;
    }
    
    public b g(Uri param1Uri) {
      this.h = param1Uri;
      return this;
    }
    
    public b h(CharSequence param1CharSequence) {
      this.c = param1CharSequence;
      return this;
    }
    
    public b i(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\android\support\v4\media\MediaDescriptionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */