package a7;

import android.net.wifi.ScanResult;
import java.util.List;

public interface b {
  ScanResult a(List<ScanResult> paramList);
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a7\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */