package a;

public final class a {
  public final StackTraceElement a() {
    return b.a(new Exception(), c.class.getSimpleName());
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */