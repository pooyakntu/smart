package a9;

import r8.m;

class e {
  public static final long a(long paramLong, d paramd1, d paramd2) {
    m.j(paramd1, "sourceUnit");
    m.j(paramd2, "targetUnit");
    return paramd2.getTimeUnit$kotlin_stdlib().convert(paramLong, paramd1.getTimeUnit$kotlin_stdlib());
  }
  
  public static final long b(long paramLong, d paramd1, d paramd2) {
    m.j(paramd1, "sourceUnit");
    m.j(paramd2, "targetUnit");
    return paramd2.getTimeUnit$kotlin_stdlib().convert(paramLong, paramd1.getTimeUnit$kotlin_stdlib());
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a9\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */