package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.result.ActivityResultRegistry;
import androidx.activity.result.b;
import androidx.activity.result.c;
import androidx.activity.result.d;
import androidx.activity.result.e;
import androidx.core.app.g;
import androidx.core.app.k1;
import androidx.core.app.o;
import androidx.core.app.p;
import androidx.core.view.n0;
import androidx.core.view.y;
import androidx.lifecycle.HasDefaultViewModelProviderFactory;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ReportFragment;
import androidx.lifecycle.SavedStateHandleSupport;
import androidx.lifecycle.SavedStateViewModelFactory;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewTreeLifecycleOwner;
import androidx.lifecycle.ViewTreeViewModelStoreOwner;
import androidx.lifecycle.viewmodel.CreationExtras;
import androidx.lifecycle.viewmodel.MutableCreationExtras;
import java.io.Serializable;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import p0.d;

public class ComponentActivity extends o implements ViewModelStoreOwner, HasDefaultViewModelProviderFactory, d, l, d {
  private static final String ACTIVITY_RESULT_TAG = "android:support:activity-result";
  
  private final ActivityResultRegistry mActivityResultRegistry;
  
  private int mContentLayoutId;
  
  final d.a mContextAwareHelper = new d.a();
  
  private ViewModelProvider.Factory mDefaultFactory;
  
  private boolean mDispatchingOnMultiWindowModeChanged;
  
  private boolean mDispatchingOnPictureInPictureModeChanged;
  
  private final LifecycleRegistry mLifecycleRegistry = new LifecycleRegistry(this);
  
  private final y mMenuHostHelper = new y(new b(this));
  
  private final AtomicInteger mNextLocalRequestCode;
  
  private final OnBackPressedDispatcher mOnBackPressedDispatcher;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Configuration>> mOnConfigurationChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<p>> mOnMultiWindowModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Intent>> mOnNewIntentListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<k1>> mOnPictureInPictureModeChangedListeners;
  
  private final CopyOnWriteArrayList<androidx.core.util.a<Integer>> mOnTrimMemoryListeners;
  
  final p0.c mSavedStateRegistryController;
  
  private ViewModelStore mViewModelStore;
  
  public ComponentActivity() {
    p0.c c1 = p0.c.a(this);
    this.mSavedStateRegistryController = c1;
    this.mOnBackPressedDispatcher = new OnBackPressedDispatcher(new a(this));
    this.mNextLocalRequestCode = new AtomicInteger();
    this.mActivityResultRegistry = new b(this);
    this.mOnConfigurationChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<Configuration>>();
    this.mOnTrimMemoryListeners = new CopyOnWriteArrayList<androidx.core.util.a<Integer>>();
    this.mOnNewIntentListeners = new CopyOnWriteArrayList<androidx.core.util.a<Intent>>();
    this.mOnMultiWindowModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<p>>();
    this.mOnPictureInPictureModeChangedListeners = new CopyOnWriteArrayList<androidx.core.util.a<k1>>();
    this.mDispatchingOnMultiWindowModeChanged = false;
    this.mDispatchingOnPictureInPictureModeChanged = false;
    if (getLifecycle() != null) {
      int i = Build.VERSION.SDK_INT;
      getLifecycle().addObserver((LifecycleObserver)new LifecycleEventObserver(this) {
            public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
              if (param1Event == Lifecycle.Event.ON_STOP) {
                Window window = this.g.getWindow();
                if (window != null) {
                  View view = window.peekDecorView();
                } else {
                  window = null;
                } 
                if (window != null)
                  ComponentActivity.c.a((View)window); 
              } 
            }
          });
      getLifecycle().addObserver((LifecycleObserver)new LifecycleEventObserver(this) {
            public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
              if (param1Event == Lifecycle.Event.ON_DESTROY) {
                this.g.mContextAwareHelper.b();
                if (!this.g.isChangingConfigurations())
                  this.g.getViewModelStore().clear(); 
              } 
            }
          });
      getLifecycle().addObserver((LifecycleObserver)new LifecycleEventObserver(this) {
            public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
              this.g.ensureViewModelStore();
              this.g.getLifecycle().removeObserver((LifecycleObserver)this);
            }
          });
      c1.c();
      SavedStateHandleSupport.enableSavedStateHandles(this);
      if (i <= 23)
        getLifecycle().addObserver((LifecycleObserver)new ImmLeaksCleaner((Activity)this)); 
      getSavedStateRegistry().h("android:support:activity-result", new c(this));
      addOnContextAvailableListener(new d(this));
      return;
    } 
    throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
  }
  
  public ComponentActivity(int paramInt) {
    this();
    this.mContentLayoutId = paramInt;
  }
  
  private void initViewTreeOwners() {
    ViewTreeLifecycleOwner.set(getWindow().getDecorView(), this);
    ViewTreeViewModelStoreOwner.set(getWindow().getDecorView(), this);
    p0.e.a(getWindow().getDecorView(), this);
    n.a(getWindow().getDecorView(), this);
  }
  
  public void addContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.addContentView(paramView, paramLayoutParams);
  }
  
  public void addMenuProvider(n0 paramn0) {
    this.mMenuHostHelper.c(paramn0);
  }
  
  public void addMenuProvider(n0 paramn0, LifecycleOwner paramLifecycleOwner) {
    this.mMenuHostHelper.d(paramn0, paramLifecycleOwner);
  }
  
  @SuppressLint({"LambdaLast"})
  public void addMenuProvider(n0 paramn0, LifecycleOwner paramLifecycleOwner, Lifecycle.State paramState) {
    this.mMenuHostHelper.e(paramn0, paramLifecycleOwner, paramState);
  }
  
  public final void addOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.add(parama);
  }
  
  public final void addOnContextAvailableListener(d.b paramb) {
    this.mContextAwareHelper.a(paramb);
  }
  
  public final void addOnMultiWindowModeChangedListener(androidx.core.util.a<p> parama) {
    this.mOnMultiWindowModeChangedListeners.add(parama);
  }
  
  public final void addOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.add(parama);
  }
  
  public final void addOnPictureInPictureModeChangedListener(androidx.core.util.a<k1> parama) {
    this.mOnPictureInPictureModeChangedListeners.add(parama);
  }
  
  public final void addOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.add(parama);
  }
  
  void ensureViewModelStore() {
    if (this.mViewModelStore == null) {
      e e = (e)getLastNonConfigurationInstance();
      if (e != null)
        this.mViewModelStore = e.b; 
      if (this.mViewModelStore == null)
        this.mViewModelStore = new ViewModelStore(); 
    } 
  }
  
  public final ActivityResultRegistry getActivityResultRegistry() {
    return this.mActivityResultRegistry;
  }
  
  public CreationExtras getDefaultViewModelCreationExtras() {
    MutableCreationExtras mutableCreationExtras = new MutableCreationExtras();
    if (getApplication() != null)
      mutableCreationExtras.set(ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY, getApplication()); 
    mutableCreationExtras.set(SavedStateHandleSupport.SAVED_STATE_REGISTRY_OWNER_KEY, this);
    mutableCreationExtras.set(SavedStateHandleSupport.VIEW_MODEL_STORE_OWNER_KEY, this);
    if (getIntent() != null && getIntent().getExtras() != null)
      mutableCreationExtras.set(SavedStateHandleSupport.DEFAULT_ARGS_KEY, getIntent().getExtras()); 
    return (CreationExtras)mutableCreationExtras;
  }
  
  public ViewModelProvider.Factory getDefaultViewModelProviderFactory() {
    if (this.mDefaultFactory == null) {
      Bundle bundle;
      Application application = getApplication();
      if (getIntent() != null) {
        bundle = getIntent().getExtras();
      } else {
        bundle = null;
      } 
      this.mDefaultFactory = (ViewModelProvider.Factory)new SavedStateViewModelFactory(application, this, bundle);
    } 
    return this.mDefaultFactory;
  }
  
  @Deprecated
  public Object getLastCustomNonConfigurationInstance() {
    e e = (e)getLastNonConfigurationInstance();
    return (e != null) ? e.a : null;
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)this.mLifecycleRegistry;
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.mOnBackPressedDispatcher;
  }
  
  public final androidx.savedstate.a getSavedStateRegistry() {
    return this.mSavedStateRegistryController.b();
  }
  
  public ViewModelStore getViewModelStore() {
    if (getApplication() != null) {
      ensureViewModelStore();
      return this.mViewModelStore;
    } 
    throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
  }
  
  public void invalidateMenu() {
    invalidateOptionsMenu();
  }
  
  @Deprecated
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {
    if (!this.mActivityResultRegistry.b(paramInt1, paramInt2, paramIntent))
      super.onActivityResult(paramInt1, paramInt2, paramIntent); 
  }
  
  public void onBackPressed() {
    this.mOnBackPressedDispatcher.g();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    Iterator<androidx.core.util.a<Configuration>> iterator = this.mOnConfigurationChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramConfiguration); 
  }
  
  protected void onCreate(Bundle paramBundle) {
    this.mSavedStateRegistryController.d(paramBundle);
    this.mContextAwareHelper.c((Context)this);
    super.onCreate(paramBundle);
    ReportFragment.injectIfNeededIn((Activity)this);
    if (androidx.core.os.a.c())
      this.mOnBackPressedDispatcher.h(d.a((Activity)this)); 
    int i = this.mContentLayoutId;
    if (i != 0)
      setContentView(i); 
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    if (paramInt == 0) {
      super.onCreatePanelMenu(paramInt, paramMenu);
      this.mMenuHostHelper.h(paramMenu, getMenuInflater());
    } 
    return true;
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return super.onMenuItemSelected(paramInt, paramMenuItem) ? true : ((paramInt == 0) ? this.mMenuHostHelper.j(paramMenuItem) : false);
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnMultiWindowModeChanged)
      return; 
    Iterator<androidx.core.util.a<p>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new p(paramBoolean)); 
  }
  
  public void onMultiWindowModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnMultiWindowModeChanged = true;
    try {
      super.onMultiWindowModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnMultiWindowModeChanged = false;
      Iterator<androidx.core.util.a<p>> iterator = this.mOnMultiWindowModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnMultiWindowModeChanged = false;
    } 
  }
  
  protected void onNewIntent(@SuppressLint({"UnknownNullness", "MissingNullability"}) Intent paramIntent) {
    super.onNewIntent(paramIntent);
    Iterator<androidx.core.util.a<Intent>> iterator = this.mOnNewIntentListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(paramIntent); 
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.mMenuHostHelper.i(paramMenu);
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean) {
    if (this.mDispatchingOnPictureInPictureModeChanged)
      return; 
    Iterator<androidx.core.util.a<k1>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(new k1(paramBoolean)); 
  }
  
  public void onPictureInPictureModeChanged(boolean paramBoolean, Configuration paramConfiguration) {
    this.mDispatchingOnPictureInPictureModeChanged = true;
    try {
      super.onPictureInPictureModeChanged(paramBoolean, paramConfiguration);
      this.mDispatchingOnPictureInPictureModeChanged = false;
      Iterator<androidx.core.util.a<k1>> iterator = this.mOnPictureInPictureModeChangedListeners.iterator();
      return;
    } finally {
      this.mDispatchingOnPictureInPictureModeChanged = false;
    } 
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    if (paramInt == 0) {
      super.onPreparePanel(paramInt, paramView, paramMenu);
      this.mMenuHostHelper.k(paramMenu);
    } 
    return true;
  }
  
  @Deprecated
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfint) {
    if (!this.mActivityResultRegistry.b(paramInt, -1, (new Intent()).putExtra("androidx.activity.result.contract.extra.PERMISSIONS", paramArrayOfString).putExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS", paramArrayOfint)) && Build.VERSION.SDK_INT >= 23)
      super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfint); 
  }
  
  @Deprecated
  public Object onRetainCustomNonConfigurationInstance() {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance() {
    Object object = onRetainCustomNonConfigurationInstance();
    ViewModelStore viewModelStore2 = this.mViewModelStore;
    ViewModelStore viewModelStore1 = viewModelStore2;
    if (viewModelStore2 == null) {
      e e1 = (e)getLastNonConfigurationInstance();
      viewModelStore1 = viewModelStore2;
      if (e1 != null)
        viewModelStore1 = e1.b; 
    } 
    if (viewModelStore1 == null && object == null)
      return null; 
    e e = new e();
    e.a = object;
    e.b = viewModelStore1;
    return e;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    Lifecycle lifecycle = getLifecycle();
    if (lifecycle instanceof LifecycleRegistry)
      ((LifecycleRegistry)lifecycle).setCurrentState(Lifecycle.State.CREATED); 
    super.onSaveInstanceState(paramBundle);
    this.mSavedStateRegistryController.e(paramBundle);
  }
  
  public void onTrimMemory(int paramInt) {
    super.onTrimMemory(paramInt);
    Iterator<androidx.core.util.a<Integer>> iterator = this.mOnTrimMemoryListeners.iterator();
    while (iterator.hasNext())
      ((androidx.core.util.a)iterator.next()).accept(Integer.valueOf(paramInt)); 
  }
  
  public Context peekAvailableContext() {
    return this.mContextAwareHelper.d();
  }
  
  public final <I, O> c<I> registerForActivityResult(e.a<I, O> parama, ActivityResultRegistry paramActivityResultRegistry, b<O> paramb) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("activity_rq#");
    stringBuilder.append(this.mNextLocalRequestCode.getAndIncrement());
    return paramActivityResultRegistry.i(stringBuilder.toString(), this, parama, paramb);
  }
  
  public final <I, O> c<I> registerForActivityResult(e.a<I, O> parama, b<O> paramb) {
    return registerForActivityResult(parama, this.mActivityResultRegistry, paramb);
  }
  
  public void removeMenuProvider(n0 paramn0) {
    this.mMenuHostHelper.l(paramn0);
  }
  
  public final void removeOnConfigurationChangedListener(androidx.core.util.a<Configuration> parama) {
    this.mOnConfigurationChangedListeners.remove(parama);
  }
  
  public final void removeOnContextAvailableListener(d.b paramb) {
    this.mContextAwareHelper.e(paramb);
  }
  
  public final void removeOnMultiWindowModeChangedListener(androidx.core.util.a<p> parama) {
    this.mOnMultiWindowModeChangedListeners.remove(parama);
  }
  
  public final void removeOnNewIntentListener(androidx.core.util.a<Intent> parama) {
    this.mOnNewIntentListeners.remove(parama);
  }
  
  public final void removeOnPictureInPictureModeChangedListener(androidx.core.util.a<k1> parama) {
    this.mOnPictureInPictureModeChangedListeners.remove(parama);
  }
  
  public final void removeOnTrimMemoryListener(androidx.core.util.a<Integer> parama) {
    this.mOnTrimMemoryListeners.remove(parama);
  }
  
  public void reportFullyDrawn() {
    try {
      if (u0.b.d())
        u0.b.a("reportFullyDrawn() for ComponentActivity"); 
      super.reportFullyDrawn();
      return;
    } finally {
      u0.b.b();
    } 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    super.setContentView(paramInt);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView) {
    initViewTreeOwners();
    super.setContentView(paramView);
  }
  
  public void setContentView(@SuppressLint({"UnknownNullness", "MissingNullability"}) View paramView, @SuppressLint({"UnknownNullness", "MissingNullability"}) ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    super.setContentView(paramView, paramLayoutParams);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt) {
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  @Deprecated
  public void startActivityForResult(Intent paramIntent, int paramInt, Bundle paramBundle) {
    super.startActivityForResult(paramIntent, paramInt, paramBundle);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4);
  }
  
  @Deprecated
  public void startIntentSenderForResult(IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    super.startIntentSenderForResult(paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0) {}
    
    public void run() {
      try {
        this.g.onBackPressed();
        return;
      } catch (IllegalStateException illegalStateException) {
        if (TextUtils.equals(illegalStateException.getMessage(), "Can not perform this action after onSaveInstanceState"))
          return; 
        throw illegalStateException;
      } 
    }
  }
  
  class b extends ActivityResultRegistry {
    b(ComponentActivity this$0) {}
    
    public <I, O> void f(int param1Int, e.a<I, O> param1a, I param1I, g param1g) {
      String[] arrayOfString1;
      String[] arrayOfString2;
      e e;
      ComponentActivity componentActivity = this.i;
      e.a.a a1 = param1a.b((Context)componentActivity, param1I);
      if (a1 != null) {
        (new Handler(Looper.getMainLooper())).post(new a(this, param1Int, a1));
        return;
      } 
      Intent intent = param1a.a((Context)componentActivity, param1I);
      if (intent.getExtras() != null && intent.getExtras().getClassLoader() == null)
        intent.setExtrasClassLoader(componentActivity.getClassLoader()); 
      if (intent.hasExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE")) {
        Bundle bundle = intent.getBundleExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
        intent.removeExtra("androidx.activity.result.contract.extra.ACTIVITY_OPTIONS_BUNDLE");
      } else {
        param1a = null;
      } 
      if ("androidx.activity.result.contract.action.REQUEST_PERMISSIONS".equals(intent.getAction())) {
        arrayOfString2 = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        arrayOfString1 = arrayOfString2;
        if (arrayOfString2 == null)
          arrayOfString1 = new String[0]; 
        androidx.core.app.b.s((Activity)componentActivity, arrayOfString1, param1Int);
        return;
      } 
      if ("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST".equals(arrayOfString2.getAction())) {
        e = (e)arrayOfString2.getParcelableExtra("androidx.activity.result.contract.extra.INTENT_SENDER_REQUEST");
        try {
          androidx.core.app.b.x((Activity)componentActivity, e.f(), param1Int, e.a(), e.b(), e.e(), 0, (Bundle)arrayOfString1);
          return;
        } catch (android.content.IntentSender.SendIntentException sendIntentException) {
          (new Handler(Looper.getMainLooper())).post(new b(this, param1Int, sendIntentException));
          return;
        } 
      } 
      androidx.core.app.b.w((Activity)componentActivity, (Intent)e, param1Int, (Bundle)sendIntentException);
    }
    
    class a implements Runnable {
      a(ComponentActivity.b this$0, int param2Int, e.a.a param2a) {}
      
      public void run() {
        this.i.c(this.g, this.h.a());
      }
    }
    
    class b implements Runnable {
      b(ComponentActivity.b this$0, int param2Int, IntentSender.SendIntentException param2SendIntentException) {}
      
      public void run() {
        this.i.b(this.g, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.h));
      }
    }
  }
  
  class a implements Runnable {
    a(ComponentActivity this$0, int param1Int, e.a.a param1a) {}
    
    public void run() {
      this.i.c(this.g, this.h.a());
    }
  }
  
  class b implements Runnable {
    b(ComponentActivity this$0, int param1Int, IntentSender.SendIntentException param1SendIntentException) {}
    
    public void run() {
      this.i.b(this.g, 0, (new Intent()).setAction("androidx.activity.result.contract.action.INTENT_SENDER_REQUEST").putExtra("androidx.activity.result.contract.extra.SEND_INTENT_EXCEPTION", (Serializable)this.h));
    }
  }
  
  static class c {
    static void a(View param1View) {
      param1View.cancelPendingInputEvents();
    }
  }
  
  static class d {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
  }
  
  static final class e {
    Object a;
    
    ViewModelStore b;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\ComponentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */