package androidx.activity;

import androidx.lifecycle.LifecycleOwner;
import e8.q;
import q8.l;
import r8.m;

public final class k {
  public static final g a(OnBackPressedDispatcher paramOnBackPressedDispatcher, LifecycleOwner paramLifecycleOwner, boolean paramBoolean, l<? super g, q> paraml) {
    m.j(paramOnBackPressedDispatcher, "<this>");
    m.j(paraml, "onBackPressed");
    a a = new a(paramBoolean, paraml);
    if (paramLifecycleOwner != null) {
      paramOnBackPressedDispatcher.c(paramLifecycleOwner, a);
      return a;
    } 
    paramOnBackPressedDispatcher.b(a);
    return a;
  }
  
  public static final class a extends g {
    a(boolean param1Boolean, l<? super g, q> param1l) {
      super(param1Boolean);
    }
    
    public void b() {
      this.d.invoke(this);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */