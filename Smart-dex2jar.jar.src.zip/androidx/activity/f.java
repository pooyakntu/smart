package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import r8.m;

public class f extends Dialog implements LifecycleOwner, l {
  private LifecycleRegistry g;
  
  private final OnBackPressedDispatcher h = new OnBackPressedDispatcher(new e(this));
  
  public f(Context paramContext, int paramInt) {
    super(paramContext, paramInt);
  }
  
  private final LifecycleRegistry b() {
    LifecycleRegistry lifecycleRegistry2 = this.g;
    LifecycleRegistry lifecycleRegistry1 = lifecycleRegistry2;
    if (lifecycleRegistry2 == null) {
      lifecycleRegistry1 = new LifecycleRegistry(this);
      this.g = lifecycleRegistry1;
    } 
    return lifecycleRegistry1;
  }
  
  private static final void c(f paramf) {
    m.j(paramf, "this$0");
    paramf.onBackPressed();
  }
  
  public final Lifecycle getLifecycle() {
    return (Lifecycle)b();
  }
  
  public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
    return this.h;
  }
  
  public void onBackPressed() {
    this.h.g();
  }
  
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (Build.VERSION.SDK_INT >= 33)
      this.h.h(getOnBackInvokedDispatcher()); 
    b().handleLifecycleEvent(Lifecycle.Event.ON_CREATE);
  }
  
  protected void onStart() {
    super.onStart();
    b().handleLifecycleEvent(Lifecycle.Event.ON_RESUME);
  }
  
  protected void onStop() {
    b().handleLifecycleEvent(Lifecycle.Event.ON_DESTROY);
    this.g = null;
    super.onStop();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */