package androidx.activity;

import android.annotation.SuppressLint;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleEventObserver;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.LifecycleOwner;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Objects;

public final class OnBackPressedDispatcher {
  private final Runnable a;
  
  final ArrayDeque<g> b = new ArrayDeque<g>();
  
  private androidx.core.util.a<Boolean> c;
  
  private OnBackInvokedCallback d;
  
  private OnBackInvokedDispatcher e;
  
  private boolean f = false;
  
  public OnBackPressedDispatcher(Runnable paramRunnable) {
    this.a = paramRunnable;
    if (androidx.core.os.a.c()) {
      this.c = new h(this);
      this.d = a.a(new i(this));
    } 
  }
  
  public void b(g paramg) {
    d(paramg);
  }
  
  @SuppressLint({"LambdaLast"})
  public void c(LifecycleOwner paramLifecycleOwner, g paramg) {
    Lifecycle lifecycle = paramLifecycleOwner.getLifecycle();
    if (lifecycle.getCurrentState() == Lifecycle.State.DESTROYED)
      return; 
    paramg.a(new LifecycleOnBackPressedCancellable(this, lifecycle, paramg));
    if (androidx.core.os.a.c()) {
      i();
      paramg.g(this.c);
    } 
  }
  
  a d(g paramg) {
    this.b.add(paramg);
    b b = new b(this, paramg);
    paramg.a(b);
    if (androidx.core.os.a.c()) {
      i();
      paramg.g(this.c);
    } 
    return b;
  }
  
  public boolean e() {
    Iterator<g> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      if (((g)iterator.next()).c())
        return true; 
    } 
    return false;
  }
  
  public void g() {
    Iterator<g> iterator = this.b.descendingIterator();
    while (iterator.hasNext()) {
      g g = iterator.next();
      if (g.c()) {
        g.b();
        return;
      } 
    } 
    Runnable runnable = this.a;
    if (runnable != null)
      runnable.run(); 
  }
  
  public void h(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    this.e = paramOnBackInvokedDispatcher;
    i();
  }
  
  void i() {
    boolean bool = e();
    OnBackInvokedDispatcher onBackInvokedDispatcher = this.e;
    if (onBackInvokedDispatcher != null) {
      if (bool && !this.f) {
        a.b(onBackInvokedDispatcher, 0, this.d);
        this.f = true;
        return;
      } 
      if (!bool && this.f) {
        a.c(onBackInvokedDispatcher, this.d);
        this.f = false;
      } 
    } 
  }
  
  private class LifecycleOnBackPressedCancellable implements LifecycleEventObserver, a {
    private final Lifecycle g;
    
    private final g h;
    
    private a i;
    
    LifecycleOnBackPressedCancellable(OnBackPressedDispatcher this$0, Lifecycle param1Lifecycle, g param1g) {
      this.g = param1Lifecycle;
      this.h = param1g;
      param1Lifecycle.addObserver((LifecycleObserver)this);
    }
    
    public void cancel() {
      this.g.removeObserver((LifecycleObserver)this);
      this.h.e(this);
      a a1 = this.i;
      if (a1 != null) {
        a1.cancel();
        this.i = null;
      } 
    }
    
    public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      if (param1Event == Lifecycle.Event.ON_START) {
        this.i = this.j.d(this.h);
        return;
      } 
      if (param1Event == Lifecycle.Event.ON_STOP) {
        a a1 = this.i;
        if (a1 != null) {
          a1.cancel();
          return;
        } 
      } else if (param1Event == Lifecycle.Event.ON_DESTROY) {
        cancel();
      } 
    }
  }
  
  static class a {
    static OnBackInvokedCallback a(Runnable param1Runnable) {
      Objects.requireNonNull(param1Runnable);
      return new j(param1Runnable);
    }
    
    static void b(Object param1Object1, int param1Int, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(param1Int, (OnBackInvokedCallback)param1Object2);
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private class b implements a {
    private final g g;
    
    b(OnBackPressedDispatcher this$0, g param1g) {
      this.g = param1g;
    }
    
    public void cancel() {
      this.h.b.remove(this.g);
      this.g.e(this);
      if (androidx.core.os.a.c()) {
        this.g.g(null);
        this.h.i();
      } 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\OnBackPressedDispatcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */