package androidx.activity;

import android.view.View;
import r8.m;

public final class n {
  public static final void a(View paramView, l paraml) {
    m.j(paramView, "<this>");
    m.j(paraml, "onBackPressedDispatcherOwner");
    paramView.setTag(m.a, paraml);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */