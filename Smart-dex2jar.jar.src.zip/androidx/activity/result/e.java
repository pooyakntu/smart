package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
public final class e implements Parcelable {
  public static final Parcelable.Creator<e> CREATOR = new a();
  
  private final IntentSender g;
  
  private final Intent h;
  
  private final int i;
  
  private final int j;
  
  e(IntentSender paramIntentSender, Intent paramIntent, int paramInt1, int paramInt2) {
    this.g = paramIntentSender;
    this.h = paramIntent;
    this.i = paramInt1;
    this.j = paramInt2;
  }
  
  e(Parcel paramParcel) {
    this.g = (IntentSender)paramParcel.readParcelable(IntentSender.class.getClassLoader());
    this.h = (Intent)paramParcel.readParcelable(Intent.class.getClassLoader());
    this.i = paramParcel.readInt();
    this.j = paramParcel.readInt();
  }
  
  public Intent a() {
    return this.h;
  }
  
  public int b() {
    return this.i;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public int e() {
    return this.j;
  }
  
  public IntentSender f() {
    return this.g;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeParcelable((Parcelable)this.g, paramInt);
    paramParcel.writeParcelable((Parcelable)this.h, paramInt);
    paramParcel.writeInt(this.i);
    paramParcel.writeInt(this.j);
  }
  
  class a implements Parcelable.Creator<e> {
    public e a(Parcel param1Parcel) {
      return new e(param1Parcel);
    }
    
    public e[] b(int param1Int) {
      return new e[param1Int];
    }
  }
  
  public static final class b {
    private IntentSender a;
    
    private Intent b;
    
    private int c;
    
    private int d;
    
    public b(IntentSender param1IntentSender) {
      this.a = param1IntentSender;
    }
    
    public e a() {
      return new e(this.a, this.b, this.c, this.d);
    }
    
    public b b(Intent param1Intent) {
      this.b = param1Intent;
      return this;
    }
    
    public b c(int param1Int1, int param1Int2) {
      this.d = param1Int1;
      this.c = param1Int2;
      return this;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\result\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */