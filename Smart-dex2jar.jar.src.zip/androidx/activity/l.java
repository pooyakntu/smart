package androidx.activity;

import androidx.lifecycle.LifecycleOwner;

public interface l extends LifecycleOwner {
  OnBackPressedDispatcher getOnBackPressedDispatcher();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\activity\l.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */