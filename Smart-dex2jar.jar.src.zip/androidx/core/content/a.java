package androidx.core.content;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.text.TextUtils;
import androidx.appcompat.widget.r0;
import androidx.core.app.v0;
import androidx.core.content.res.h;
import java.io.File;

@SuppressLint({"PrivateConstructorForUtilityClass"})
public class a {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  public static int a(Context paramContext, String paramString) {
    androidx.core.util.c.d(paramString, "permission must be non-null");
    return (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? (v0.c(paramContext).a() ? 0 : -1) : paramContext.checkPermission(paramString, Process.myPid(), Process.myUid());
  }
  
  public static Context b(Context paramContext) {
    return (Build.VERSION.SDK_INT >= 24) ? e.a(paramContext) : null;
  }
  
  public static int c(Context paramContext, int paramInt) {
    return (Build.VERSION.SDK_INT >= 23) ? d.a(paramContext, paramInt) : paramContext.getResources().getColor(paramInt);
  }
  
  public static ColorStateList d(Context paramContext, int paramInt) {
    return h.d(paramContext.getResources(), paramInt, paramContext.getTheme());
  }
  
  public static Drawable e(Context paramContext, int paramInt) {
    return c.b(paramContext, paramInt);
  }
  
  public static File[] f(Context paramContext) {
    return b.a(paramContext);
  }
  
  public static File[] g(Context paramContext, String paramString) {
    return b.b(paramContext, paramString);
  }
  
  public static File h(Context paramContext) {
    return c.c(paramContext);
  }
  
  static String i(Context paramContext) {
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramContext.getPackageName());
    stringBuilder2.append(".DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION");
    String str = stringBuilder2.toString();
    if (i.b(paramContext, str) == 0)
      return str; 
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("Permission ");
    stringBuilder1.append(str);
    stringBuilder1.append(" is required by your application to receive broadcasts, please add it to your manifest");
    throw new RuntimeException(stringBuilder1.toString());
  }
  
  public static boolean j(Context paramContext, Intent[] paramArrayOfIntent, Bundle paramBundle) {
    a.a(paramContext, paramArrayOfIntent, paramBundle);
    return true;
  }
  
  public static void k(Context paramContext, Intent paramIntent, Bundle paramBundle) {
    a.b(paramContext, paramIntent, paramBundle);
  }
  
  public static void l(Context paramContext, Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 26) {
      f.b(paramContext, paramIntent);
      return;
    } 
    paramContext.startService(paramIntent);
  }
  
  static class a {
    static void a(Context param1Context, Intent[] param1ArrayOfIntent, Bundle param1Bundle) {
      param1Context.startActivities(param1ArrayOfIntent, param1Bundle);
    }
    
    static void b(Context param1Context, Intent param1Intent, Bundle param1Bundle) {
      param1Context.startActivity(param1Intent, param1Bundle);
    }
  }
  
  static class b {
    static File[] a(Context param1Context) {
      return param1Context.getExternalCacheDirs();
    }
    
    static File[] b(Context param1Context, String param1String) {
      return param1Context.getExternalFilesDirs(param1String);
    }
    
    static File[] c(Context param1Context) {
      return param1Context.getObbDirs();
    }
  }
  
  static class c {
    static File a(Context param1Context) {
      return param1Context.getCodeCacheDir();
    }
    
    static Drawable b(Context param1Context, int param1Int) {
      return param1Context.getDrawable(param1Int);
    }
    
    static File c(Context param1Context) {
      return param1Context.getNoBackupFilesDir();
    }
  }
  
  static class d {
    static int a(Context param1Context, int param1Int) {
      return c.a(param1Context, param1Int);
    }
    
    static <T> T b(Context param1Context, Class<T> param1Class) {
      return (T)r0.a(param1Context, param1Class);
    }
    
    static String c(Context param1Context, Class<?> param1Class) {
      return b.a(param1Context, param1Class);
    }
  }
  
  static class e {
    static Context a(Context param1Context) {
      return e.a(param1Context);
    }
    
    static File b(Context param1Context) {
      return f.a(param1Context);
    }
    
    static boolean c(Context param1Context) {
      return d.a(param1Context);
    }
  }
  
  static class f {
    static Intent a(Context param1Context, BroadcastReceiver param1BroadcastReceiver, IntentFilter param1IntentFilter, String param1String, Handler param1Handler, int param1Int) {
      return ((param1Int & 0x4) != 0 && param1String == null) ? param1Context.registerReceiver(param1BroadcastReceiver, param1IntentFilter, a.i(param1Context), param1Handler) : g.a(param1Context, param1BroadcastReceiver, param1IntentFilter, param1String, param1Handler, param1Int & 0x1);
    }
    
    static ComponentName b(Context param1Context, Intent param1Intent) {
      return h.a(param1Context, param1Intent);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\content\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */