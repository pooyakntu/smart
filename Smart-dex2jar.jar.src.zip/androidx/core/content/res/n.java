package androidx.core.content.res;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import r8.m;

public final class n {
  private static final void a(TypedArray paramTypedArray, int paramInt) {
    if (paramTypedArray.hasValue(paramInt))
      return; 
    throw new IllegalArgumentException("Attribute not defined in set.");
  }
  
  public static final int b(TypedArray paramTypedArray, int paramInt) {
    m.j(paramTypedArray, "<this>");
    a(paramTypedArray, paramInt);
    return paramTypedArray.getColor(paramInt, 0);
  }
  
  public static final Drawable c(TypedArray paramTypedArray, int paramInt) {
    m.j(paramTypedArray, "<this>");
    a(paramTypedArray, paramInt);
    Drawable drawable = paramTypedArray.getDrawable(paramInt);
    m.g(drawable);
    return drawable;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\content\res\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */