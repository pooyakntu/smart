package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import androidx.collection.e;
import androidx.core.content.res.e;
import androidx.core.content.res.h;

public class g {
  private static final e0 a;
  
  private static final e<String, Typeface> b = new e(16);
  
  public static Typeface a(Context paramContext, Typeface paramTypeface, int paramInt) {
    if (paramContext != null)
      return Typeface.create(paramTypeface, paramInt); 
    throw new IllegalArgumentException("Context cannot be null");
  }
  
  public static Typeface b(Context paramContext, CancellationSignal paramCancellationSignal, androidx.core.provider.g.b[] paramArrayOfb, int paramInt) {
    return a.b(paramContext, paramCancellationSignal, paramArrayOfb, paramInt);
  }
  
  public static Typeface c(Context paramContext, e.b paramb, Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3, h.e parame, Handler paramHandler, boolean paramBoolean) {
    Typeface typeface;
    e.e e1;
    a a;
    if (paramb instanceof e.e) {
      byte b1;
      boolean bool;
      e1 = (e.e)paramb;
      Typeface typeface1 = g(e1.c());
      if (typeface1 != null) {
        if (parame != null)
          parame.callbackSuccessAsync(typeface1, paramHandler); 
        return typeface1;
      } 
      if (paramBoolean ? (e1.a() == 0) : (parame == null)) {
        bool = true;
      } else {
        bool = false;
      } 
      if (paramBoolean) {
        b1 = e1.d();
      } else {
        b1 = -1;
      } 
      paramHandler = h.e.getHandler(paramHandler);
      a = new a(parame);
      typeface = androidx.core.provider.g.c(paramContext, e1.b(), paramInt3, bool, b1, paramHandler, a);
    } else {
      Typeface typeface1 = a.a((Context)typeface, (e.c)e1, paramResources, paramInt3);
      typeface = typeface1;
      if (a != null)
        if (typeface1 != null) {
          a.callbackSuccessAsync(typeface1, paramHandler);
          typeface = typeface1;
        } else {
          a.callbackFailAsync(-3, paramHandler);
          typeface = typeface1;
        }  
    } 
    if (typeface != null)
      b.put(e(paramResources, paramInt1, paramString, paramInt2, paramInt3), typeface); 
    return typeface;
  }
  
  public static Typeface d(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    Typeface typeface = a.d(paramContext, paramResources, paramInt1, paramString, paramInt3);
    if (typeface != null) {
      String str = e(paramResources, paramInt1, paramString, paramInt2, paramInt3);
      b.put(str, typeface);
    } 
    return typeface;
  }
  
  private static String e(Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    StringBuilder stringBuilder = new StringBuilder(paramResources.getResourcePackageName(paramInt1));
    stringBuilder.append('-');
    stringBuilder.append(paramString);
    stringBuilder.append('-');
    stringBuilder.append(paramInt2);
    stringBuilder.append('-');
    stringBuilder.append(paramInt1);
    stringBuilder.append('-');
    stringBuilder.append(paramInt3);
    return stringBuilder.toString();
  }
  
  public static Typeface f(Resources paramResources, int paramInt1, String paramString, int paramInt2, int paramInt3) {
    return (Typeface)b.get(e(paramResources, paramInt1, paramString, paramInt2, paramInt3));
  }
  
  private static Typeface g(String paramString) {
    Typeface typeface2 = null;
    Typeface typeface1 = typeface2;
    if (paramString != null) {
      if (paramString.isEmpty())
        return null; 
      Typeface typeface3 = Typeface.create(paramString, 0);
      Typeface typeface4 = Typeface.create(Typeface.DEFAULT, 0);
      typeface1 = typeface2;
      if (typeface3 != null) {
        typeface1 = typeface2;
        if (!typeface3.equals(typeface4))
          typeface1 = typeface3; 
      } 
    } 
    return typeface1;
  }
  
  static {
    int i = Build.VERSION.SDK_INT;
    if (i >= 29) {
      a = new d0();
    } else if (i >= 28) {
      a = new o();
    } else if (i >= 26) {
      a = new n();
    } else if (i >= 24 && i.j()) {
      a = new i();
    } else {
      a = new h();
    } 
  }
  
  public static class a extends androidx.core.provider.g.c {
    private h.e a;
    
    public a(h.e param1e) {
      this.a = param1e;
    }
    
    public void a(int param1Int) {
      h.e e1 = this.a;
      if (e1 != null)
        e1.onFontRetrievalFailed(param1Int); 
    }
    
    public void b(Typeface param1Typeface) {
      h.e e1 = this.a;
      if (e1 != null)
        e1.onFontRetrieved(param1Typeface); 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */