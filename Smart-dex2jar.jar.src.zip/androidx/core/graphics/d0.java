package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.Font;
import android.graphics.fonts.FontFamily;
import android.graphics.fonts.FontStyle;
import android.os.CancellationSignal;
import androidx.core.content.res.e;
import androidx.core.provider.g;
import java.io.IOException;

public class d0 extends e0 {
  private Font h(FontFamily paramFontFamily, int paramInt) {
    if ((paramInt & 0x1) != 0) {
      i = 700;
    } else {
      i = 400;
    } 
    int j = 1;
    if ((paramInt & 0x2) != 0) {
      paramInt = 1;
    } else {
      paramInt = 0;
    } 
    FontStyle fontStyle = new FontStyle(i, paramInt);
    Font font = q.a(paramFontFamily, 0);
    int i = i(fontStyle, a0.a(font));
    paramInt = j;
    while (paramInt < r.a(paramFontFamily)) {
      Font font1 = q.a(paramFontFamily, paramInt);
      int k = i(fontStyle, a0.a(font1));
      j = i;
      if (k < i) {
        font = font1;
        j = k;
      } 
      paramInt++;
      i = j;
    } 
    return font;
  }
  
  private static int i(FontStyle paramFontStyle1, FontStyle paramFontStyle2) {
    byte b;
    int i = Math.abs(s.a(paramFontStyle1) - s.a(paramFontStyle2)) / 100;
    if (t.a(paramFontStyle1) == t.a(paramFontStyle2)) {
      b = 0;
    } else {
      b = 2;
    } 
    return i + b;
  }
  
  public Typeface a(Context paramContext, e.c paramc, Resources paramResources, int paramInt) {
    try {
      e.d[] arrayOfD = paramc.a();
      int j = arrayOfD.length;
      paramContext = null;
      int i = 0;
      while (true) {
        FontFamily.Builder builder;
        if (i < j) {
          e.d d = arrayOfD[i];
          try {
            FontFamily.Builder builder1;
            boolean bool;
            Font.Builder builder2 = p.a(new Font.Builder(paramResources, d.b()), d.e());
            if (d.f()) {
              bool = true;
            } else {
              bool = false;
            } 
            Font font = x.a(w.a(v.a(u.a(builder2, bool), d.c()), d.d()));
            if (paramContext == null) {
              builder1 = new FontFamily.Builder(font);
              builder = builder1;
            } else {
              y.a(builder, (Font)builder1);
            } 
          } catch (IOException iOException) {}
          i++;
          continue;
        } 
        if (builder == null)
          return null; 
        FontFamily fontFamily = z.a(builder);
        return c0.a(b0.a(new Typeface.CustomFallbackBuilder(fontFamily), a0.a(h(fontFamily, paramInt))));
      } 
    } catch (Exception exception) {
      return null;
    } 
  }
  
  public Typeface b(Context paramContext, CancellationSignal paramCancellationSignal, g.b[] paramArrayOfb, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: astore #9
    //   6: aload_3
    //   7: arraylength
    //   8: istore #7
    //   10: aconst_null
    //   11: astore_1
    //   12: iconst_0
    //   13: istore #5
    //   15: iload #5
    //   17: iload #7
    //   19: if_icmpge -> 197
    //   22: aload_3
    //   23: iload #5
    //   25: aaload
    //   26: astore #11
    //   28: aload_1
    //   29: astore #8
    //   31: aload #9
    //   33: aload #11
    //   35: invokevirtual d : ()Landroid/net/Uri;
    //   38: ldc 'r'
    //   40: aload_2
    //   41: invokevirtual openFileDescriptor : (Landroid/net/Uri;Ljava/lang/String;Landroid/os/CancellationSignal;)Landroid/os/ParcelFileDescriptor;
    //   44: astore #10
    //   46: aload #10
    //   48: ifnonnull -> 73
    //   51: aload_1
    //   52: astore #8
    //   54: aload #10
    //   56: ifnull -> 185
    //   59: aload_1
    //   60: astore #8
    //   62: aload #10
    //   64: invokevirtual close : ()V
    //   67: aload_1
    //   68: astore #8
    //   70: goto -> 185
    //   73: new android/graphics/fonts/Font$Builder
    //   76: dup
    //   77: aload #10
    //   79: invokespecial <init> : (Landroid/os/ParcelFileDescriptor;)V
    //   82: aload #11
    //   84: invokevirtual e : ()I
    //   87: invokestatic a : (Landroid/graphics/fonts/Font$Builder;I)Landroid/graphics/fonts/Font$Builder;
    //   90: astore #8
    //   92: aload #11
    //   94: invokevirtual f : ()Z
    //   97: ifeq -> 242
    //   100: iconst_1
    //   101: istore #6
    //   103: goto -> 106
    //   106: aload #8
    //   108: iload #6
    //   110: invokestatic a : (Landroid/graphics/fonts/Font$Builder;I)Landroid/graphics/fonts/Font$Builder;
    //   113: aload #11
    //   115: invokevirtual c : ()I
    //   118: invokestatic a : (Landroid/graphics/fonts/Font$Builder;I)Landroid/graphics/fonts/Font$Builder;
    //   121: invokestatic a : (Landroid/graphics/fonts/Font$Builder;)Landroid/graphics/fonts/Font;
    //   124: astore #8
    //   126: aload_1
    //   127: ifnonnull -> 147
    //   130: new android/graphics/fonts/FontFamily$Builder
    //   133: dup
    //   134: aload #8
    //   136: invokespecial <init> : (Landroid/graphics/fonts/Font;)V
    //   139: astore #8
    //   141: aload #8
    //   143: astore_1
    //   144: goto -> 59
    //   147: aload_1
    //   148: aload #8
    //   150: invokestatic a : (Landroid/graphics/fonts/FontFamily$Builder;Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/FontFamily$Builder;
    //   153: pop
    //   154: goto -> 59
    //   157: astore #11
    //   159: aload #10
    //   161: invokevirtual close : ()V
    //   164: goto -> 179
    //   167: astore #10
    //   169: aload_1
    //   170: astore #8
    //   172: aload #11
    //   174: aload #10
    //   176: invokevirtual addSuppressed : (Ljava/lang/Throwable;)V
    //   179: aload_1
    //   180: astore #8
    //   182: aload #11
    //   184: athrow
    //   185: iload #5
    //   187: iconst_1
    //   188: iadd
    //   189: istore #5
    //   191: aload #8
    //   193: astore_1
    //   194: goto -> 15
    //   197: aload_1
    //   198: ifnonnull -> 203
    //   201: aconst_null
    //   202: areturn
    //   203: aload_1
    //   204: invokestatic a : (Landroid/graphics/fonts/FontFamily$Builder;)Landroid/graphics/fonts/FontFamily;
    //   207: astore_1
    //   208: new android/graphics/Typeface$CustomFallbackBuilder
    //   211: dup
    //   212: aload_1
    //   213: invokespecial <init> : (Landroid/graphics/fonts/FontFamily;)V
    //   216: aload_0
    //   217: aload_1
    //   218: iload #4
    //   220: invokespecial h : (Landroid/graphics/fonts/FontFamily;I)Landroid/graphics/fonts/Font;
    //   223: invokestatic a : (Landroid/graphics/fonts/Font;)Landroid/graphics/fonts/FontStyle;
    //   226: invokestatic a : (Landroid/graphics/Typeface$CustomFallbackBuilder;Landroid/graphics/fonts/FontStyle;)Landroid/graphics/Typeface$CustomFallbackBuilder;
    //   229: invokestatic a : (Landroid/graphics/Typeface$CustomFallbackBuilder;)Landroid/graphics/Typeface;
    //   232: astore_1
    //   233: aload_1
    //   234: areturn
    //   235: astore_1
    //   236: aconst_null
    //   237: areturn
    //   238: astore_1
    //   239: goto -> 185
    //   242: iconst_0
    //   243: istore #6
    //   245: goto -> 106
    // Exception table:
    //   from	to	target	type
    //   6	10	235	java/lang/Exception
    //   31	46	238	java/io/IOException
    //   31	46	235	java/lang/Exception
    //   62	67	238	java/io/IOException
    //   62	67	235	java/lang/Exception
    //   73	100	157	finally
    //   106	126	157	finally
    //   130	141	157	finally
    //   147	154	157	finally
    //   159	164	167	finally
    //   172	179	238	java/io/IOException
    //   172	179	235	java/lang/Exception
    //   182	185	238	java/io/IOException
    //   182	185	235	java/lang/Exception
    //   203	233	235	java/lang/Exception
  }
  
  public Typeface d(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    try {
      Font font = x.a(new Font.Builder(paramResources, paramInt1));
      return c0.a(b0.a(new Typeface.CustomFallbackBuilder(z.a(new FontFamily.Builder(font))), a0.a(font)));
    } catch (Exception exception) {
      return null;
    } 
  }
  
  protected g.b g(g.b[] paramArrayOfb, int paramInt) {
    throw new RuntimeException("Do not use this function in API 29 or later.");
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */