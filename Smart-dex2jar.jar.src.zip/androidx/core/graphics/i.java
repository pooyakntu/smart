package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import androidx.collection.g;
import androidx.core.content.res.e;
import androidx.core.provider.g;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.List;

class i extends e0 {
  private static final Class<?> b;
  
  private static final Constructor<?> c;
  
  private static final Method d;
  
  private static final Method e;
  
  static {
    ClassNotFoundException classNotFoundException2;
    ClassNotFoundException classNotFoundException3;
    ClassNotFoundException classNotFoundException4;
    try {
      Class<?> clazz = Class.forName("android.graphics.FontFamily");
      Constructor<?> constructor = clazz.getConstructor(new Class[0]);
      Class<int> clazz1 = int.class;
      Method method2 = clazz.getMethod("addFontWeightStyle", new Class[] { ByteBuffer.class, clazz1, List.class, clazz1, boolean.class });
      Method method1 = Typeface.class.getMethod("createFromFamiliesWithDefault", new Class[] { Array.newInstance(clazz, 1).getClass() });
    } catch (ClassNotFoundException|NoSuchMethodException classNotFoundException1) {
      ClassNotFoundException classNotFoundException = null;
      classNotFoundException2 = null;
      classNotFoundException1 = classNotFoundException2;
      classNotFoundException4 = classNotFoundException1;
      classNotFoundException3 = classNotFoundException1;
      classNotFoundException1 = classNotFoundException;
    } 
    c = (Constructor<?>)classNotFoundException3;
    b = (Class<?>)classNotFoundException1;
    d = (Method)classNotFoundException4;
    e = (Method)classNotFoundException2;
  }
  
  private static boolean h(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, boolean paramBoolean) {
    try {
      return ((Boolean)d.invoke(paramObject, new Object[] { paramByteBuffer, Integer.valueOf(paramInt1), null, Integer.valueOf(paramInt2), Boolean.valueOf(paramBoolean) })).booleanValue();
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return false;
    } 
  }
  
  private static Typeface i(Object paramObject) {
    try {
      Object object = Array.newInstance(b, 1);
      Array.set(object, 0, paramObject);
      return (Typeface)e.invoke(null, new Object[] { object });
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return null;
    } 
  }
  
  public static boolean j() {
    return (d != null);
  }
  
  private static Object k() {
    try {
      return c.newInstance(new Object[0]);
    } catch (IllegalAccessException|InstantiationException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      return null;
    } 
  }
  
  public Typeface a(Context paramContext, e.c paramc, Resources paramResources, int paramInt) {
    Object object = k();
    if (object == null)
      return null; 
    e.d[] arrayOfD = paramc.a();
    int j = arrayOfD.length;
    for (paramInt = 0; paramInt < j; paramInt++) {
      e.d d = arrayOfD[paramInt];
      ByteBuffer byteBuffer = f0.b(paramContext, paramResources, d.b());
      if (byteBuffer == null)
        return null; 
      if (!h(object, byteBuffer, d.c(), d.e(), d.f()))
        return null; 
    } 
    return i(object);
  }
  
  public Typeface b(Context paramContext, CancellationSignal paramCancellationSignal, g.b[] paramArrayOfb, int paramInt) {
    Object object = k();
    if (object == null)
      return null; 
    g g = new g();
    int k = paramArrayOfb.length;
    int j;
    for (j = 0; j < k; j++) {
      g.b b1 = paramArrayOfb[j];
      Uri uri = b1.d();
      ByteBuffer byteBuffer2 = (ByteBuffer)g.get(uri);
      ByteBuffer byteBuffer1 = byteBuffer2;
      if (byteBuffer2 == null) {
        byteBuffer1 = f0.f(paramContext, paramCancellationSignal, uri);
        g.put(uri, byteBuffer1);
      } 
      if (byteBuffer1 == null)
        return null; 
      if (!h(object, byteBuffer1, b1.c(), b1.e(), b1.f()))
        return null; 
    } 
    Typeface typeface = i(object);
    return (typeface == null) ? null : Typeface.create(typeface, paramInt);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */