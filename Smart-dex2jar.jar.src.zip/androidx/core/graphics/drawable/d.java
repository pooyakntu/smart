package androidx.core.graphics.drawable;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import r8.m;

public final class d {
  public static final Bitmap a(Drawable paramDrawable, int paramInt1, int paramInt2, Bitmap.Config paramConfig) {
    Bitmap bitmap1;
    m.j(paramDrawable, "<this>");
    if (paramDrawable instanceof BitmapDrawable) {
      BitmapDrawable bitmapDrawable = (BitmapDrawable)paramDrawable;
      if (bitmapDrawable.getBitmap() != null) {
        if (paramConfig == null || bitmapDrawable.getBitmap().getConfig() == paramConfig) {
          if (paramInt1 == bitmapDrawable.getBitmap().getWidth() && paramInt2 == bitmapDrawable.getBitmap().getHeight()) {
            Bitmap bitmap = bitmapDrawable.getBitmap();
            m.i(bitmap, "bitmap");
            return bitmap;
          } 
          bitmap1 = Bitmap.createScaledBitmap(bitmapDrawable.getBitmap(), paramInt1, paramInt2, true);
          m.i(bitmap1, "createScaledBitmap(bitmap, width, height, true)");
          return bitmap1;
        } 
      } else {
        throw new IllegalArgumentException("bitmap is null");
      } 
    } 
    Rect rect = bitmap1.getBounds();
    m.i(rect, "bounds");
    int i = rect.left;
    int j = rect.top;
    int k = rect.right;
    int m = rect.bottom;
    Bitmap.Config config = paramConfig;
    if (paramConfig == null)
      config = Bitmap.Config.ARGB_8888; 
    Bitmap bitmap2 = Bitmap.createBitmap(paramInt1, paramInt2, config);
    bitmap1.setBounds(0, 0, paramInt1, paramInt2);
    bitmap1.draw(new Canvas(bitmap2));
    bitmap1.setBounds(i, j, k, m);
    m.i(bitmap2, "bitmap");
    return bitmap2;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\drawable\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */