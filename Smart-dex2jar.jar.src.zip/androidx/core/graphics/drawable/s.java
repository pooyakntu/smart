package androidx.core.graphics.drawable;

import android.graphics.drawable.Drawable;

public interface s {
  void a(Drawable paramDrawable);
  
  Drawable b();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\drawable\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */