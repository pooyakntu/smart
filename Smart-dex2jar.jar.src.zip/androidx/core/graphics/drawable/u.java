package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Outline;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.lang.reflect.Method;

class u extends t {
  private static Method n;
  
  u(Drawable paramDrawable) {
    super(paramDrawable);
    g();
  }
  
  u(v paramv, Resources paramResources) {
    super(paramv, paramResources);
    g();
  }
  
  private void g() {
    if (n == null)
      try {
        n = Drawable.class.getDeclaredMethod("isProjected", new Class[0]);
        return;
      } catch (Exception exception) {
        return;
      }  
  }
  
  protected boolean c() {
    int i = Build.VERSION.SDK_INT;
    boolean bool = false;
    null = bool;
    if (i == 21) {
      Drawable drawable = this.l;
      if (!(drawable instanceof android.graphics.drawable.GradientDrawable) && !(drawable instanceof android.graphics.drawable.DrawableContainer) && !(drawable instanceof android.graphics.drawable.InsetDrawable)) {
        null = bool;
        return (drawable instanceof android.graphics.drawable.RippleDrawable) ? true : null;
      } 
    } else {
      return null;
    } 
    return true;
  }
  
  public Rect getDirtyBounds() {
    return this.l.getDirtyBounds();
  }
  
  public void getOutline(Outline paramOutline) {
    this.l.getOutline(paramOutline);
  }
  
  public boolean isProjected() {
    Drawable drawable = this.l;
    if (drawable != null) {
      Method method = n;
      if (method != null)
        try {
          return ((Boolean)method.invoke(drawable, new Object[0])).booleanValue();
        } catch (Exception exception) {
          return false;
        }  
    } 
    return false;
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    this.l.setHotspot(paramFloat1, paramFloat2);
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.l.setHotspotBounds(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean setState(int[] paramArrayOfint) {
    if (super.setState(paramArrayOfint)) {
      invalidateSelf();
      return true;
    } 
    return false;
  }
  
  public void setTint(int paramInt) {
    if (c()) {
      super.setTint(paramInt);
      return;
    } 
    this.l.setTint(paramInt);
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    if (c()) {
      super.setTintList(paramColorStateList);
      return;
    } 
    this.l.setTintList(paramColorStateList);
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    if (c()) {
      super.setTintMode(paramMode);
      return;
    } 
    this.l.setTintMode(paramMode);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\drawabl\\u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */