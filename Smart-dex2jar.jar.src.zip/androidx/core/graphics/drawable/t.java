package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;

class t extends Drawable implements Drawable.Callback, s, r {
  static final PorterDuff.Mode m = PorterDuff.Mode.SRC_IN;
  
  private int g;
  
  private PorterDuff.Mode h;
  
  private boolean i;
  
  v j = d();
  
  private boolean k;
  
  Drawable l;
  
  t(Drawable paramDrawable) {
    a(paramDrawable);
  }
  
  t(v paramv, Resources paramResources) {
    e(paramResources);
  }
  
  private v d() {
    return new v(this.j);
  }
  
  private void e(Resources paramResources) {
    v v1 = this.j;
    if (v1 != null) {
      Drawable.ConstantState constantState = v1.b;
      if (constantState != null)
        a(constantState.newDrawable(paramResources)); 
    } 
  }
  
  private boolean f(int[] paramArrayOfint) {
    if (!c())
      return false; 
    v v1 = this.j;
    ColorStateList colorStateList = v1.c;
    PorterDuff.Mode mode = v1.d;
    if (colorStateList != null && mode != null) {
      int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
      if (!this.i || i != this.g || mode != this.h) {
        setColorFilter(i, mode);
        this.g = i;
        this.h = mode;
        this.i = true;
        return true;
      } 
    } else {
      this.i = false;
      clearColorFilter();
    } 
    return false;
  }
  
  public final void a(Drawable paramDrawable) {
    Drawable drawable = this.l;
    if (drawable != null)
      drawable.setCallback(null); 
    this.l = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback(this);
      setVisible(paramDrawable.isVisible(), true);
      setState(paramDrawable.getState());
      setLevel(paramDrawable.getLevel());
      setBounds(paramDrawable.getBounds());
      v v1 = this.j;
      if (v1 != null)
        v1.b = paramDrawable.getConstantState(); 
    } 
    invalidateSelf();
  }
  
  public final Drawable b() {
    return this.l;
  }
  
  protected boolean c() {
    throw null;
  }
  
  public void draw(Canvas paramCanvas) {
    this.l.draw(paramCanvas);
  }
  
  public int getChangingConfigurations() {
    byte b;
    int i = super.getChangingConfigurations();
    v v1 = this.j;
    if (v1 != null) {
      b = v1.getChangingConfigurations();
    } else {
      b = 0;
    } 
    return i | b | this.l.getChangingConfigurations();
  }
  
  public Drawable.ConstantState getConstantState() {
    v v1 = this.j;
    if (v1 != null && v1.a()) {
      this.j.a = getChangingConfigurations();
      return this.j;
    } 
    return null;
  }
  
  public Drawable getCurrent() {
    return this.l.getCurrent();
  }
  
  public int getIntrinsicHeight() {
    return this.l.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return this.l.getIntrinsicWidth();
  }
  
  public int getLayoutDirection() {
    return a.f(this.l);
  }
  
  public int getMinimumHeight() {
    return this.l.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return this.l.getMinimumWidth();
  }
  
  public int getOpacity() {
    return this.l.getOpacity();
  }
  
  public boolean getPadding(Rect paramRect) {
    return this.l.getPadding(paramRect);
  }
  
  public int[] getState() {
    return this.l.getState();
  }
  
  public Region getTransparentRegion() {
    return this.l.getTransparentRegion();
  }
  
  public void invalidateDrawable(Drawable paramDrawable) {
    invalidateSelf();
  }
  
  public boolean isAutoMirrored() {
    return a.h(this.l);
  }
  
  public boolean isStateful() {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual c : ()Z
    //   4: ifeq -> 24
    //   7: aload_0
    //   8: getfield j : Landroidx/core/graphics/drawable/v;
    //   11: astore_1
    //   12: aload_1
    //   13: ifnull -> 24
    //   16: aload_1
    //   17: getfield c : Landroid/content/res/ColorStateList;
    //   20: astore_1
    //   21: goto -> 26
    //   24: aconst_null
    //   25: astore_1
    //   26: aload_1
    //   27: ifnull -> 37
    //   30: aload_1
    //   31: invokevirtual isStateful : ()Z
    //   34: ifne -> 47
    //   37: aload_0
    //   38: getfield l : Landroid/graphics/drawable/Drawable;
    //   41: invokevirtual isStateful : ()Z
    //   44: ifeq -> 49
    //   47: iconst_1
    //   48: ireturn
    //   49: iconst_0
    //   50: ireturn
  }
  
  public void jumpToCurrentState() {
    this.l.jumpToCurrentState();
  }
  
  public Drawable mutate() {
    if (!this.k && super.mutate() == this) {
      this.j = d();
      Drawable drawable = this.l;
      if (drawable != null)
        drawable.mutate(); 
      v v1 = this.j;
      if (v1 != null) {
        drawable = this.l;
        if (drawable != null) {
          Drawable.ConstantState constantState = drawable.getConstantState();
        } else {
          drawable = null;
        } 
        v1.b = (Drawable.ConstantState)drawable;
      } 
      this.k = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    Drawable drawable = this.l;
    if (drawable != null)
      drawable.setBounds(paramRect); 
  }
  
  public boolean onLayoutDirectionChanged(int paramInt) {
    return a.m(this.l, paramInt);
  }
  
  protected boolean onLevelChange(int paramInt) {
    return this.l.setLevel(paramInt);
  }
  
  public void scheduleDrawable(Drawable paramDrawable, Runnable paramRunnable, long paramLong) {
    scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    this.l.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    a.j(this.l, paramBoolean);
  }
  
  public void setChangingConfigurations(int paramInt) {
    this.l.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.l.setColorFilter(paramColorFilter);
  }
  
  public void setDither(boolean paramBoolean) {
    this.l.setDither(paramBoolean);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    this.l.setFilterBitmap(paramBoolean);
  }
  
  public boolean setState(int[] paramArrayOfint) {
    boolean bool = this.l.setState(paramArrayOfint);
    return (f(paramArrayOfint) || bool);
  }
  
  public void setTint(int paramInt) {
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    this.j.c = paramColorStateList;
    f(getState());
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    this.j.d = paramMode;
    f(getState());
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    return (super.setVisible(paramBoolean1, paramBoolean2) || this.l.setVisible(paramBoolean1, paramBoolean2));
  }
  
  public void unscheduleDrawable(Drawable paramDrawable, Runnable paramRunnable) {
    unscheduleSelf(paramRunnable);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\graphics\drawable\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */