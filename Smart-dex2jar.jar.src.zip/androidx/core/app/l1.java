package androidx.core.app;

import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;

public final class l1 {
  static RemoteInput a(l1 paraml1) {
    return a.b(paraml1);
  }
  
  static RemoteInput[] b(l1[] paramArrayOfl1) {
    if (paramArrayOfl1 == null)
      return null; 
    RemoteInput[] arrayOfRemoteInput = new RemoteInput[paramArrayOfl1.length];
    for (int i = 0; i < paramArrayOfl1.length; i++) {
      l1 l11 = paramArrayOfl1[i];
      arrayOfRemoteInput[i] = a(null);
    } 
    return arrayOfRemoteInput;
  }
  
  static class a {
    static void a(Object param1Object, Intent param1Intent, Bundle param1Bundle) {
      RemoteInput.addResultsToIntent((RemoteInput[])param1Object, param1Intent, param1Bundle);
    }
    
    public static RemoteInput b(l1 param1l1) {
      throw null;
    }
    
    static Bundle c(Intent param1Intent) {
      return RemoteInput.getResultsFromIntent(param1Intent);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\l1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */