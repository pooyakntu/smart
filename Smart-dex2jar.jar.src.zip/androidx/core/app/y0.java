package androidx.core.app;

import android.app.Person;



/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\y0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */