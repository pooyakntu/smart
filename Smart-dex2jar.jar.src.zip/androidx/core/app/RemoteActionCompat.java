package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import w0.a;

public final class RemoteActionCompat implements a {
  public IconCompat a;
  
  public CharSequence b;
  
  public CharSequence c;
  
  public PendingIntent d;
  
  public boolean e;
  
  public boolean f;
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\RemoteActionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */