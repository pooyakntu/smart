package androidx.core.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import t.h;

public class s {
  public static Bundle a(Notification paramNotification) {
    return paramNotification.extras;
  }
  
  public static class a {
    final Bundle a;
    
    private IconCompat b;
    
    private final l1[] c;
    
    private final l1[] d;
    
    private boolean e;
    
    boolean f = true;
    
    private final int g;
    
    private final boolean h;
    
    @Deprecated
    public int i;
    
    public CharSequence j;
    
    public PendingIntent k;
    
    private boolean l;
    
    public a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(iconCompat, param1CharSequence, param1PendingIntent);
    }
    
    public a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1IconCompat, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true, 0, true, false, false);
    }
    
    a(IconCompat param1IconCompat, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, l1[] param1ArrayOfl11, l1[] param1ArrayOfl12, boolean param1Boolean1, int param1Int, boolean param1Boolean2, boolean param1Boolean3, boolean param1Boolean4) {
      this.b = param1IconCompat;
      if (param1IconCompat != null && param1IconCompat.o() == 2)
        this.i = param1IconCompat.l(); 
      this.j = s.e.k(param1CharSequence);
      this.k = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.c = param1ArrayOfl11;
      this.d = param1ArrayOfl12;
      this.e = param1Boolean1;
      this.g = param1Int;
      this.f = param1Boolean2;
      this.h = param1Boolean3;
      this.l = param1Boolean4;
    }
    
    public PendingIntent a() {
      return this.k;
    }
    
    public boolean b() {
      return this.e;
    }
    
    public Bundle c() {
      return this.a;
    }
    
    public IconCompat d() {
      if (this.b == null) {
        int i = this.i;
        if (i != 0)
          this.b = IconCompat.j(null, "", i); 
      } 
      return this.b;
    }
    
    public l1[] e() {
      return this.c;
    }
    
    public int f() {
      return this.g;
    }
    
    public boolean g() {
      return this.f;
    }
    
    public CharSequence h() {
      return this.j;
    }
    
    public boolean i() {
      return this.l;
    }
    
    public boolean j() {
      return this.h;
    }
  }
  
  public static class b extends g {
    private IconCompat e;
    
    private IconCompat f;
    
    private boolean g;
    
    private CharSequence h;
    
    private boolean i;
    
    public void b(r param1r) {
      int i = Build.VERSION.SDK_INT;
      Notification.BigPictureStyle bigPictureStyle2 = (new Notification.BigPictureStyle(param1r.a())).setBigContentTitle(this.b);
      IconCompat iconCompat = this.e;
      Context context = null;
      Notification.BigPictureStyle bigPictureStyle1 = bigPictureStyle2;
      if (iconCompat != null)
        if (i >= 31) {
          if (param1r instanceof r0) {
            Context context1 = ((r0)param1r).f();
          } else {
            bigPictureStyle1 = null;
          } 
          c.a(bigPictureStyle2, this.e.y((Context)bigPictureStyle1));
          bigPictureStyle1 = bigPictureStyle2;
        } else {
          bigPictureStyle1 = bigPictureStyle2;
          if (iconCompat.o() == 1)
            bigPictureStyle1 = bigPictureStyle2.bigPicture(this.e.k()); 
        }  
      if (this.g) {
        IconCompat iconCompat1 = this.f;
        if (iconCompat1 == null) {
          a.a(bigPictureStyle1, null);
        } else if (i >= 23) {
          if (param1r instanceof r0)
            context = ((r0)param1r).f(); 
          b.a(bigPictureStyle1, this.f.y(context));
        } else if (iconCompat1.o() == 1) {
          a.a(bigPictureStyle1, this.f.k());
        } else {
          a.a(bigPictureStyle1, null);
        } 
      } 
      if (this.d)
        a.b(bigPictureStyle1, this.c); 
      if (i >= 31) {
        c.c(bigPictureStyle1, this.i);
        c.b(bigPictureStyle1, this.h);
      } 
    }
    
    protected String k() {
      return "androidx.core.app.NotificationCompat$BigPictureStyle";
    }
    
    public b q(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.f(param1Bitmap);
      } 
      this.f = iconCompat;
      this.g = true;
      return this;
    }
    
    public b r(Bitmap param1Bitmap) {
      IconCompat iconCompat;
      if (param1Bitmap == null) {
        param1Bitmap = null;
      } else {
        iconCompat = IconCompat.f(param1Bitmap);
      } 
      this.e = iconCompat;
      return this;
    }
    
    private static class a {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Bitmap param2Bitmap) {
        param2BigPictureStyle.bigLargeIcon(param2Bitmap);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        param2BigPictureStyle.setSummaryText(param2CharSequence);
      }
    }
    
    private static class b {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        t.a(param2BigPictureStyle, param2Icon);
      }
    }
    
    private static class c {
      static void a(Notification.BigPictureStyle param2BigPictureStyle, Icon param2Icon) {
        v.a(param2BigPictureStyle, param2Icon);
      }
      
      static void b(Notification.BigPictureStyle param2BigPictureStyle, CharSequence param2CharSequence) {
        w.a(param2BigPictureStyle, param2CharSequence);
      }
      
      static void c(Notification.BigPictureStyle param2BigPictureStyle, boolean param2Boolean) {
        u.a(param2BigPictureStyle, param2Boolean);
      }
    }
  }
  
  private static class a {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Bitmap param1Bitmap) {
      param1BigPictureStyle.bigLargeIcon(param1Bitmap);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      param1BigPictureStyle.setSummaryText(param1CharSequence);
    }
  }
  
  private static class b {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      t.a(param1BigPictureStyle, param1Icon);
    }
  }
  
  private static class c {
    static void a(Notification.BigPictureStyle param1BigPictureStyle, Icon param1Icon) {
      v.a(param1BigPictureStyle, param1Icon);
    }
    
    static void b(Notification.BigPictureStyle param1BigPictureStyle, CharSequence param1CharSequence) {
      w.a(param1BigPictureStyle, param1CharSequence);
    }
    
    static void c(Notification.BigPictureStyle param1BigPictureStyle, boolean param1Boolean) {
      u.a(param1BigPictureStyle, param1Boolean);
    }
  }
  
  public static class c extends g {
    private CharSequence e;
    
    public void a(Bundle param1Bundle) {
      super.a(param1Bundle);
    }
    
    public void b(r param1r) {
      Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1r.a())).setBigContentTitle(this.b).bigText(this.e);
      if (this.d)
        bigTextStyle.setSummaryText(this.c); 
    }
    
    protected String k() {
      return "androidx.core.app.NotificationCompat$BigTextStyle";
    }
    
    public c q(CharSequence param1CharSequence) {
      this.e = s.e.k(param1CharSequence);
      return this;
    }
  }
  
  public static final class d {
    public static Notification.BubbleMetadata a(d param1d) {
      return null;
    }
  }
  
  public static class e {
    boolean A = false;
    
    boolean B;
    
    boolean C;
    
    String D;
    
    Bundle E;
    
    int F = 0;
    
    int G = 0;
    
    Notification H;
    
    RemoteViews I;
    
    RemoteViews J;
    
    RemoteViews K;
    
    String L;
    
    int M = 0;
    
    String N;
    
    long O;
    
    int P = 0;
    
    int Q = 0;
    
    boolean R;
    
    Notification S;
    
    boolean T;
    
    Icon U;
    
    @Deprecated
    public ArrayList<String> V;
    
    public Context a;
    
    public ArrayList<s.a> b = new ArrayList<s.a>();
    
    public ArrayList<j1> c = new ArrayList<j1>();
    
    ArrayList<s.a> d = new ArrayList<s.a>();
    
    CharSequence e;
    
    CharSequence f;
    
    PendingIntent g;
    
    PendingIntent h;
    
    RemoteViews i;
    
    Bitmap j;
    
    CharSequence k;
    
    int l;
    
    int m;
    
    boolean n = true;
    
    boolean o;
    
    boolean p;
    
    s.g q;
    
    CharSequence r;
    
    CharSequence s;
    
    CharSequence[] t;
    
    int u;
    
    int v;
    
    boolean w;
    
    String x;
    
    boolean y;
    
    String z;
    
    @Deprecated
    public e(Context param1Context) {
      this(param1Context, null);
    }
    
    public e(Context param1Context, String param1String) {
      Notification notification = new Notification();
      this.S = notification;
      this.a = param1Context;
      this.L = param1String;
      notification.when = System.currentTimeMillis();
      this.S.audioStreamType = -1;
      this.m = 0;
      this.V = new ArrayList<String>();
      this.R = true;
    }
    
    protected static CharSequence k(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      CharSequence charSequence = param1CharSequence;
      if (param1CharSequence.length() > 5120)
        charSequence = param1CharSequence.subSequence(0, 5120); 
      return charSequence;
    }
    
    private Bitmap l(Bitmap param1Bitmap) {
      Bitmap bitmap = param1Bitmap;
      if (param1Bitmap != null) {
        if (Build.VERSION.SDK_INT >= 27)
          return param1Bitmap; 
        Resources resources = this.a.getResources();
        int i = resources.getDimensionPixelSize(t.c.b);
        int j = resources.getDimensionPixelSize(t.c.a);
        if (param1Bitmap.getWidth() <= i && param1Bitmap.getHeight() <= j)
          return param1Bitmap; 
        double d = Math.min(i / Math.max(1, param1Bitmap.getWidth()), j / Math.max(1, param1Bitmap.getHeight()));
        bitmap = Bitmap.createScaledBitmap(param1Bitmap, (int)Math.ceil(param1Bitmap.getWidth() * d), (int)Math.ceil(param1Bitmap.getHeight() * d), true);
      } 
      return bitmap;
    }
    
    private void x(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.S;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.S;
      notification.flags = param1Int & notification.flags;
    }
    
    public e A(int param1Int1, int param1Int2, int param1Int3) {
      Notification notification = this.S;
      notification.ledARGB = param1Int1;
      notification.ledOnMS = param1Int2;
      notification.ledOffMS = param1Int3;
      if (param1Int2 != 0 && param1Int3 != 0) {
        param1Int1 = 1;
      } else {
        param1Int1 = 0;
      } 
      notification.flags = param1Int1 | notification.flags & 0xFFFFFFFE;
      return this;
    }
    
    public e B(boolean param1Boolean) {
      this.A = param1Boolean;
      return this;
    }
    
    public e C(int param1Int) {
      this.l = param1Int;
      return this;
    }
    
    public e D(boolean param1Boolean) {
      x(2, param1Boolean);
      return this;
    }
    
    public e E(int param1Int) {
      this.m = param1Int;
      return this;
    }
    
    public e F(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.u = param1Int1;
      this.v = param1Int2;
      this.w = param1Boolean;
      return this;
    }
    
    public e G(boolean param1Boolean) {
      this.n = param1Boolean;
      return this;
    }
    
    public e H(int param1Int) {
      this.S.icon = param1Int;
      return this;
    }
    
    public e I(Uri param1Uri) {
      Notification notification = this.S;
      notification.sound = param1Uri;
      notification.audioStreamType = -1;
      notification.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build();
      return this;
    }
    
    public e J(s.g param1g) {
      if (this.q != param1g) {
        this.q = param1g;
        if (param1g != null)
          param1g.p(this); 
      } 
      return this;
    }
    
    public e K(CharSequence param1CharSequence) {
      this.r = k(param1CharSequence);
      return this;
    }
    
    public e L(CharSequence param1CharSequence) {
      this.S.tickerText = k(param1CharSequence);
      return this;
    }
    
    public e M(long[] param1ArrayOflong) {
      this.S.vibrate = param1ArrayOflong;
      return this;
    }
    
    public e N(int param1Int) {
      this.G = param1Int;
      return this;
    }
    
    public e O(long param1Long) {
      this.S.when = param1Long;
      return this;
    }
    
    public e a(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.b.add(new s.a(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public e b(s.a param1a) {
      if (param1a != null)
        this.b.add(param1a); 
      return this;
    }
    
    public Notification c() {
      return (new r0(this)).c();
    }
    
    public RemoteViews d() {
      return this.J;
    }
    
    public int e() {
      return this.F;
    }
    
    public RemoteViews f() {
      return this.I;
    }
    
    public Bundle g() {
      if (this.E == null)
        this.E = new Bundle(); 
      return this.E;
    }
    
    public RemoteViews h() {
      return this.K;
    }
    
    public int i() {
      return this.m;
    }
    
    public long j() {
      return this.n ? this.S.when : 0L;
    }
    
    public e m(boolean param1Boolean) {
      x(16, param1Boolean);
      return this;
    }
    
    public e n(String param1String) {
      this.L = param1String;
      return this;
    }
    
    public e o(int param1Int) {
      this.F = param1Int;
      return this;
    }
    
    public e p(boolean param1Boolean) {
      this.B = param1Boolean;
      this.C = true;
      return this;
    }
    
    public e q(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public e r(CharSequence param1CharSequence) {
      this.f = k(param1CharSequence);
      return this;
    }
    
    public e s(CharSequence param1CharSequence) {
      this.e = k(param1CharSequence);
      return this;
    }
    
    public e t(RemoteViews param1RemoteViews) {
      this.J = param1RemoteViews;
      return this;
    }
    
    public e u(RemoteViews param1RemoteViews) {
      this.I = param1RemoteViews;
      return this;
    }
    
    public e v(int param1Int) {
      Notification notification = this.S;
      notification.defaults = param1Int;
      if ((param1Int & 0x4) != 0)
        notification.flags |= 0x1; 
      return this;
    }
    
    public e w(PendingIntent param1PendingIntent) {
      this.S.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public e y(boolean param1Boolean) {
      this.y = param1Boolean;
      return this;
    }
    
    public e z(Bitmap param1Bitmap) {
      this.j = l(param1Bitmap);
      return this;
    }
  }
  
  public static class f extends g {
    private RemoteViews q(RemoteViews param1RemoteViews, boolean param1Boolean) {
      // Byte code:
      //   0: getstatic t/g.c : I
      //   3: istore_3
      //   4: iconst_1
      //   5: istore #6
      //   7: iconst_0
      //   8: istore #5
      //   10: aload_0
      //   11: iconst_1
      //   12: iload_3
      //   13: iconst_0
      //   14: invokevirtual c : (ZIZ)Landroid/widget/RemoteViews;
      //   17: astore #8
      //   19: aload #8
      //   21: getstatic t/e.L : I
      //   24: invokevirtual removeAllViews : (I)V
      //   27: aload_0
      //   28: getfield a : Landroidx/core/app/s$e;
      //   31: getfield b : Ljava/util/ArrayList;
      //   34: invokestatic s : (Ljava/util/List;)Ljava/util/List;
      //   37: astore #9
      //   39: iload_2
      //   40: ifeq -> 112
      //   43: aload #9
      //   45: ifnull -> 112
      //   48: aload #9
      //   50: invokeinterface size : ()I
      //   55: iconst_3
      //   56: invokestatic min : (II)I
      //   59: istore #7
      //   61: iload #7
      //   63: ifle -> 112
      //   66: iconst_0
      //   67: istore_3
      //   68: iload #6
      //   70: istore #4
      //   72: iload_3
      //   73: iload #7
      //   75: if_icmpge -> 115
      //   78: aload_0
      //   79: aload #9
      //   81: iload_3
      //   82: invokeinterface get : (I)Ljava/lang/Object;
      //   87: checkcast androidx/core/app/s$a
      //   90: invokespecial r : (Landroidx/core/app/s$a;)Landroid/widget/RemoteViews;
      //   93: astore #10
      //   95: aload #8
      //   97: getstatic t/e.L : I
      //   100: aload #10
      //   102: invokevirtual addView : (ILandroid/widget/RemoteViews;)V
      //   105: iload_3
      //   106: iconst_1
      //   107: iadd
      //   108: istore_3
      //   109: goto -> 68
      //   112: iconst_0
      //   113: istore #4
      //   115: iload #4
      //   117: ifeq -> 126
      //   120: iload #5
      //   122: istore_3
      //   123: goto -> 129
      //   126: bipush #8
      //   128: istore_3
      //   129: aload #8
      //   131: getstatic t/e.L : I
      //   134: iload_3
      //   135: invokevirtual setViewVisibility : (II)V
      //   138: aload #8
      //   140: getstatic t/e.I : I
      //   143: iload_3
      //   144: invokevirtual setViewVisibility : (II)V
      //   147: aload_0
      //   148: aload #8
      //   150: aload_1
      //   151: invokevirtual d : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   154: aload #8
      //   156: areturn
    }
    
    private RemoteViews r(s.a param1a) {
      boolean bool;
      int i;
      if (param1a.k == null) {
        bool = true;
      } else {
        bool = false;
      } 
      String str = this.a.a.getPackageName();
      if (bool) {
        i = t.g.b;
      } else {
        i = t.g.a;
      } 
      RemoteViews remoteViews = new RemoteViews(str, i);
      IconCompat iconCompat = param1a.d();
      if (iconCompat != null)
        remoteViews.setImageViewBitmap(t.e.J, h(iconCompat, this.a.a.getResources().getColor(t.b.a))); 
      remoteViews.setTextViewText(t.e.K, param1a.j);
      if (!bool)
        remoteViews.setOnClickPendingIntent(t.e.H, param1a.k); 
      remoteViews.setContentDescription(t.e.H, param1a.j);
      return remoteViews;
    }
    
    private static List<s.a> s(List<s.a> param1List) {
      if (param1List == null)
        return null; 
      ArrayList<s.a> arrayList = new ArrayList();
      for (s.a a : param1List) {
        if (!a.j())
          arrayList.add(a); 
      } 
      return arrayList;
    }
    
    public void b(r param1r) {
      if (Build.VERSION.SDK_INT >= 24)
        param1r.a().setStyle((Notification.Style)new Notification.DecoratedCustomViewStyle()); 
    }
    
    protected String k() {
      return "androidx.core.app.NotificationCompat$DecoratedCustomViewStyle";
    }
    
    public RemoteViews m(r param1r) {
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews = this.a.d();
      if (remoteViews == null)
        remoteViews = this.a.f(); 
      return (remoteViews == null) ? null : q(remoteViews, true);
    }
    
    public RemoteViews n(r param1r) {
      return (Build.VERSION.SDK_INT >= 24) ? null : ((this.a.f() == null) ? null : q(this.a.f(), false));
    }
    
    public RemoteViews o(r param1r) {
      RemoteViews remoteViews1;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews2 = this.a.h();
      if (remoteViews2 != null) {
        remoteViews1 = remoteViews2;
      } else {
        remoteViews1 = this.a.f();
      } 
      return (remoteViews2 == null) ? null : q(remoteViews1, true);
    }
  }
  
  public static abstract class g {
    protected s.e a;
    
    CharSequence b;
    
    CharSequence c;
    
    boolean d = false;
    
    private int e() {
      Resources resources = this.a.a.getResources();
      int i = resources.getDimensionPixelSize(t.c.i);
      int j = resources.getDimensionPixelSize(t.c.j);
      float f = (f((resources.getConfiguration()).fontScale, 1.0F, 1.3F) - 1.0F) / 0.29999995F;
      return Math.round((1.0F - f) * i + f * j);
    }
    
    private static float f(float param1Float1, float param1Float2, float param1Float3) {
      if (param1Float1 < param1Float2)
        return param1Float2; 
      param1Float2 = param1Float1;
      if (param1Float1 > param1Float3)
        param1Float2 = param1Float3; 
      return param1Float2;
    }
    
    private Bitmap g(int param1Int1, int param1Int2, int param1Int3) {
      return i(IconCompat.i(this.a.a, param1Int1), param1Int2, param1Int3);
    }
    
    private Bitmap i(IconCompat param1IconCompat, int param1Int1, int param1Int2) {
      int i;
      Drawable drawable = param1IconCompat.r(this.a.a);
      if (param1Int2 == 0) {
        i = drawable.getIntrinsicWidth();
      } else {
        i = param1Int2;
      } 
      int j = param1Int2;
      if (param1Int2 == 0)
        j = drawable.getIntrinsicHeight(); 
      Bitmap bitmap = Bitmap.createBitmap(i, j, Bitmap.Config.ARGB_8888);
      drawable.setBounds(0, 0, i, j);
      if (param1Int1 != 0)
        drawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(param1Int1, PorterDuff.Mode.SRC_IN)); 
      drawable.draw(new Canvas(bitmap));
      return bitmap;
    }
    
    private Bitmap j(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      int j = t.d.a;
      int i = param1Int4;
      if (param1Int4 == 0)
        i = 0; 
      Bitmap bitmap = g(j, i, param1Int2);
      Canvas canvas = new Canvas(bitmap);
      Drawable drawable = this.a.a.getResources().getDrawable(param1Int1).mutate();
      drawable.setFilterBitmap(true);
      param1Int1 = (param1Int2 - param1Int3) / 2;
      param1Int2 = param1Int3 + param1Int1;
      drawable.setBounds(param1Int1, param1Int1, param1Int2, param1Int2);
      drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
      drawable.draw(canvas);
      return bitmap;
    }
    
    private void l(RemoteViews param1RemoteViews) {
      param1RemoteViews.setViewVisibility(t.e.k0, 8);
      param1RemoteViews.setViewVisibility(t.e.i0, 8);
      param1RemoteViews.setViewVisibility(t.e.h0, 8);
    }
    
    public void a(Bundle param1Bundle) {
      if (this.d)
        param1Bundle.putCharSequence("android.summaryText", this.c); 
      CharSequence charSequence = this.b;
      if (charSequence != null)
        param1Bundle.putCharSequence("android.title.big", charSequence); 
      charSequence = k();
      if (charSequence != null)
        param1Bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", (String)charSequence); 
    }
    
    public abstract void b(r param1r);
    
    public RemoteViews c(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      Bitmap bitmap1;
      Resources resources = this.a.a.getResources();
      RemoteViews remoteViews = new RemoteViews(this.a.a.getPackageName(), param1Int);
      this.a.i();
      int i = Build.VERSION.SDK_INT;
      s.e e2 = this.a;
      Bitmap bitmap2 = e2.j;
      boolean bool2 = false;
      if (bitmap2 != null) {
        param1Int = t.e.N;
        remoteViews.setViewVisibility(param1Int, 0);
        remoteViews.setImageViewBitmap(param1Int, this.a.j);
        if (param1Boolean1 && this.a.S.icon != 0) {
          param1Int = resources.getDimensionPixelSize(t.c.e);
          int j = resources.getDimensionPixelSize(t.c.f);
          e2 = this.a;
          bitmap1 = j(e2.S.icon, param1Int, param1Int - j * 2, e2.e());
          param1Int = t.e.T;
          remoteViews.setImageViewBitmap(param1Int, bitmap1);
          remoteViews.setViewVisibility(param1Int, 0);
        } 
      } else if (param1Boolean1 && ((s.e)bitmap1).S.icon != 0) {
        param1Int = t.e.N;
        remoteViews.setViewVisibility(param1Int, 0);
        int j = resources.getDimensionPixelSize(t.c.d);
        int k = resources.getDimensionPixelSize(t.c.c);
        int m = resources.getDimensionPixelSize(t.c.g);
        s.e e3 = this.a;
        remoteViews.setImageViewBitmap(param1Int, j(e3.S.icon, j - k, m, e3.e()));
      } 
      CharSequence charSequence2 = this.a.e;
      if (charSequence2 != null)
        remoteViews.setTextViewText(t.e.k0, charSequence2); 
      charSequence2 = this.a.f;
      boolean bool3 = true;
      if (charSequence2 != null) {
        remoteViews.setTextViewText(t.e.h0, charSequence2);
        param1Int = 1;
      } else {
        param1Int = 0;
      } 
      s.e e1 = this.a;
      CharSequence charSequence3 = e1.k;
      if (charSequence3 != null) {
        param1Int = t.e.O;
        remoteViews.setTextViewText(param1Int, charSequence3);
        remoteViews.setViewVisibility(param1Int, 0);
      } else if (e1.l > 0) {
        param1Int = resources.getInteger(t.f.a);
        if (this.a.l > param1Int) {
          remoteViews.setTextViewText(t.e.O, resources.getString(h.a));
        } else {
          NumberFormat numberFormat = NumberFormat.getIntegerInstance();
          remoteViews.setTextViewText(t.e.O, numberFormat.format(this.a.l));
        } 
        remoteViews.setViewVisibility(t.e.O, 0);
      } else {
        remoteViews.setViewVisibility(t.e.O, 8);
        boolean bool = false;
        int j = param1Int;
        param1Int = bool;
        CharSequence charSequence = this.a.r;
      } 
      boolean bool1 = true;
      param1Int = 1;
      CharSequence charSequence1 = this.a.r;
    }
    
    public void d(RemoteViews param1RemoteViews1, RemoteViews param1RemoteViews2) {
      l(param1RemoteViews1);
      int i = t.e.R;
      param1RemoteViews1.removeAllViews(i);
      param1RemoteViews1.addView(i, param1RemoteViews2.clone());
      param1RemoteViews1.setViewVisibility(i, 0);
      param1RemoteViews1.setViewPadding(t.e.S, 0, e(), 0, 0);
    }
    
    Bitmap h(IconCompat param1IconCompat, int param1Int) {
      return i(param1IconCompat, param1Int, 0);
    }
    
    protected abstract String k();
    
    public RemoteViews m(r param1r) {
      return null;
    }
    
    public RemoteViews n(r param1r) {
      return null;
    }
    
    public RemoteViews o(r param1r) {
      return null;
    }
    
    public void p(s.e param1e) {
      if (this.a != param1e) {
        this.a = param1e;
        if (param1e != null)
          param1e.J(this); 
      } 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */