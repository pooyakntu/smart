package androidx.core.app;

import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.text.Html;
import java.util.ArrayList;

class m1 {
  static String a(CharSequence paramCharSequence) {
    return Html.escapeHtml(paramCharSequence);
  }
  
  static void b(Intent paramIntent, ArrayList<Uri> paramArrayList) {
    CharSequence charSequence = paramIntent.getCharSequenceExtra("android.intent.extra.TEXT");
    String str2 = paramIntent.getStringExtra("android.intent.extra.HTML_TEXT");
    String str1 = paramIntent.getType();
    ClipData.Item item = new ClipData.Item(charSequence, str2, null, paramArrayList.get(0));
    ClipData clipData = new ClipData(null, new String[] { str1 }, item);
    int j = paramArrayList.size();
    for (int i = 1; i < j; i++)
      clipData.addItem(new ClipData.Item(paramArrayList.get(i))); 
    paramIntent.setClipData(clipData);
    paramIntent.addFlags(1);
  }
  
  static void c(Intent paramIntent) {
    paramIntent.setClipData(null);
    paramIntent.setFlags(paramIntent.getFlags() & 0xFFFFFFFE);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\m1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */