package androidx.core.app;

import android.app.Person;
import android.graphics.drawable.Icon;
import androidx.core.graphics.drawable.IconCompat;

public class j1 {
  CharSequence a;
  
  IconCompat b;
  
  String c;
  
  String d;
  
  boolean e;
  
  boolean f;
  
  j1(b paramb) {
    this.a = paramb.a;
    this.b = paramb.b;
    this.c = paramb.c;
    this.d = paramb.d;
    this.e = paramb.e;
    this.f = paramb.f;
  }
  
  public IconCompat a() {
    return this.b;
  }
  
  public String b() {
    return this.d;
  }
  
  public CharSequence c() {
    return this.a;
  }
  
  public String d() {
    return this.c;
  }
  
  public boolean e() {
    return this.e;
  }
  
  public boolean f() {
    return this.f;
  }
  
  public String g() {
    String str = this.c;
    if (str != null)
      return str; 
    if (this.a != null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("name:");
      stringBuilder.append(this.a);
      return stringBuilder.toString();
    } 
    return "";
  }
  
  public Person h() {
    return a.b(this);
  }
  
  static class a {
    static j1 a(Person param1Person) {
      IconCompat iconCompat;
      j1.b b = (new j1.b()).f(g1.a(param1Person));
      if (h1.a(param1Person) != null) {
        iconCompat = IconCompat.b(h1.a(param1Person));
      } else {
        iconCompat = null;
      } 
      return b.c(iconCompat).g(i1.a(param1Person)).e(x0.a(param1Person)).b(y0.a(param1Person)).d(z0.a(param1Person)).a();
    }
    
    static Person b(j1 param1j1) {
      Icon icon;
      Person.Builder builder = w0.a(new Person.Builder(), param1j1.c());
      if (param1j1.a() != null) {
        icon = param1j1.a().x();
      } else {
        icon = null;
      } 
      return f1.a(e1.a(d1.a(c1.a(b1.a(a1.a(builder, icon), param1j1.d()), param1j1.b()), param1j1.e()), param1j1.f()));
    }
  }
  
  public static class b {
    CharSequence a;
    
    IconCompat b;
    
    String c;
    
    String d;
    
    boolean e;
    
    boolean f;
    
    public j1 a() {
      return new j1(this);
    }
    
    public b b(boolean param1Boolean) {
      this.e = param1Boolean;
      return this;
    }
    
    public b c(IconCompat param1IconCompat) {
      this.b = param1IconCompat;
      return this;
    }
    
    public b d(boolean param1Boolean) {
      this.f = param1Boolean;
      return this;
    }
    
    public b e(String param1String) {
      this.d = param1String;
      return this;
    }
    
    public b f(CharSequence param1CharSequence) {
      this.a = param1CharSequence;
      return this;
    }
    
    public b g(String param1String) {
      this.c = param1String;
      return this;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\j1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */