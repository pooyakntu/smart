package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;

public final class p1 implements Iterable<Intent> {
  private final ArrayList<Intent> g = new ArrayList<Intent>();
  
  private final Context h;
  
  private p1(Context paramContext) {
    this.h = paramContext;
  }
  
  public static p1 d(Context paramContext) {
    return new p1(paramContext);
  }
  
  public p1 a(Intent paramIntent) {
    this.g.add(paramIntent);
    return this;
  }
  
  public p1 b(Activity paramActivity) {
    Intent intent1;
    if (paramActivity instanceof a) {
      intent1 = ((a)paramActivity).getSupportParentActivityIntent();
    } else {
      intent1 = null;
    } 
    Intent intent2 = intent1;
    if (intent1 == null)
      intent2 = q.a(paramActivity); 
    if (intent2 != null) {
      ComponentName componentName2 = intent2.getComponent();
      ComponentName componentName1 = componentName2;
      if (componentName2 == null)
        componentName1 = intent2.resolveActivity(this.h.getPackageManager()); 
      c(componentName1);
      a(intent2);
    } 
    return this;
  }
  
  public p1 c(ComponentName paramComponentName) {
    int i = this.g.size();
    try {
      for (Intent intent = q.b(this.h, paramComponentName); intent != null; intent = q.b(this.h, intent.getComponent()))
        this.g.add(i, intent); 
      return this;
    } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
      throw new IllegalArgumentException(nameNotFoundException);
    } 
  }
  
  public void e() {
    f(null);
  }
  
  public void f(Bundle paramBundle) {
    if (!this.g.isEmpty()) {
      Intent[] arrayOfIntent = this.g.<Intent>toArray(new Intent[0]);
      arrayOfIntent[0] = (new Intent(arrayOfIntent[0])).addFlags(268484608);
      if (!androidx.core.content.a.j(this.h, arrayOfIntent, paramBundle)) {
        Intent intent = new Intent(arrayOfIntent[arrayOfIntent.length - 1]);
        intent.addFlags(268435456);
        this.h.startActivity(intent);
      } 
      return;
    } 
    throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
  }
  
  @Deprecated
  public Iterator<Intent> iterator() {
    return this.g.iterator();
  }
  
  public static interface a {
    Intent getSupportParentActivityIntent();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\p1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */