package androidx.core.app;

import android.content.res.Configuration;

public final class k1 {
  private final boolean a;
  
  private final Configuration b;
  
  public k1(boolean paramBoolean) {
    this.a = paramBoolean;
    this.b = null;
  }
  
  public k1(boolean paramBoolean, Configuration paramConfiguration) {
    this.a = paramBoolean;
    this.b = paramConfiguration;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\k1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */