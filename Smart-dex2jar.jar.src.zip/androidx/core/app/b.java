package androidx.core.app;

import android.app.Activity;
import android.app.SharedElementCallback;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.text.TextUtils;
import android.view.View;
import androidx.core.content.a;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

public class b extends a {
  public static void n(Activity paramActivity) {
    b.a(paramActivity);
  }
  
  public static void o(Activity paramActivity) {
    c.a(paramActivity);
  }
  
  public static void q(Activity paramActivity) {
    c.b(paramActivity);
  }
  
  public static void r(Activity paramActivity) {
    if (Build.VERSION.SDK_INT >= 28) {
      paramActivity.recreate();
      return;
    } 
    (new Handler(paramActivity.getMainLooper())).post(new a(paramActivity));
  }
  
  public static void s(Activity paramActivity, String[] paramArrayOfString, int paramInt) {
    StringBuilder stringBuilder;
    String[] arrayOfString;
    HashSet<Integer> hashSet = new HashSet();
    int j = 0;
    int i = 0;
    while (i < paramArrayOfString.length) {
      if (!TextUtils.isEmpty(paramArrayOfString[i])) {
        if (!androidx.core.os.a.c() && TextUtils.equals(paramArrayOfString[i], "android.permission.POST_NOTIFICATIONS"))
          hashSet.add(Integer.valueOf(i)); 
        i++;
        continue;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("Permission request for permissions ");
      stringBuilder.append(Arrays.toString((Object[])paramArrayOfString));
      stringBuilder.append(" must not contain null or empty values");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    i = hashSet.size();
    if (i > 0) {
      arrayOfString = new String[paramArrayOfString.length - i];
    } else {
      arrayOfString = paramArrayOfString;
    } 
    if (i > 0) {
      if (i == paramArrayOfString.length)
        return; 
      int k = 0;
      i = j;
      while (i < paramArrayOfString.length) {
        j = k;
        if (!hashSet.contains(Integer.valueOf(i))) {
          arrayOfString[k] = paramArrayOfString[i];
          j = k + 1;
        } 
        i++;
        k = j;
      } 
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      if (stringBuilder instanceof f)
        ((f)stringBuilder).validateRequestPermissionsRequestCode(paramInt); 
      d.b((Activity)stringBuilder, paramArrayOfString, paramInt);
      return;
    } 
    if (stringBuilder instanceof e)
      (new Handler(Looper.getMainLooper())).post(new a(arrayOfString, (Activity)stringBuilder, paramInt)); 
  }
  
  public static void t(Activity paramActivity, o1 paramo1) {
    if (paramo1 != null) {
      g g = new g(paramo1);
    } else {
      paramo1 = null;
    } 
    c.c(paramActivity, (SharedElementCallback)paramo1);
  }
  
  public static void u(Activity paramActivity, o1 paramo1) {
    if (paramo1 != null) {
      g g = new g(paramo1);
    } else {
      paramo1 = null;
    } 
    c.d(paramActivity, (SharedElementCallback)paramo1);
  }
  
  public static boolean v(Activity paramActivity, String paramString) {
    return (!androidx.core.os.a.c() && TextUtils.equals("android.permission.POST_NOTIFICATIONS", paramString)) ? false : ((Build.VERSION.SDK_INT >= 23) ? d.c(paramActivity, paramString) : false);
  }
  
  public static void w(Activity paramActivity, Intent paramIntent, int paramInt, Bundle paramBundle) {
    b.b(paramActivity, paramIntent, paramInt, paramBundle);
  }
  
  public static void x(Activity paramActivity, IntentSender paramIntentSender, int paramInt1, Intent paramIntent, int paramInt2, int paramInt3, int paramInt4, Bundle paramBundle) throws IntentSender.SendIntentException {
    b.c(paramActivity, paramIntentSender, paramInt1, paramIntent, paramInt2, paramInt3, paramInt4, paramBundle);
  }
  
  public static void y(Activity paramActivity) {
    c.e(paramActivity);
  }
  
  class a implements Runnable {
    a(b this$0, Activity param1Activity, int param1Int) {}
    
    public void run() {
      int[] arrayOfInt = new int[this.g.length];
      PackageManager packageManager = this.h.getPackageManager();
      String str = this.h.getPackageName();
      int j = this.g.length;
      for (int i = 0; i < j; i++)
        arrayOfInt[i] = packageManager.checkPermission(this.g[i], str); 
      ((b.e)this.h).onRequestPermissionsResult(this.i, this.g, arrayOfInt);
    }
  }
  
  static class b {
    static void a(Activity param1Activity) {
      param1Activity.finishAffinity();
    }
    
    static void b(Activity param1Activity, Intent param1Intent, int param1Int, Bundle param1Bundle) {
      param1Activity.startActivityForResult(param1Intent, param1Int, param1Bundle);
    }
    
    static void c(Activity param1Activity, IntentSender param1IntentSender, int param1Int1, Intent param1Intent, int param1Int2, int param1Int3, int param1Int4, Bundle param1Bundle) throws IntentSender.SendIntentException {
      param1Activity.startIntentSenderForResult(param1IntentSender, param1Int1, param1Intent, param1Int2, param1Int3, param1Int4, param1Bundle);
    }
  }
  
  static class c {
    static void a(Activity param1Activity) {
      param1Activity.finishAfterTransition();
    }
    
    static void b(Activity param1Activity) {
      param1Activity.postponeEnterTransition();
    }
    
    static void c(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setEnterSharedElementCallback(param1SharedElementCallback);
    }
    
    static void d(Activity param1Activity, SharedElementCallback param1SharedElementCallback) {
      param1Activity.setExitSharedElementCallback(param1SharedElementCallback);
    }
    
    static void e(Activity param1Activity) {
      param1Activity.startPostponedEnterTransition();
    }
  }
  
  static class d {
    static void a(Object param1Object) {
      d.a((SharedElementCallback.OnSharedElementsReadyListener)param1Object);
    }
    
    static void b(Activity param1Activity, String[] param1ArrayOfString, int param1Int) {
      c.a(param1Activity, param1ArrayOfString, param1Int);
    }
    
    static boolean c(Activity param1Activity, String param1String) {
      return e.a(param1Activity, param1String);
    }
  }
  
  public static interface e {
    void onRequestPermissionsResult(int param1Int, String[] param1ArrayOfString, int[] param1ArrayOfint);
  }
  
  public static interface f {
    void validateRequestPermissionsRequestCode(int param1Int);
  }
  
  static class g extends SharedElementCallback {
    private final o1 a;
    
    g(o1 param1o1) {
      this.a = param1o1;
    }
    
    public Parcelable onCaptureSharedElementSnapshot(View param1View, Matrix param1Matrix, RectF param1RectF) {
      return this.a.b(param1View, param1Matrix, param1RectF);
    }
    
    public View onCreateSnapshotView(Context param1Context, Parcelable param1Parcelable) {
      return this.a.c(param1Context, param1Parcelable);
    }
    
    public void onMapSharedElements(List<String> param1List, Map<String, View> param1Map) {
      this.a.d(param1List, param1Map);
    }
    
    public void onRejectSharedElements(List<View> param1List) {
      this.a.e(param1List);
    }
    
    public void onSharedElementEnd(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.a.f(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementStart(List<String> param1List, List<View> param1List1, List<View> param1List2) {
      this.a.g(param1List, param1List1, param1List2);
    }
    
    public void onSharedElementsArrived(List<String> param1List, List<View> param1List1, SharedElementCallback.OnSharedElementsReadyListener param1OnSharedElementsReadyListener) {
      this.a.h(param1List, param1List1, new f(param1OnSharedElementsReadyListener));
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */