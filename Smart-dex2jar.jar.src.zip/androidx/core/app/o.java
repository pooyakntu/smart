package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.collection.g;
import androidx.core.view.t;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;
import androidx.lifecycle.ReportFragment;

public class o extends Activity implements LifecycleOwner, t.a {
  private g<Class<? extends a>, a> mExtraDataMap = new g();
  
  private LifecycleRegistry mLifecycleRegistry = new LifecycleRegistry(this);
  
  private static boolean shouldSkipDump(String[] paramArrayOfString) {
    boolean bool3 = false;
    boolean bool4 = false;
    boolean bool2 = false;
    boolean bool1 = bool4;
    if (paramArrayOfString != null) {
      bool1 = bool4;
      if (paramArrayOfString.length > 0) {
        String str = paramArrayOfString[0];
        str.hashCode();
        int i = str.hashCode();
        byte b = -1;
        switch (i) {
          case 1455016274:
            if (!str.equals("--autofill"))
              break; 
            b = 4;
            break;
          case 1159329357:
            if (!str.equals("--contentcapture"))
              break; 
            b = 3;
            break;
          case 472614934:
            if (!str.equals("--list-dumpables"))
              break; 
            b = 2;
            break;
          case 100470631:
            if (!str.equals("--dump-dumpable"))
              break; 
            b = 1;
            break;
          case -645125871:
            if (!str.equals("--translation"))
              break; 
            b = 0;
            break;
        } 
        switch (b) {
          default:
            return false;
          case 4:
            bool1 = bool2;
            if (Build.VERSION.SDK_INT >= 26)
              bool1 = true; 
            return bool1;
          case 3:
            bool1 = bool3;
            if (Build.VERSION.SDK_INT >= 29)
              bool1 = true; 
            return bool1;
          case 1:
          case 2:
            return androidx.core.os.a.c();
          case 0:
            break;
        } 
        bool1 = bool4;
        if (Build.VERSION.SDK_INT >= 31)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && t.d(view, paramKeyEvent)) ? true : t.e(this, view, (Window.Callback)this, paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return (view != null && t.d(view, paramKeyEvent)) ? true : super.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  @Deprecated
  public <T extends a> T getExtraData(Class<T> paramClass) {
    return (T)this.mExtraDataMap.get(paramClass);
  }
  
  public Lifecycle getLifecycle() {
    return (Lifecycle)this.mLifecycleRegistry;
  }
  
  @SuppressLint({"RestrictedApi"})
  protected void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    ReportFragment.injectIfNeededIn(this);
  }
  
  protected void onSaveInstanceState(Bundle paramBundle) {
    this.mLifecycleRegistry.markState(Lifecycle.State.CREATED);
    super.onSaveInstanceState(paramBundle);
  }
  
  @Deprecated
  public void putExtraData(a parama) {
    this.mExtraDataMap.put(parama.getClass(), parama);
  }
  
  protected final boolean shouldDumpInternalState(String[] paramArrayOfString) {
    return shouldSkipDump(paramArrayOfString) ^ true;
  }
  
  public boolean superDispatchKeyEvent(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  @Deprecated
  public static class a {}
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */