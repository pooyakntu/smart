package androidx.core.app;

import android.os.Bundle;
import android.os.Parcelable;
import androidx.core.graphics.drawable.IconCompat;

class s0 {
  private static final Object a = new Object();
  
  private static final Object b = new Object();
  
  static Bundle a(s.a parama) {
    boolean bool;
    Bundle bundle1;
    Bundle bundle2 = new Bundle();
    IconCompat iconCompat = parama.d();
    if (iconCompat != null) {
      bool = iconCompat.l();
    } else {
      bool = false;
    } 
    bundle2.putInt("icon", bool);
    bundle2.putCharSequence("title", parama.h());
    bundle2.putParcelable("actionIntent", (Parcelable)parama.a());
    if (parama.c() != null) {
      bundle1 = new Bundle(parama.c());
    } else {
      bundle1 = new Bundle();
    } 
    bundle1.putBoolean("android.support.allowGeneratedReplies", parama.b());
    bundle2.putBundle("extras", bundle1);
    bundle2.putParcelableArray("remoteInputs", (Parcelable[])c(parama.e()));
    bundle2.putBoolean("showsUserInterface", parama.g());
    bundle2.putInt("semanticAction", parama.f());
    return bundle2;
  }
  
  private static Bundle b(l1 paraml1) {
    new Bundle();
    throw null;
  }
  
  private static Bundle[] c(l1[] paramArrayOfl1) {
    if (paramArrayOfl1 == null)
      return null; 
    Bundle[] arrayOfBundle = new Bundle[paramArrayOfl1.length];
    for (int i = 0; i < paramArrayOfl1.length; i++) {
      l1 l11 = paramArrayOfl1[i];
      arrayOfBundle[i] = b(null);
    } 
    return arrayOfBundle;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\s0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */