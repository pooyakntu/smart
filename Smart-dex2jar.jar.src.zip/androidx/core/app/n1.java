package androidx.core.app;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import androidx.core.util.h;
import java.util.ArrayList;

public class n1 {
  private final Context a;
  
  private final Intent b;
  
  private CharSequence c;
  
  private ArrayList<String> d;
  
  private ArrayList<String> e;
  
  private ArrayList<String> f;
  
  private ArrayList<Uri> g;
  
  public n1(Context paramContext) {
    this.a = (Context)h.g(paramContext);
    Intent intent = (new Intent()).setAction("android.intent.action.SEND");
    this.b = intent;
    intent.putExtra("androidx.core.app.EXTRA_CALLING_PACKAGE", paramContext.getPackageName());
    intent.putExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE", paramContext.getPackageName());
    intent.addFlags(524288);
    while (true) {
      if (paramContext instanceof ContextWrapper) {
        Activity activity;
        if (paramContext instanceof Activity) {
          activity = (Activity)paramContext;
          break;
        } 
        Context context = ((ContextWrapper)activity).getBaseContext();
        continue;
      } 
      paramContext = null;
      break;
    } 
    if (paramContext != null) {
      ComponentName componentName = paramContext.getComponentName();
      this.b.putExtra("androidx.core.app.EXTRA_CALLING_ACTIVITY", (Parcelable)componentName);
      this.b.putExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY", (Parcelable)componentName);
    } 
  }
  
  private void b(String paramString, ArrayList<String> paramArrayList) {
    byte b;
    String[] arrayOfString1 = this.b.getStringArrayExtra(paramString);
    if (arrayOfString1 != null) {
      b = arrayOfString1.length;
    } else {
      b = 0;
    } 
    String[] arrayOfString2 = new String[paramArrayList.size() + b];
    paramArrayList.toArray(arrayOfString2);
    if (arrayOfString1 != null)
      System.arraycopy(arrayOfString1, 0, arrayOfString2, paramArrayList.size(), b); 
    this.b.putExtra(paramString, arrayOfString2);
  }
  
  public n1 a(Uri paramUri) {
    if (this.g == null)
      this.g = new ArrayList<Uri>(); 
    this.g.add(paramUri);
    return this;
  }
  
  public Intent c() {
    return Intent.createChooser(d(), this.c);
  }
  
  public Intent d() {
    // Byte code:
    //   0: aload_0
    //   1: getfield d : Ljava/util/ArrayList;
    //   4: astore_3
    //   5: aload_3
    //   6: ifnull -> 21
    //   9: aload_0
    //   10: ldc 'android.intent.extra.EMAIL'
    //   12: aload_3
    //   13: invokespecial b : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   16: aload_0
    //   17: aconst_null
    //   18: putfield d : Ljava/util/ArrayList;
    //   21: aload_0
    //   22: getfield e : Ljava/util/ArrayList;
    //   25: astore_3
    //   26: aload_3
    //   27: ifnull -> 42
    //   30: aload_0
    //   31: ldc 'android.intent.extra.CC'
    //   33: aload_3
    //   34: invokespecial b : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   37: aload_0
    //   38: aconst_null
    //   39: putfield e : Ljava/util/ArrayList;
    //   42: aload_0
    //   43: getfield f : Ljava/util/ArrayList;
    //   46: astore_3
    //   47: aload_3
    //   48: ifnull -> 63
    //   51: aload_0
    //   52: ldc 'android.intent.extra.BCC'
    //   54: aload_3
    //   55: invokespecial b : (Ljava/lang/String;Ljava/util/ArrayList;)V
    //   58: aload_0
    //   59: aconst_null
    //   60: putfield f : Ljava/util/ArrayList;
    //   63: aload_0
    //   64: getfield g : Ljava/util/ArrayList;
    //   67: astore_3
    //   68: aload_3
    //   69: ifnull -> 87
    //   72: aload_3
    //   73: invokevirtual size : ()I
    //   76: istore_2
    //   77: iconst_1
    //   78: istore_1
    //   79: iload_2
    //   80: iconst_1
    //   81: if_icmple -> 87
    //   84: goto -> 89
    //   87: iconst_0
    //   88: istore_1
    //   89: iload_1
    //   90: ifne -> 173
    //   93: aload_0
    //   94: getfield b : Landroid/content/Intent;
    //   97: ldc 'android.intent.action.SEND'
    //   99: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
    //   102: pop
    //   103: aload_0
    //   104: getfield g : Ljava/util/ArrayList;
    //   107: astore_3
    //   108: aload_3
    //   109: ifnull -> 154
    //   112: aload_3
    //   113: invokevirtual isEmpty : ()Z
    //   116: ifne -> 154
    //   119: aload_0
    //   120: getfield b : Landroid/content/Intent;
    //   123: ldc 'android.intent.extra.STREAM'
    //   125: aload_0
    //   126: getfield g : Ljava/util/ArrayList;
    //   129: iconst_0
    //   130: invokevirtual get : (I)Ljava/lang/Object;
    //   133: checkcast android/os/Parcelable
    //   136: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   139: pop
    //   140: aload_0
    //   141: getfield b : Landroid/content/Intent;
    //   144: aload_0
    //   145: getfield g : Ljava/util/ArrayList;
    //   148: invokestatic b : (Landroid/content/Intent;Ljava/util/ArrayList;)V
    //   151: goto -> 208
    //   154: aload_0
    //   155: getfield b : Landroid/content/Intent;
    //   158: ldc 'android.intent.extra.STREAM'
    //   160: invokevirtual removeExtra : (Ljava/lang/String;)V
    //   163: aload_0
    //   164: getfield b : Landroid/content/Intent;
    //   167: invokestatic c : (Landroid/content/Intent;)V
    //   170: goto -> 208
    //   173: aload_0
    //   174: getfield b : Landroid/content/Intent;
    //   177: ldc 'android.intent.action.SEND_MULTIPLE'
    //   179: invokevirtual setAction : (Ljava/lang/String;)Landroid/content/Intent;
    //   182: pop
    //   183: aload_0
    //   184: getfield b : Landroid/content/Intent;
    //   187: ldc 'android.intent.extra.STREAM'
    //   189: aload_0
    //   190: getfield g : Ljava/util/ArrayList;
    //   193: invokevirtual putParcelableArrayListExtra : (Ljava/lang/String;Ljava/util/ArrayList;)Landroid/content/Intent;
    //   196: pop
    //   197: aload_0
    //   198: getfield b : Landroid/content/Intent;
    //   201: aload_0
    //   202: getfield g : Ljava/util/ArrayList;
    //   205: invokestatic b : (Landroid/content/Intent;Ljava/util/ArrayList;)V
    //   208: aload_0
    //   209: getfield b : Landroid/content/Intent;
    //   212: areturn
  }
  
  public n1 e(String paramString) {
    this.b.setType(paramString);
    return this;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\core\app\n1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */