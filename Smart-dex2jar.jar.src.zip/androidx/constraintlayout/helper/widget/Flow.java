package androidx.constraintlayout.helper.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.b;
import androidx.constraintlayout.widget.i;
import androidx.constraintlayout.widget.k;
import p.e;
import p.g;
import p.i;
import p.l;

public class Flow extends k {
  private g r;
  
  public Flow(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    this.r = new g();
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int m = typedArray.getIndex(i);
        if (m == i.o1) {
          this.r.D2(typedArray.getInt(m, 0));
        } else if (m == i.p1) {
          this.r.I1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.z1) {
          this.r.N1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.A1) {
          this.r.K1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.q1) {
          this.r.L1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.r1) {
          this.r.O1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.s1) {
          this.r.M1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.t1) {
          this.r.J1(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.Z1) {
          this.r.I2(typedArray.getInt(m, 0));
        } else if (m == i.P1) {
          this.r.x2(typedArray.getInt(m, 0));
        } else if (m == i.Y1) {
          this.r.H2(typedArray.getInt(m, 0));
        } else if (m == i.J1) {
          this.r.r2(typedArray.getInt(m, 0));
        } else if (m == i.R1) {
          this.r.z2(typedArray.getInt(m, 0));
        } else if (m == i.L1) {
          this.r.t2(typedArray.getInt(m, 0));
        } else if (m == i.T1) {
          this.r.B2(typedArray.getInt(m, 0));
        } else if (m == i.N1) {
          this.r.v2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.I1) {
          this.r.q2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.Q1) {
          this.r.y2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.K1) {
          this.r.s2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.S1) {
          this.r.A2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.W1) {
          this.r.F2(typedArray.getFloat(m, 0.5F));
        } else if (m == i.M1) {
          this.r.u2(typedArray.getInt(m, 2));
        } else if (m == i.V1) {
          this.r.E2(typedArray.getInt(m, 2));
        } else if (m == i.O1) {
          this.r.w2(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.X1) {
          this.r.G2(typedArray.getDimensionPixelSize(m, 0));
        } else if (m == i.U1) {
          this.r.C2(typedArray.getInt(m, -1));
        } 
      } 
      typedArray.recycle();
    } 
    ((b)this).j = (i)this.r;
    s();
  }
  
  public void n(e parame, boolean paramBoolean) {
    this.r.t1(paramBoolean);
  }
  
  @SuppressLint({"WrongCall"})
  protected void onMeasure(int paramInt1, int paramInt2) {
    t((l)this.r, paramInt1, paramInt2);
  }
  
  public void setFirstHorizontalBias(float paramFloat) {
    this.r.q2(paramFloat);
    requestLayout();
  }
  
  public void setFirstHorizontalStyle(int paramInt) {
    this.r.r2(paramInt);
    requestLayout();
  }
  
  public void setFirstVerticalBias(float paramFloat) {
    this.r.s2(paramFloat);
    requestLayout();
  }
  
  public void setFirstVerticalStyle(int paramInt) {
    this.r.t2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalAlign(int paramInt) {
    this.r.u2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalBias(float paramFloat) {
    this.r.v2(paramFloat);
    requestLayout();
  }
  
  public void setHorizontalGap(int paramInt) {
    this.r.w2(paramInt);
    requestLayout();
  }
  
  public void setHorizontalStyle(int paramInt) {
    this.r.x2(paramInt);
    requestLayout();
  }
  
  public void setLastHorizontalBias(float paramFloat) {
    this.r.y2(paramFloat);
    requestLayout();
  }
  
  public void setLastHorizontalStyle(int paramInt) {
    this.r.z2(paramInt);
    requestLayout();
  }
  
  public void setLastVerticalBias(float paramFloat) {
    this.r.A2(paramFloat);
    requestLayout();
  }
  
  public void setLastVerticalStyle(int paramInt) {
    this.r.B2(paramInt);
    requestLayout();
  }
  
  public void setMaxElementsWrap(int paramInt) {
    this.r.C2(paramInt);
    requestLayout();
  }
  
  public void setOrientation(int paramInt) {
    this.r.D2(paramInt);
    requestLayout();
  }
  
  public void setPadding(int paramInt) {
    this.r.I1(paramInt);
    requestLayout();
  }
  
  public void setPaddingBottom(int paramInt) {
    this.r.J1(paramInt);
    requestLayout();
  }
  
  public void setPaddingLeft(int paramInt) {
    this.r.L1(paramInt);
    requestLayout();
  }
  
  public void setPaddingRight(int paramInt) {
    this.r.M1(paramInt);
    requestLayout();
  }
  
  public void setPaddingTop(int paramInt) {
    this.r.O1(paramInt);
    requestLayout();
  }
  
  public void setVerticalAlign(int paramInt) {
    this.r.E2(paramInt);
    requestLayout();
  }
  
  public void setVerticalBias(float paramFloat) {
    this.r.F2(paramFloat);
    requestLayout();
  }
  
  public void setVerticalGap(int paramInt) {
    this.r.G2(paramInt);
    requestLayout();
  }
  
  public void setVerticalStyle(int paramInt) {
    this.r.H2(paramInt);
    requestLayout();
  }
  
  public void setWrapMode(int paramInt) {
    this.r.I2(paramInt);
    requestLayout();
  }
  
  public void t(l paraml, int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (paraml != null) {
      paraml.C1(i, paramInt1, j, paramInt2);
      setMeasuredDimension(paraml.x1(), paraml.w1());
      return;
    } 
    setMeasuredDimension(0, 0);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\helper\widget\Flow.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */