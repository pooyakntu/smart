package androidx.constraintlayout.motion.widget;

import android.view.animation.Interpolator;

public abstract class i implements Interpolator {
  public abstract float a();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\motion\widget\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */