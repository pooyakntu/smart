package androidx.constraintlayout.motion.widget;

public abstract class d {
  public static int a = -1;
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\motion\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */