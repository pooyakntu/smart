package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import p.l;

public abstract class k extends b {
  private boolean p;
  
  private boolean q;
  
  public k(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
  }
  
  protected void i(ConstraintLayout paramConstraintLayout) {
    h(paramConstraintLayout);
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    super.m(paramAttributeSet);
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int j = typedArray.getIndexCount();
      for (int i = 0; i < j; i++) {
        int m = typedArray.getIndex(i);
        if (m == i.u1) {
          this.p = true;
        } else if (m == i.B1) {
          this.q = true;
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.p || this.q) {
      ViewParent viewParent = getParent();
      if (viewParent instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)viewParent;
        int j = getVisibility();
        float f = getElevation();
        for (int i = 0; i < this.h; i++) {
          View view = constraintLayout.i(this.g[i]);
          if (view != null) {
            if (this.p)
              view.setVisibility(j); 
            if (this.q && f > 0.0F)
              view.setTranslationZ(view.getTranslationZ() + f); 
          } 
        } 
      } 
    } 
  }
  
  public void setElevation(float paramFloat) {
    super.setElevation(paramFloat);
    g();
  }
  
  public void setVisibility(int paramInt) {
    super.setVisibility(paramInt);
    g();
  }
  
  public void t(l paraml, int paramInt1, int paramInt2) {}
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\widget\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */