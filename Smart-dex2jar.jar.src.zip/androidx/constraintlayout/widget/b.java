package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.Arrays;
import java.util.HashMap;
import p.e;
import p.i;

public abstract class b extends View {
  protected int[] g = new int[32];
  
  protected int h;
  
  protected Context i;
  
  protected i j;
  
  protected boolean k = false;
  
  protected String l;
  
  protected String m;
  
  private View[] n = null;
  
  protected HashMap<Integer, String> o = new HashMap<Integer, String>();
  
  public b(Context paramContext) {
    super(paramContext);
    this.i = paramContext;
    m(null);
  }
  
  public b(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.i = paramContext;
    m(paramAttributeSet);
  }
  
  private void d(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.i == null)
        return; 
      paramString = paramString.trim();
      if (getParent() instanceof ConstraintLayout)
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent(); 
      int j = k(paramString);
      if (j != 0) {
        this.o.put(Integer.valueOf(j), paramString);
        e(j);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find id of \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
    } 
  }
  
  private void e(int paramInt) {
    if (paramInt == getId())
      return; 
    int j = this.h;
    int[] arrayOfInt = this.g;
    if (j + 1 > arrayOfInt.length)
      this.g = Arrays.copyOf(arrayOfInt, arrayOfInt.length * 2); 
    arrayOfInt = this.g;
    j = this.h;
    arrayOfInt[j] = paramInt;
    this.h = j + 1;
  }
  
  private void f(String paramString) {
    if (paramString != null) {
      if (paramString.length() == 0)
        return; 
      if (this.i == null)
        return; 
      String str = paramString.trim();
      if (getParent() instanceof ConstraintLayout) {
        ConstraintLayout constraintLayout = (ConstraintLayout)getParent();
      } else {
        paramString = null;
      } 
      if (paramString == null)
        return; 
      int k = paramString.getChildCount();
      for (int j = 0; j < k; j++) {
        View view = paramString.getChildAt(j);
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.b && str.equals(((ConstraintLayout.b)layoutParams).c0))
          if (view.getId() == -1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("to use ConstraintTag view ");
            stringBuilder.append(view.getClass().getSimpleName());
            stringBuilder.append(" must have an ID");
          } else {
            e(view.getId());
          }  
      } 
    } 
  }
  
  private int j(ConstraintLayout paramConstraintLayout, String paramString) {
    if (paramString != null) {
      if (paramConstraintLayout == null)
        return 0; 
      Resources resources = this.i.getResources();
      if (resources == null)
        return 0; 
      int k = paramConstraintLayout.getChildCount();
      int j = 0;
      while (true) {
        if (j < k) {
          View view = paramConstraintLayout.getChildAt(j);
          if (view.getId() != -1) {
            try {
              String str = resources.getResourceEntryName(view.getId());
            } catch (android.content.res.Resources.NotFoundException notFoundException) {
              notFoundException = null;
            } 
            if (paramString.equals(notFoundException))
              return view.getId(); 
          } 
          j++;
          continue;
        } 
        return 0;
      } 
    } 
    return 0;
  }
  
  private int k(String paramString) {
    ConstraintLayout constraintLayout;
    if (getParent() instanceof ConstraintLayout) {
      constraintLayout = (ConstraintLayout)getParent();
    } else {
      constraintLayout = null;
    } 
    boolean bool = isInEditMode();
    int j = 0;
    int k = j;
    if (bool) {
      k = j;
      if (constraintLayout != null) {
        Object object = constraintLayout.g(0, paramString);
        k = j;
        if (object instanceof Integer)
          k = ((Integer)object).intValue(); 
      } 
    } 
    j = k;
    if (k == 0) {
      j = k;
      if (constraintLayout != null)
        j = j(constraintLayout, paramString); 
    } 
    k = j;
    if (j == 0)
      try {
        k = h.class.getField(paramString).getInt(null);
      } catch (Exception exception) {
        k = j;
      }  
    j = k;
    if (k == 0)
      j = this.i.getResources().getIdentifier(paramString, "id", this.i.getPackageName()); 
    return j;
  }
  
  protected void g() {
    ViewParent viewParent = getParent();
    if (viewParent != null && viewParent instanceof ConstraintLayout)
      h((ConstraintLayout)viewParent); 
  }
  
  public int[] getReferencedIds() {
    return Arrays.copyOf(this.g, this.h);
  }
  
  protected void h(ConstraintLayout paramConstraintLayout) {
    int k = getVisibility();
    float f = getElevation();
    for (int j = 0; j < this.h; j++) {
      View view = paramConstraintLayout.i(this.g[j]);
      if (view != null) {
        view.setVisibility(k);
        if (f > 0.0F)
          view.setTranslationZ(view.getTranslationZ() + f); 
      } 
    } 
  }
  
  protected void i(ConstraintLayout paramConstraintLayout) {}
  
  protected View[] l(ConstraintLayout paramConstraintLayout) {
    View[] arrayOfView = this.n;
    if (arrayOfView == null || arrayOfView.length != this.h)
      this.n = new View[this.h]; 
    for (int j = 0; j < this.h; j++) {
      int k = this.g[j];
      this.n[j] = paramConstraintLayout.i(k);
    } 
    return this.n;
  }
  
  protected void m(AttributeSet paramAttributeSet) {
    if (paramAttributeSet != null) {
      TypedArray typedArray = getContext().obtainStyledAttributes(paramAttributeSet, i.n1);
      int k = typedArray.getIndexCount();
      for (int j = 0; j < k; j++) {
        int m = typedArray.getIndex(j);
        if (m == i.G1) {
          String str = typedArray.getString(m);
          this.l = str;
          setIds(str);
        } else if (m == i.H1) {
          String str = typedArray.getString(m);
          this.m = str;
          setReferenceTags(str);
        } 
      } 
      typedArray.recycle();
    } 
  }
  
  public void n(e parame, boolean paramBoolean) {}
  
  public void o(ConstraintLayout paramConstraintLayout) {}
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    String str = this.l;
    if (str != null)
      setIds(str); 
    str = this.m;
    if (str != null)
      setReferenceTags(str); 
  }
  
  public void onDraw(Canvas paramCanvas) {}
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.k) {
      super.onMeasure(paramInt1, paramInt2);
      return;
    } 
    setMeasuredDimension(0, 0);
  }
  
  public void p(ConstraintLayout paramConstraintLayout) {}
  
  public void q(ConstraintLayout paramConstraintLayout) {}
  
  public void r(ConstraintLayout paramConstraintLayout) {
    if (isInEditMode())
      setIds(this.l); 
    i i1 = this.j;
    if (i1 == null)
      return; 
    i1.a();
    for (int j = 0; j < this.h; j++) {
      int k = this.g[j];
      View view2 = paramConstraintLayout.i(k);
      View view1 = view2;
      if (view2 == null) {
        String str = this.o.get(Integer.valueOf(k));
        k = j(paramConstraintLayout, str);
        view1 = view2;
        if (k != 0) {
          this.g[j] = k;
          this.o.put(Integer.valueOf(k), str);
          view1 = paramConstraintLayout.i(k);
        } 
      } 
      if (view1 != null)
        this.j.b(paramConstraintLayout.p(view1)); 
    } 
    this.j.c(paramConstraintLayout.i);
  }
  
  public void s() {
    if (this.j == null)
      return; 
    ViewGroup.LayoutParams layoutParams = getLayoutParams();
    if (layoutParams instanceof ConstraintLayout.b)
      ((ConstraintLayout.b)layoutParams).v0 = (e)this.j; 
  }
  
  protected void setIds(String paramString) {
    this.l = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.h = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        d(paramString.substring(j));
        return;
      } 
      d(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  protected void setReferenceTags(String paramString) {
    this.m = paramString;
    if (paramString == null)
      return; 
    int j = 0;
    this.h = 0;
    while (true) {
      int k = paramString.indexOf(',', j);
      if (k == -1) {
        f(paramString.substring(j));
        return;
      } 
      f(paramString.substring(j, k));
      j = k + 1;
    } 
  }
  
  public void setReferencedIds(int[] paramArrayOfint) {
    this.l = null;
    int j = 0;
    this.h = 0;
    while (j < paramArrayOfint.length) {
      e(paramArrayOfint[j]);
      j++;
    } 
  }
  
  public void setTag(int paramInt, Object paramObject) {
    super.setTag(paramInt, paramObject);
    if (paramObject == null && this.l == null)
      e(paramInt); 
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\widget\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */