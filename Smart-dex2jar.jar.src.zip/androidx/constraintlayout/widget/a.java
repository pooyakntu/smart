package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.util.Xml;
import android.view.View;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;

public class a {
  private boolean a;
  
  String b;
  
  private b c;
  
  private int d;
  
  private float e;
  
  private String f;
  
  boolean g;
  
  private int h;
  
  public a(a parama, Object paramObject) {
    this.a = false;
    this.b = parama.b;
    this.c = parama.c;
    f(paramObject);
  }
  
  public a(String paramString, b paramb, Object paramObject, boolean paramBoolean) {
    this.b = paramString;
    this.c = paramb;
    this.a = paramBoolean;
    f(paramObject);
  }
  
  public static HashMap<String, a> a(HashMap<String, a> paramHashMap, View paramView) {
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    Class<?> clazz = paramView.getClass();
    for (String str : paramHashMap.keySet()) {
      a a1 = paramHashMap.get(str);
      try {
        if (str.equals("BackgroundColor")) {
          hashMap.put(str, new a(a1, Integer.valueOf(((ColorDrawable)paramView.getBackground()).getColor())));
          continue;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getMap");
        stringBuilder.append(str);
        hashMap.put(str, new a(a1, clazz.getMethod(stringBuilder.toString(), new Class[0]).invoke(paramView, new Object[0])));
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.printStackTrace();
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        invocationTargetException.printStackTrace();
      } 
    } 
    return (HashMap)hashMap;
  }
  
  public static void d(Context paramContext, XmlPullParser paramXmlPullParser, HashMap<String, a> paramHashMap) {
    Object object1;
    String str;
    TypedArray typedArray = paramContext.obtainStyledAttributes(Xml.asAttributeSet(paramXmlPullParser), i.X4);
    int j = typedArray.getIndexCount();
    XmlPullParser xmlPullParser = null;
    Object object3 = null;
    Object object2 = object3;
    int i = 0;
    boolean bool = false;
    while (i < j) {
      b b1;
      int k = typedArray.getIndex(i);
      if (k == i.Y4) {
        str = typedArray.getString(k);
        String str2 = str;
        Object object5 = object3;
        Object object6 = object2;
        Object object4 = object1;
        if (str != null) {
          str2 = str;
          object5 = object3;
          object6 = object2;
          object4 = object1;
          if (str.length() > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Character.toUpperCase(str.charAt(0)));
            stringBuilder.append(str.substring(1));
            String str3 = stringBuilder.toString();
            object5 = object3;
            object6 = object2;
            object4 = object1;
          } 
        } 
        continue;
      } 
      if (k == i.i5) {
        String str2 = typedArray.getString(k);
        boolean bool1 = true;
        Object object4 = object3;
        Object object5 = object2;
        continue;
      } 
      if (k == i.Z4) {
        Boolean bool1 = Boolean.valueOf(typedArray.getBoolean(k, false));
        b b3 = b.BOOLEAN_TYPE;
        String str2 = str;
        Object object4 = object1;
        continue;
      } 
      if (k == i.b5) {
        b1 = b.COLOR_TYPE;
        Integer integer = Integer.valueOf(typedArray.getColor(k, 0));
      } else if (k == i.a5) {
        b1 = b.COLOR_DRAWABLE_TYPE;
        Integer integer = Integer.valueOf(typedArray.getColor(k, 0));
      } else if (k == i.f5) {
        b1 = b.DIMENSION_TYPE;
        Float float_ = Float.valueOf(TypedValue.applyDimension(1, typedArray.getDimension(k, 0.0F), paramContext.getResources().getDisplayMetrics()));
      } else if (k == i.c5) {
        b1 = b.DIMENSION_TYPE;
        Float float_ = Float.valueOf(typedArray.getDimension(k, 0.0F));
      } else if (k == i.d5) {
        b1 = b.FLOAT_TYPE;
        Float float_ = Float.valueOf(typedArray.getFloat(k, Float.NaN));
      } else if (k == i.e5) {
        b1 = b.INT_TYPE;
        Integer integer = Integer.valueOf(typedArray.getInteger(k, -1));
      } else if (k == i.h5) {
        b1 = b.STRING_TYPE;
        String str2 = typedArray.getString(k);
      } else {
        String str2 = str;
        Object object5 = object3;
        Object object6 = object2;
        Object object4 = object1;
        if (k == i.g5) {
          b1 = b.REFERENCE_TYPE;
          int n = typedArray.getResourceId(k, -1);
          int m = n;
          if (n == -1)
            m = typedArray.getInt(k, -1); 
          object5 = Integer.valueOf(m);
        } else {
          continue;
        } 
      } 
      b b2 = b1;
      String str1 = str;
      Object object = object1;
      continue;
      i++;
      xmlPullParser = paramXmlPullParser;
      object3 = SYNTHETIC_LOCAL_VARIABLE_10;
      object2 = SYNTHETIC_LOCAL_VARIABLE_11;
      object1 = SYNTHETIC_LOCAL_VARIABLE_9;
    } 
    if (str != null && object3 != null)
      paramHashMap.put(str, new a(str, (b)object2, object3, object1)); 
    typedArray.recycle();
  }
  
  public static void e(View paramView, HashMap<String, a> paramHashMap) {
    Class<?> clazz = paramView.getClass();
    for (String str2 : paramHashMap.keySet()) {
      String str1;
      StringBuilder stringBuilder;
      a a1 = paramHashMap.get(str2);
      if (!a1.a) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("set");
        stringBuilder1.append(str2);
        str1 = stringBuilder1.toString();
      } else {
        str1 = str2;
      } 
      try {
        Method method;
        ColorDrawable colorDrawable;
        switch (a.a[a1.c.ordinal()]) {
          case 8:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(a1.e) });
          case 7:
            clazz.getMethod(str1, new Class[] { float.class }).invoke(paramView, new Object[] { Float.valueOf(a1.e) });
          case 6:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.d) });
          case 5:
            method = clazz.getMethod(str1, new Class[] { Drawable.class });
            colorDrawable = new ColorDrawable();
            colorDrawable.setColor(a1.h);
            method.invoke(paramView, new Object[] { colorDrawable });
          case 4:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.h) });
          case 3:
            clazz.getMethod(str1, new Class[] { CharSequence.class }).invoke(paramView, new Object[] { a1.f });
          case 2:
            clazz.getMethod(str1, new Class[] { boolean.class }).invoke(paramView, new Object[] { Boolean.valueOf(a1.g) });
          case 1:
            clazz.getMethod(str1, new Class[] { int.class }).invoke(paramView, new Object[] { Integer.valueOf(a1.d) });
        } 
      } catch (NoSuchMethodException noSuchMethodException) {
        noSuchMethodException.getMessage();
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append(str2);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        stringBuilder = new StringBuilder();
        stringBuilder.append(clazz.getName());
        stringBuilder.append(" must have a method ");
        stringBuilder.append(str1);
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        illegalAccessException.printStackTrace();
      } catch (InvocationTargetException invocationTargetException) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" Custom Attribute \"");
        stringBuilder1.append((String)stringBuilder);
        stringBuilder1.append("\" not found on ");
        stringBuilder1.append(clazz.getName());
        invocationTargetException.printStackTrace();
      } 
    } 
  }
  
  public String b() {
    return this.b;
  }
  
  public b c() {
    return this.c;
  }
  
  public void f(Object paramObject) {
    switch (a.a[this.c.ordinal()]) {
      default:
        return;
      case 8:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 7:
        this.e = ((Float)paramObject).floatValue();
        return;
      case 4:
      case 5:
        this.h = ((Integer)paramObject).intValue();
        return;
      case 3:
        this.f = (String)paramObject;
        return;
      case 2:
        this.g = ((Boolean)paramObject).booleanValue();
        return;
      case 1:
      case 6:
        break;
    } 
    this.d = ((Integer)paramObject).intValue();
  }
  
  public enum b {
    BOOLEAN_TYPE, COLOR_DRAWABLE_TYPE, COLOR_TYPE, DIMENSION_TYPE, FLOAT_TYPE, INT_TYPE, REFERENCE_TYPE, STRING_TYPE;
    
    static {
      COLOR_TYPE = new b("COLOR_TYPE", 2);
      COLOR_DRAWABLE_TYPE = new b("COLOR_DRAWABLE_TYPE", 3);
      STRING_TYPE = new b("STRING_TYPE", 4);
      BOOLEAN_TYPE = new b("BOOLEAN_TYPE", 5);
      DIMENSION_TYPE = new b("DIMENSION_TYPE", 6);
      REFERENCE_TYPE = new b("REFERENCE_TYPE", 7);
      $VALUES = $values();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\widget\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */