package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;

public class e extends ViewGroup {
  d g;
  
  protected a a() {
    return new a(-2, -2);
  }
  
  public a b(AttributeSet paramAttributeSet) {
    return new a(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)new ConstraintLayout.b(paramLayoutParams);
  }
  
  public d getConstraintSet() {
    if (this.g == null)
      this.g = new d(); 
    this.g.g(this);
    return this.g;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
  
  public static class a extends ConstraintLayout.b {
    public float A0;
    
    public float B0;
    
    public float C0;
    
    public float D0;
    
    public float E0;
    
    public float F0;
    
    public float G0;
    
    public float H0;
    
    public float I0;
    
    public float J0;
    
    public float x0 = 1.0F;
    
    public boolean y0;
    
    public float z0;
    
    public a(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.y0 = false;
      this.z0 = 0.0F;
      this.A0 = 0.0F;
      this.B0 = 0.0F;
      this.C0 = 0.0F;
      this.D0 = 1.0F;
      this.E0 = 1.0F;
      this.F0 = 0.0F;
      this.G0 = 0.0F;
      this.H0 = 0.0F;
      this.I0 = 0.0F;
      this.J0 = 0.0F;
    }
    
    public a(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      int i = 0;
      this.y0 = false;
      this.z0 = 0.0F;
      this.A0 = 0.0F;
      this.B0 = 0.0F;
      this.C0 = 0.0F;
      this.D0 = 1.0F;
      this.E0 = 1.0F;
      this.F0 = 0.0F;
      this.G0 = 0.0F;
      this.H0 = 0.0F;
      this.I0 = 0.0F;
      this.J0 = 0.0F;
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, i.K4);
      int j = typedArray.getIndexCount();
      while (i < j) {
        int k = typedArray.getIndex(i);
        if (k == i.L4) {
          this.x0 = typedArray.getFloat(k, this.x0);
        } else if (k == i.W4) {
          this.z0 = typedArray.getFloat(k, this.z0);
          this.y0 = true;
        } else if (k == i.T4) {
          this.B0 = typedArray.getFloat(k, this.B0);
        } else if (k == i.U4) {
          this.C0 = typedArray.getFloat(k, this.C0);
        } else if (k == i.S4) {
          this.A0 = typedArray.getFloat(k, this.A0);
        } else if (k == i.Q4) {
          this.D0 = typedArray.getFloat(k, this.D0);
        } else if (k == i.R4) {
          this.E0 = typedArray.getFloat(k, this.E0);
        } else if (k == i.M4) {
          this.F0 = typedArray.getFloat(k, this.F0);
        } else if (k == i.N4) {
          this.G0 = typedArray.getFloat(k, this.G0);
        } else if (k == i.O4) {
          this.H0 = typedArray.getFloat(k, this.H0);
        } else if (k == i.P4) {
          this.I0 = typedArray.getFloat(k, this.I0);
        } else if (k == i.V4) {
          this.J0 = typedArray.getFloat(k, this.J0);
        } 
        i++;
      } 
      typedArray.recycle();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\widget\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */