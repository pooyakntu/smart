package androidx.constraintlayout.widget;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.view.View;
import p.e;

public class g extends View {
  private int g;
  
  private View h;
  
  private int i;
  
  public void a(ConstraintLayout paramConstraintLayout) {
    if (this.h == null)
      return; 
    ConstraintLayout.b b1 = (ConstraintLayout.b)getLayoutParams();
    ConstraintLayout.b b2 = (ConstraintLayout.b)this.h.getLayoutParams();
    b2.v0.j1(0);
    e.b b3 = b1.v0.A();
    e.b b4 = e.b.FIXED;
    if (b3 != b4)
      b1.v0.k1(b2.v0.W()); 
    if (b1.v0.T() != b4)
      b1.v0.L0(b2.v0.x()); 
    b2.v0.j1(8);
  }
  
  public void b(ConstraintLayout paramConstraintLayout) {
    if (this.g == -1 && !isInEditMode())
      setVisibility(this.i); 
    View view = paramConstraintLayout.findViewById(this.g);
    this.h = view;
    if (view != null) {
      ((ConstraintLayout.b)view.getLayoutParams()).j0 = true;
      this.h.setVisibility(0);
      setVisibility(0);
    } 
  }
  
  public View getContent() {
    return this.h;
  }
  
  public int getEmptyVisibility() {
    return this.i;
  }
  
  public void onDraw(Canvas paramCanvas) {
    if (isInEditMode()) {
      paramCanvas.drawRGB(223, 223, 223);
      Paint paint = new Paint();
      paint.setARGB(255, 210, 210, 210);
      paint.setTextAlign(Paint.Align.CENTER);
      paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
      Rect rect = new Rect();
      paramCanvas.getClipBounds(rect);
      paint.setTextSize(rect.height());
      int i = rect.height();
      int j = rect.width();
      paint.setTextAlign(Paint.Align.LEFT);
      paint.getTextBounds("?", 0, 1, rect);
      paramCanvas.drawText("?", j / 2.0F - rect.width() / 2.0F - rect.left, i / 2.0F + rect.height() / 2.0F - rect.bottom, paint);
    } 
  }
  
  public void setContentId(int paramInt) {
    if (this.g == paramInt)
      return; 
    View view = this.h;
    if (view != null) {
      view.setVisibility(0);
      ((ConstraintLayout.b)this.h.getLayoutParams()).j0 = false;
      this.h = null;
    } 
    this.g = paramInt;
    if (paramInt != -1) {
      view = ((View)getParent()).findViewById(paramInt);
      if (view != null)
        view.setVisibility(8); 
    } 
  }
  
  public void setEmptyVisibility(int paramInt) {
    this.i = paramInt;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\constraintlayout\widget\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */