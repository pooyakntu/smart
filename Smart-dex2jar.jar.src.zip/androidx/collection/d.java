package androidx.collection;

public class d<E> implements Cloneable {
  private static final Object k = new Object();
  
  private boolean g = false;
  
  private long[] h;
  
  private Object[] i;
  
  private int j;
  
  public d() {
    this(10);
  }
  
  public d(int paramInt) {
    if (paramInt == 0) {
      this.h = c.b;
      this.i = c.c;
      return;
    } 
    paramInt = c.f(paramInt);
    this.h = new long[paramInt];
    this.i = new Object[paramInt];
  }
  
  private void e() {
    int k = this.j;
    long[] arrayOfLong = this.h;
    Object[] arrayOfObject = this.i;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != k) {
        if (i != j) {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.g = false;
    this.j = j;
  }
  
  public void a(long paramLong, E paramE) {
    int i = this.j;
    if (i != 0 && paramLong <= this.h[i - 1]) {
      k(paramLong, paramE);
      return;
    } 
    if (this.g && i >= this.h.length)
      e(); 
    i = this.j;
    if (i >= this.h.length) {
      int j = c.f(i + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.h;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.i;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.h = arrayOfLong1;
      this.i = arrayOfObject1;
    } 
    this.h[i] = paramLong;
    this.i[i] = paramE;
    this.j = i + 1;
  }
  
  public void b() {
    int j = this.j;
    Object[] arrayOfObject = this.i;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.j = 0;
    this.g = false;
  }
  
  public d<E> c() {
    try {
      d<E> d1 = (d)super.clone();
      d1.h = (long[])this.h.clone();
      d1.i = (Object[])this.i.clone();
      return d1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public boolean d(long paramLong) {
    return (h(paramLong) >= 0);
  }
  
  public E f(long paramLong) {
    return g(paramLong, null);
  }
  
  public E g(long paramLong, E paramE) {
    int i = c.b(this.h, this.j, paramLong);
    if (i >= 0) {
      Object object = this.i[i];
      return (E)((object == k) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public int h(long paramLong) {
    if (this.g)
      e(); 
    return c.b(this.h, this.j, paramLong);
  }
  
  public boolean i() {
    return (n() == 0);
  }
  
  public long j(int paramInt) {
    if (this.g)
      e(); 
    return this.h[paramInt];
  }
  
  public void k(long paramLong, E paramE) {
    int i = c.b(this.h, this.j, paramLong);
    if (i >= 0) {
      this.i[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.j;
    if (j < k) {
      Object[] arrayOfObject = this.i;
      if (arrayOfObject[j] == k) {
        this.h[j] = paramLong;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.g) {
      i = j;
      if (k >= this.h.length) {
        e();
        i = c.b(this.h, this.j, paramLong);
      } 
    } 
    j = this.j;
    if (j >= this.h.length) {
      j = c.f(j + 1);
      long[] arrayOfLong1 = new long[j];
      Object[] arrayOfObject1 = new Object[j];
      long[] arrayOfLong2 = this.h;
      System.arraycopy(arrayOfLong2, 0, arrayOfLong1, 0, arrayOfLong2.length);
      Object[] arrayOfObject2 = this.i;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.h = arrayOfLong1;
      this.i = arrayOfObject1;
    } 
    j = this.j;
    if (j - i != 0) {
      long[] arrayOfLong = this.h;
      k = i + 1;
      System.arraycopy(arrayOfLong, i, arrayOfLong, k, j - i);
      Object[] arrayOfObject = this.i;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.j - i);
    } 
    this.h[i] = paramLong;
    this.i[i] = paramE;
    this.j++;
  }
  
  public void l(long paramLong) {
    int i = c.b(this.h, this.j, paramLong);
    if (i >= 0) {
      Object[] arrayOfObject = this.i;
      Object object1 = arrayOfObject[i];
      Object object2 = k;
      if (object1 != object2) {
        arrayOfObject[i] = object2;
        this.g = true;
      } 
    } 
  }
  
  public void m(int paramInt) {
    Object[] arrayOfObject = this.i;
    Object object1 = arrayOfObject[paramInt];
    Object object2 = k;
    if (object1 != object2) {
      arrayOfObject[paramInt] = object2;
      this.g = true;
    } 
  }
  
  public int n() {
    if (this.g)
      e(); 
    return this.j;
  }
  
  public E o(int paramInt) {
    if (this.g)
      e(); 
    return (E)this.i[paramInt];
  }
  
  public String toString() {
    if (n() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.j * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.j; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(j(i));
      stringBuilder.append('=');
      E e = o(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\collection\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */