package androidx.collection;

public class h<E> implements Cloneable {
  private static final Object k = new Object();
  
  private boolean g = false;
  
  private int[] h;
  
  private Object[] i;
  
  private int j;
  
  public h() {
    this(10);
  }
  
  public h(int paramInt) {
    if (paramInt == 0) {
      this.h = c.a;
      this.i = c.c;
      return;
    } 
    paramInt = c.e(paramInt);
    this.h = new int[paramInt];
    this.i = new Object[paramInt];
  }
  
  private void d() {
    int k = this.j;
    int[] arrayOfInt = this.h;
    Object[] arrayOfObject = this.i;
    int i = 0;
    int j;
    for (j = 0; i < k; j = m) {
      Object object = arrayOfObject[i];
      int m = j;
      if (object != k) {
        if (i != j) {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = object;
          arrayOfObject[i] = null;
        } 
        m = j + 1;
      } 
      i++;
    } 
    this.g = false;
    this.j = j;
  }
  
  public void a(int paramInt, E paramE) {
    int i = this.j;
    if (i != 0 && paramInt <= this.h[i - 1]) {
      i(paramInt, paramE);
      return;
    } 
    if (this.g && i >= this.h.length)
      d(); 
    i = this.j;
    if (i >= this.h.length) {
      int j = c.e(i + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.h;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.i;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.h = arrayOfInt1;
      this.i = arrayOfObject1;
    } 
    this.h[i] = paramInt;
    this.i[i] = paramE;
    this.j = i + 1;
  }
  
  public void b() {
    int j = this.j;
    Object[] arrayOfObject = this.i;
    for (int i = 0; i < j; i++)
      arrayOfObject[i] = null; 
    this.j = 0;
    this.g = false;
  }
  
  public h<E> c() {
    try {
      h<E> h1 = (h)super.clone();
      h1.h = (int[])this.h.clone();
      h1.i = (Object[])this.i.clone();
      return h1;
    } catch (CloneNotSupportedException cloneNotSupportedException) {
      throw new AssertionError(cloneNotSupportedException);
    } 
  }
  
  public E e(int paramInt) {
    return f(paramInt, null);
  }
  
  public E f(int paramInt, E paramE) {
    paramInt = c.a(this.h, this.j, paramInt);
    if (paramInt >= 0) {
      Object object = this.i[paramInt];
      return (E)((object == k) ? (Object)paramE : object);
    } 
    return paramE;
  }
  
  public int g(E paramE) {
    if (this.g)
      d(); 
    for (int i = 0; i < this.j; i++) {
      if (this.i[i] == paramE)
        return i; 
    } 
    return -1;
  }
  
  public int h(int paramInt) {
    if (this.g)
      d(); 
    return this.h[paramInt];
  }
  
  public void i(int paramInt, E paramE) {
    int i = c.a(this.h, this.j, paramInt);
    if (i >= 0) {
      this.i[i] = paramE;
      return;
    } 
    int j = i;
    int k = this.j;
    if (j < k) {
      Object[] arrayOfObject = this.i;
      if (arrayOfObject[j] == k) {
        this.h[j] = paramInt;
        arrayOfObject[j] = paramE;
        return;
      } 
    } 
    i = j;
    if (this.g) {
      i = j;
      if (k >= this.h.length) {
        d();
        i = c.a(this.h, this.j, paramInt);
      } 
    } 
    j = this.j;
    if (j >= this.h.length) {
      j = c.e(j + 1);
      int[] arrayOfInt1 = new int[j];
      Object[] arrayOfObject1 = new Object[j];
      int[] arrayOfInt2 = this.h;
      System.arraycopy(arrayOfInt2, 0, arrayOfInt1, 0, arrayOfInt2.length);
      Object[] arrayOfObject2 = this.i;
      System.arraycopy(arrayOfObject2, 0, arrayOfObject1, 0, arrayOfObject2.length);
      this.h = arrayOfInt1;
      this.i = arrayOfObject1;
    } 
    j = this.j;
    if (j - i != 0) {
      int[] arrayOfInt = this.h;
      k = i + 1;
      System.arraycopy(arrayOfInt, i, arrayOfInt, k, j - i);
      Object[] arrayOfObject = this.i;
      System.arraycopy(arrayOfObject, i, arrayOfObject, k, this.j - i);
    } 
    this.h[i] = paramInt;
    this.i[i] = paramE;
    this.j++;
  }
  
  public int j() {
    if (this.g)
      d(); 
    return this.j;
  }
  
  public E k(int paramInt) {
    if (this.g)
      d(); 
    return (E)this.i[paramInt];
  }
  
  public String toString() {
    if (j() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(this.j * 28);
    stringBuilder.append('{');
    for (int i = 0; i < this.j; i++) {
      if (i > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(h(i));
      stringBuilder.append('=');
      E e = k(i);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\collection\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */