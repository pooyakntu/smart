package androidx.appcompat.widget;

import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityManager;
import androidx.core.view.e1;
import androidx.core.view.y2;

class f3 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
  private static f3 q;
  
  private static f3 r;
  
  private final View g;
  
  private final CharSequence h;
  
  private final int i;
  
  private final Runnable j = new d3(this);
  
  private final Runnable k = new e3(this);
  
  private int l;
  
  private int m;
  
  private g3 n;
  
  private boolean o;
  
  private boolean p;
  
  private f3(View paramView, CharSequence paramCharSequence) {
    this.g = paramView;
    this.h = paramCharSequence;
    this.i = y2.c(ViewConfiguration.get(paramView.getContext()));
    c();
    paramView.setOnLongClickListener(this);
    paramView.setOnHoverListener(this);
  }
  
  private void b() {
    this.g.removeCallbacks(this.j);
  }
  
  private void c() {
    this.p = true;
  }
  
  private void f() {
    this.g.postDelayed(this.j, ViewConfiguration.getLongPressTimeout());
  }
  
  private static void g(f3 paramf3) {
    f3 f31 = q;
    if (f31 != null)
      f31.b(); 
    q = paramf3;
    if (paramf3 != null)
      paramf3.f(); 
  }
  
  public static void h(View paramView, CharSequence paramCharSequence) {
    f3 f31;
    f3 f32 = q;
    if (f32 != null && f32.g == paramView)
      g(null); 
    if (TextUtils.isEmpty(paramCharSequence)) {
      f31 = r;
      if (f31 != null && f31.g == paramView)
        f31.d(); 
      paramView.setOnLongClickListener(null);
      paramView.setLongClickable(false);
      paramView.setOnHoverListener(null);
      return;
    } 
    new f3(paramView, (CharSequence)f31);
  }
  
  private boolean j(MotionEvent paramMotionEvent) {
    int i = (int)paramMotionEvent.getX();
    int j = (int)paramMotionEvent.getY();
    if (this.p || Math.abs(i - this.l) > this.i || Math.abs(j - this.m) > this.i) {
      this.l = i;
      this.m = j;
      this.p = false;
      return true;
    } 
    return false;
  }
  
  void d() {
    if (r == this) {
      r = null;
      g3 g31 = this.n;
      if (g31 != null) {
        g31.c();
        this.n = null;
        c();
        this.g.removeOnAttachStateChangeListener(this);
      } 
    } 
    if (q == this)
      g(null); 
    this.g.removeCallbacks(this.k);
  }
  
  void i(boolean paramBoolean) {
    long l;
    if (!e1.Z(this.g))
      return; 
    g(null);
    f3 f31 = r;
    if (f31 != null)
      f31.d(); 
    r = this;
    this.o = paramBoolean;
    g3 g31 = new g3(this.g.getContext());
    this.n = g31;
    g31.e(this.g, this.l, this.m, this.o, this.h);
    this.g.addOnAttachStateChangeListener(this);
    if (this.o) {
      l = 2500L;
    } else {
      long l1;
      if ((e1.S(this.g) & 0x1) == 1) {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 3000L;
      } else {
        l = ViewConfiguration.getLongPressTimeout();
        l1 = 15000L;
      } 
      l = l1 - l;
    } 
    this.g.removeCallbacks(this.k);
    this.g.postDelayed(this.k, l);
  }
  
  public boolean onHover(View paramView, MotionEvent paramMotionEvent) {
    if (this.n != null && this.o)
      return false; 
    AccessibilityManager accessibilityManager = (AccessibilityManager)this.g.getContext().getSystemService("accessibility");
    if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled())
      return false; 
    int i = paramMotionEvent.getAction();
    if (i != 7) {
      if (i != 10)
        return false; 
      c();
      d();
      return false;
    } 
    if (this.g.isEnabled() && this.n == null && j(paramMotionEvent))
      g(this); 
    return false;
  }
  
  public boolean onLongClick(View paramView) {
    this.l = paramView.getWidth() / 2;
    this.m = paramView.getHeight() / 2;
    i(true);
    return true;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    d();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\f3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */