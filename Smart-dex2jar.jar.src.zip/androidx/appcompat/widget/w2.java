package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

class w2 extends n2 {
  private final WeakReference<Context> b;
  
  public w2(Context paramContext, Resources paramResources) {
    super(paramResources);
    this.b = new WeakReference<Context>(paramContext);
  }
  
  public Drawable getDrawable(int paramInt) throws Resources.NotFoundException {
    Drawable drawable = a(paramInt);
    Context context = this.b.get();
    if (drawable != null && context != null)
      m2.h().x(context, paramInt, drawable); 
    return drawable;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\w2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */