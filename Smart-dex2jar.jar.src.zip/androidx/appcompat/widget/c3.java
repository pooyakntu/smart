package androidx.appcompat.widget;

import android.os.Build;
import android.view.View;

public class c3 {
  public static void a(View paramView, CharSequence paramCharSequence) {
    if (Build.VERSION.SDK_INT >= 26) {
      a.a(paramView, paramCharSequence);
      return;
    } 
    f3.h(paramView, paramCharSequence);
  }
  
  static class a {
    static void a(View param1View, CharSequence param1CharSequence) {
      b3.a(param1View, param1CharSequence);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\c3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */