package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.core.widget.d0;
import androidx.core.widget.e0;
import f.a;
import g.a;

public class i0 extends RadioButton implements d0, e0 {
  private final h g;
  
  private final d h;
  
  private final v0 i;
  
  private k j;
  
  public i0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.G);
  }
  
  public i0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    h h1 = new h((CompoundButton)this);
    this.g = h1;
    h1.e(paramAttributeSet, paramInt);
    d d1 = new d((View)this);
    this.h = d1;
    d1.e(paramAttributeSet, paramInt);
    v0 v01 = new v0((TextView)this);
    this.i = v01;
    v01.m(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private k getEmojiTextViewHelper() {
    if (this.j == null)
      this.j = new k((TextView)this); 
    return this.j;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.h;
    if (d1 != null)
      d1.b(); 
    v0 v01 = this.i;
    if (v01 != null)
      v01.b(); 
  }
  
  public int getCompoundPaddingLeft() {
    int j = super.getCompoundPaddingLeft();
    h h1 = this.g;
    int i = j;
    if (h1 != null)
      i = h1.b(j); 
    return i;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.h;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.h;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportButtonTintList() {
    h h1 = this.g;
    return (h1 != null) ? h1.c() : null;
  }
  
  public PorterDuff.Mode getSupportButtonTintMode() {
    h h1 = this.g;
    return (h1 != null) ? h1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.i.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.i.k();
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.h;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.h;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setButtonDrawable(int paramInt) {
    setButtonDrawable(a.b(getContext(), paramInt));
  }
  
  public void setButtonDrawable(Drawable paramDrawable) {
    super.setButtonDrawable(paramDrawable);
    h h1 = this.g;
    if (h1 != null)
      h1.f(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.i;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.i;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.h;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.h;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportButtonTintList(ColorStateList paramColorStateList) {
    h h1 = this.g;
    if (h1 != null)
      h1.g(paramColorStateList); 
  }
  
  public void setSupportButtonTintMode(PorterDuff.Mode paramMode) {
    h h1 = this.g;
    if (h1 != null)
      h1.h(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.i.w(paramColorStateList);
    this.i.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.i.x(paramMode);
    this.i.b();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\i0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */