package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.DataSetObserver;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.ThemedSpinnerAdapter;
import androidx.appcompat.view.menu.p;
import androidx.core.view.e1;

public class o0 extends Spinner {
  @SuppressLint({"ResourceType"})
  private static final int[] o = new int[] { 16843505 };
  
  private final d g;
  
  private final Context h;
  
  private b2 i;
  
  private SpinnerAdapter j;
  
  private final boolean k;
  
  private j l;
  
  int m;
  
  final Rect n;
  
  public o0(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.K);
  }
  
  public o0(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, -1);
  }
  
  public o0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this(paramContext, paramAttributeSet, paramInt1, paramInt2, null);
  }
  
  public o0(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2, Resources.Theme paramTheme) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: iload_3
    //   4: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   7: aload_0
    //   8: new android/graphics/Rect
    //   11: dup
    //   12: invokespecial <init> : ()V
    //   15: putfield n : Landroid/graphics/Rect;
    //   18: aload_0
    //   19: aload_0
    //   20: invokevirtual getContext : ()Landroid/content/Context;
    //   23: invokestatic a : (Landroid/view/View;Landroid/content/Context;)V
    //   26: aload_1
    //   27: aload_2
    //   28: getstatic f/j.x2 : [I
    //   31: iload_3
    //   32: iconst_0
    //   33: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/x2;
    //   36: astore #8
    //   38: aload_0
    //   39: new androidx/appcompat/widget/d
    //   42: dup
    //   43: aload_0
    //   44: invokespecial <init> : (Landroid/view/View;)V
    //   47: putfield g : Landroidx/appcompat/widget/d;
    //   50: aload #5
    //   52: ifnull -> 72
    //   55: aload_0
    //   56: new androidx/appcompat/view/d
    //   59: dup
    //   60: aload_1
    //   61: aload #5
    //   63: invokespecial <init> : (Landroid/content/Context;Landroid/content/res/Resources$Theme;)V
    //   66: putfield h : Landroid/content/Context;
    //   69: goto -> 110
    //   72: aload #8
    //   74: getstatic f/j.C2 : I
    //   77: iconst_0
    //   78: invokevirtual n : (II)I
    //   81: istore #6
    //   83: iload #6
    //   85: ifeq -> 105
    //   88: aload_0
    //   89: new androidx/appcompat/view/d
    //   92: dup
    //   93: aload_1
    //   94: iload #6
    //   96: invokespecial <init> : (Landroid/content/Context;I)V
    //   99: putfield h : Landroid/content/Context;
    //   102: goto -> 110
    //   105: aload_0
    //   106: aload_1
    //   107: putfield h : Landroid/content/Context;
    //   110: aconst_null
    //   111: astore #7
    //   113: iload #4
    //   115: istore #6
    //   117: iload #4
    //   119: iconst_m1
    //   120: if_icmpne -> 217
    //   123: aload_1
    //   124: aload_2
    //   125: getstatic androidx/appcompat/widget/o0.o : [I
    //   128: iload_3
    //   129: iconst_0
    //   130: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;
    //   133: astore #5
    //   135: iload #4
    //   137: istore #6
    //   139: aload #5
    //   141: astore #7
    //   143: aload #5
    //   145: iconst_0
    //   146: invokevirtual hasValue : (I)Z
    //   149: ifeq -> 165
    //   152: aload #5
    //   154: iconst_0
    //   155: iconst_0
    //   156: invokevirtual getInt : (II)I
    //   159: istore #6
    //   161: aload #5
    //   163: astore #7
    //   165: aload #7
    //   167: invokevirtual recycle : ()V
    //   170: goto -> 217
    //   173: astore_2
    //   174: aload #5
    //   176: astore_1
    //   177: goto -> 184
    //   180: astore_2
    //   181: aload #7
    //   183: astore_1
    //   184: aload_1
    //   185: ifnull -> 192
    //   188: aload_1
    //   189: invokevirtual recycle : ()V
    //   192: aload_2
    //   193: athrow
    //   194: aconst_null
    //   195: astore #5
    //   197: iload #4
    //   199: istore #6
    //   201: aload #5
    //   203: ifnull -> 217
    //   206: iload #4
    //   208: istore #6
    //   210: aload #5
    //   212: astore #7
    //   214: goto -> 165
    //   217: iload #6
    //   219: ifeq -> 331
    //   222: iload #6
    //   224: iconst_1
    //   225: if_icmpeq -> 231
    //   228: goto -> 362
    //   231: new androidx/appcompat/widget/o0$h
    //   234: dup
    //   235: aload_0
    //   236: aload_0
    //   237: getfield h : Landroid/content/Context;
    //   240: aload_2
    //   241: iload_3
    //   242: invokespecial <init> : (Landroidx/appcompat/widget/o0;Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   245: astore #5
    //   247: aload_0
    //   248: getfield h : Landroid/content/Context;
    //   251: aload_2
    //   252: getstatic f/j.x2 : [I
    //   255: iload_3
    //   256: iconst_0
    //   257: invokestatic v : (Landroid/content/Context;Landroid/util/AttributeSet;[III)Landroidx/appcompat/widget/x2;
    //   260: astore #7
    //   262: aload_0
    //   263: aload #7
    //   265: getstatic f/j.B2 : I
    //   268: bipush #-2
    //   270: invokevirtual m : (II)I
    //   273: putfield m : I
    //   276: aload #5
    //   278: aload #7
    //   280: getstatic f/j.z2 : I
    //   283: invokevirtual g : (I)Landroid/graphics/drawable/Drawable;
    //   286: invokevirtual c : (Landroid/graphics/drawable/Drawable;)V
    //   289: aload #5
    //   291: aload #8
    //   293: getstatic f/j.A2 : I
    //   296: invokevirtual o : (I)Ljava/lang/String;
    //   299: invokevirtual k : (Ljava/lang/CharSequence;)V
    //   302: aload #7
    //   304: invokevirtual w : ()V
    //   307: aload_0
    //   308: aload #5
    //   310: putfield l : Landroidx/appcompat/widget/o0$j;
    //   313: aload_0
    //   314: new androidx/appcompat/widget/o0$a
    //   317: dup
    //   318: aload_0
    //   319: aload_0
    //   320: aload #5
    //   322: invokespecial <init> : (Landroidx/appcompat/widget/o0;Landroid/view/View;Landroidx/appcompat/widget/o0$h;)V
    //   325: putfield i : Landroidx/appcompat/widget/b2;
    //   328: goto -> 362
    //   331: new androidx/appcompat/widget/o0$f
    //   334: dup
    //   335: aload_0
    //   336: invokespecial <init> : (Landroidx/appcompat/widget/o0;)V
    //   339: astore #5
    //   341: aload_0
    //   342: aload #5
    //   344: putfield l : Landroidx/appcompat/widget/o0$j;
    //   347: aload #5
    //   349: aload #8
    //   351: getstatic f/j.A2 : I
    //   354: invokevirtual o : (I)Ljava/lang/String;
    //   357: invokeinterface k : (Ljava/lang/CharSequence;)V
    //   362: aload #8
    //   364: getstatic f/j.y2 : I
    //   367: invokevirtual q : (I)[Ljava/lang/CharSequence;
    //   370: astore #5
    //   372: aload #5
    //   374: ifnull -> 402
    //   377: new android/widget/ArrayAdapter
    //   380: dup
    //   381: aload_1
    //   382: ldc 17367048
    //   384: aload #5
    //   386: invokespecial <init> : (Landroid/content/Context;I[Ljava/lang/Object;)V
    //   389: astore_1
    //   390: aload_1
    //   391: getstatic f/g.t : I
    //   394: invokevirtual setDropDownViewResource : (I)V
    //   397: aload_0
    //   398: aload_1
    //   399: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   402: aload #8
    //   404: invokevirtual w : ()V
    //   407: aload_0
    //   408: iconst_1
    //   409: putfield k : Z
    //   412: aload_0
    //   413: getfield j : Landroid/widget/SpinnerAdapter;
    //   416: astore_1
    //   417: aload_1
    //   418: ifnull -> 431
    //   421: aload_0
    //   422: aload_1
    //   423: invokevirtual setAdapter : (Landroid/widget/SpinnerAdapter;)V
    //   426: aload_0
    //   427: aconst_null
    //   428: putfield j : Landroid/widget/SpinnerAdapter;
    //   431: aload_0
    //   432: getfield g : Landroidx/appcompat/widget/d;
    //   435: aload_2
    //   436: iload_3
    //   437: invokevirtual e : (Landroid/util/AttributeSet;I)V
    //   440: return
    //   441: astore #5
    //   443: goto -> 194
    //   446: astore #7
    //   448: goto -> 197
    // Exception table:
    //   from	to	target	type
    //   123	135	441	java/lang/Exception
    //   123	135	180	finally
    //   143	161	446	java/lang/Exception
    //   143	161	173	finally
  }
  
  int a(SpinnerAdapter paramSpinnerAdapter, Drawable paramDrawable) {
    int m = 0;
    if (paramSpinnerAdapter == null)
      return 0; 
    int n = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 0);
    int i1 = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 0);
    int i = Math.max(0, getSelectedItemPosition());
    int i2 = Math.min(paramSpinnerAdapter.getCount(), i + 15);
    int k = Math.max(0, i - 15 - i2 - i);
    View view = null;
    i = 0;
    while (k < i2) {
      int i4 = paramSpinnerAdapter.getItemViewType(k);
      int i3 = m;
      if (i4 != m) {
        view = null;
        i3 = i4;
      } 
      view = paramSpinnerAdapter.getView(k, view, (ViewGroup)this);
      if (view.getLayoutParams() == null)
        view.setLayoutParams(new ViewGroup.LayoutParams(-2, -2)); 
      view.measure(n, i1);
      i = Math.max(i, view.getMeasuredWidth());
      k++;
      m = i3;
    } 
    k = i;
    if (paramDrawable != null) {
      paramDrawable.getPadding(this.n);
      Rect rect = this.n;
      k = i + rect.left + rect.right;
    } 
    return k;
  }
  
  void b() {
    this.l.n(d.b((View)this), d.a((View)this));
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.g;
    if (d1 != null)
      d1.b(); 
  }
  
  public int getDropDownHorizontalOffset() {
    j j1 = this.l;
    return (j1 != null) ? j1.d() : super.getDropDownHorizontalOffset();
  }
  
  public int getDropDownVerticalOffset() {
    j j1 = this.l;
    return (j1 != null) ? j1.o() : super.getDropDownVerticalOffset();
  }
  
  public int getDropDownWidth() {
    return (this.l != null) ? this.m : super.getDropDownWidth();
  }
  
  final j getInternalPopup() {
    return this.l;
  }
  
  public Drawable getPopupBackground() {
    j j1 = this.l;
    return (j1 != null) ? j1.i() : super.getPopupBackground();
  }
  
  public Context getPopupContext() {
    return this.h;
  }
  
  public CharSequence getPrompt() {
    j j1 = this.l;
    return (j1 != null) ? j1.g() : super.getPrompt();
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.g;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.g;
    return (d1 != null) ? d1.d() : null;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    j j1 = this.l;
    if (j1 != null && j1.a())
      this.l.dismiss(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.l != null && View.MeasureSpec.getMode(paramInt1) == Integer.MIN_VALUE)
      setMeasuredDimension(Math.min(Math.max(getMeasuredWidth(), a(getAdapter(), getBackground())), View.MeasureSpec.getSize(paramInt1)), getMeasuredHeight()); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    i i = (i)paramParcelable;
    super.onRestoreInstanceState(i.getSuperState());
    if (i.g) {
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.addOnGlobalLayoutListener(new b(this)); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    boolean bool;
    i i = new i(super.onSaveInstanceState());
    j j1 = this.l;
    if (j1 != null && j1.a()) {
      bool = true;
    } else {
      bool = false;
    } 
    i.g = bool;
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    b2 b21 = this.i;
    return (b21 != null && b21.onTouch((View)this, paramMotionEvent)) ? true : super.onTouchEvent(paramMotionEvent);
  }
  
  public boolean performClick() {
    j j1 = this.l;
    if (j1 != null) {
      if (!j1.a())
        b(); 
      return true;
    } 
    return super.performClick();
  }
  
  public void setAdapter(SpinnerAdapter paramSpinnerAdapter) {
    if (!this.k) {
      this.j = paramSpinnerAdapter;
      return;
    } 
    super.setAdapter(paramSpinnerAdapter);
    if (this.l != null) {
      Context context2 = this.h;
      Context context1 = context2;
      if (context2 == null)
        context1 = getContext(); 
      this.l.p(new g(paramSpinnerAdapter, context1.getTheme()));
    } 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.g;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.g;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setDropDownHorizontalOffset(int paramInt) {
    j j1 = this.l;
    if (j1 != null) {
      j1.m(paramInt);
      this.l.f(paramInt);
      return;
    } 
    super.setDropDownHorizontalOffset(paramInt);
  }
  
  public void setDropDownVerticalOffset(int paramInt) {
    j j1 = this.l;
    if (j1 != null) {
      j1.l(paramInt);
      return;
    } 
    super.setDropDownVerticalOffset(paramInt);
  }
  
  public void setDropDownWidth(int paramInt) {
    if (this.l != null) {
      this.m = paramInt;
      return;
    } 
    super.setDropDownWidth(paramInt);
  }
  
  public void setPopupBackgroundDrawable(Drawable paramDrawable) {
    j j1 = this.l;
    if (j1 != null) {
      j1.c(paramDrawable);
      return;
    } 
    super.setPopupBackgroundDrawable(paramDrawable);
  }
  
  public void setPopupBackgroundResource(int paramInt) {
    setPopupBackgroundDrawable(g.a.b(getPopupContext(), paramInt));
  }
  
  public void setPrompt(CharSequence paramCharSequence) {
    j j1 = this.l;
    if (j1 != null) {
      j1.k(paramCharSequence);
      return;
    } 
    super.setPrompt(paramCharSequence);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.g;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.g;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  class a extends b2 {
    a(o0 this$0, View param1View, o0.h param1h) {
      super(param1View);
    }
    
    public p b() {
      return this.p;
    }
    
    @SuppressLint({"SyntheticAccessor"})
    public boolean c() {
      if (!this.q.getInternalPopup().a())
        this.q.b(); 
      return true;
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(o0 this$0) {}
    
    public void onGlobalLayout() {
      if (!this.g.getInternalPopup().a())
        this.g.b(); 
      ViewTreeObserver viewTreeObserver = this.g.getViewTreeObserver();
      if (viewTreeObserver != null)
        o0.c.a(viewTreeObserver, this); 
    }
  }
  
  private static final class c {
    static void a(ViewTreeObserver param1ViewTreeObserver, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {
      param1ViewTreeObserver.removeOnGlobalLayoutListener(param1OnGlobalLayoutListener);
    }
  }
  
  private static final class d {
    static int a(View param1View) {
      return param1View.getTextAlignment();
    }
    
    static int b(View param1View) {
      return param1View.getTextDirection();
    }
    
    static void c(View param1View, int param1Int) {
      param1View.setTextAlignment(param1Int);
    }
    
    static void d(View param1View, int param1Int) {
      param1View.setTextDirection(param1Int);
    }
  }
  
  private static final class e {
    static void a(ThemedSpinnerAdapter param1ThemedSpinnerAdapter, Resources.Theme param1Theme) {
      if (!androidx.core.util.c.a(p0.a(param1ThemedSpinnerAdapter), param1Theme))
        q0.a(param1ThemedSpinnerAdapter, param1Theme); 
    }
  }
  
  class f implements j, DialogInterface.OnClickListener {
    androidx.appcompat.app.c g;
    
    private ListAdapter h;
    
    private CharSequence i;
    
    f(o0 this$0) {}
    
    public boolean a() {
      androidx.appcompat.app.c c1 = this.g;
      return (c1 != null) ? c1.isShowing() : false;
    }
    
    public void c(Drawable param1Drawable) {}
    
    public int d() {
      return 0;
    }
    
    public void dismiss() {
      androidx.appcompat.app.c c1 = this.g;
      if (c1 != null) {
        c1.dismiss();
        this.g = null;
      } 
    }
    
    public void f(int param1Int) {}
    
    public CharSequence g() {
      return this.i;
    }
    
    public Drawable i() {
      return null;
    }
    
    public void k(CharSequence param1CharSequence) {
      this.i = param1CharSequence;
    }
    
    public void l(int param1Int) {}
    
    public void m(int param1Int) {}
    
    public void n(int param1Int1, int param1Int2) {
      if (this.h == null)
        return; 
      androidx.appcompat.app.c.a a = new androidx.appcompat.app.c.a(this.j.getPopupContext());
      CharSequence charSequence = this.i;
      if (charSequence != null)
        a.h(charSequence); 
      androidx.appcompat.app.c c1 = a.g(this.h, this.j.getSelectedItemPosition(), this).a();
      this.g = c1;
      ListView listView = c1.h();
      o0.d.d((View)listView, param1Int1);
      o0.d.c((View)listView, param1Int2);
      this.g.show();
    }
    
    public int o() {
      return 0;
    }
    
    public void onClick(DialogInterface param1DialogInterface, int param1Int) {
      this.j.setSelection(param1Int);
      if (this.j.getOnItemClickListener() != null)
        this.j.performItemClick(null, param1Int, this.h.getItemId(param1Int)); 
      dismiss();
    }
    
    public void p(ListAdapter param1ListAdapter) {
      this.h = param1ListAdapter;
    }
  }
  
  private static class g implements ListAdapter, SpinnerAdapter {
    private SpinnerAdapter g;
    
    private ListAdapter h;
    
    public g(SpinnerAdapter param1SpinnerAdapter, Resources.Theme param1Theme) {
      this.g = param1SpinnerAdapter;
      if (param1SpinnerAdapter instanceof ListAdapter)
        this.h = (ListAdapter)param1SpinnerAdapter; 
      if (param1Theme != null) {
        if (Build.VERSION.SDK_INT >= 23 && param1SpinnerAdapter instanceof ThemedSpinnerAdapter) {
          o0.e.a((ThemedSpinnerAdapter)param1SpinnerAdapter, param1Theme);
          return;
        } 
        if (param1SpinnerAdapter instanceof t2) {
          param1SpinnerAdapter = param1SpinnerAdapter;
          if (param1SpinnerAdapter.getDropDownViewTheme() == null)
            param1SpinnerAdapter.setDropDownViewTheme(param1Theme); 
        } 
      } 
    }
    
    public boolean areAllItemsEnabled() {
      ListAdapter listAdapter = this.h;
      return (listAdapter != null) ? listAdapter.areAllItemsEnabled() : true;
    }
    
    public int getCount() {
      SpinnerAdapter spinnerAdapter = this.g;
      return (spinnerAdapter == null) ? 0 : spinnerAdapter.getCount();
    }
    
    public View getDropDownView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      SpinnerAdapter spinnerAdapter = this.g;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public Object getItem(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.g;
      return (spinnerAdapter == null) ? null : spinnerAdapter.getItem(param1Int);
    }
    
    public long getItemId(int param1Int) {
      SpinnerAdapter spinnerAdapter = this.g;
      return (spinnerAdapter == null) ? -1L : spinnerAdapter.getItemId(param1Int);
    }
    
    public int getItemViewType(int param1Int) {
      return 0;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      return getDropDownView(param1Int, param1View, param1ViewGroup);
    }
    
    public int getViewTypeCount() {
      return 1;
    }
    
    public boolean hasStableIds() {
      SpinnerAdapter spinnerAdapter = this.g;
      return (spinnerAdapter != null && spinnerAdapter.hasStableIds());
    }
    
    public boolean isEmpty() {
      return (getCount() == 0);
    }
    
    public boolean isEnabled(int param1Int) {
      ListAdapter listAdapter = this.h;
      return (listAdapter != null) ? listAdapter.isEnabled(param1Int) : true;
    }
    
    public void registerDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.g;
      if (spinnerAdapter != null)
        spinnerAdapter.registerDataSetObserver(param1DataSetObserver); 
    }
    
    public void unregisterDataSetObserver(DataSetObserver param1DataSetObserver) {
      SpinnerAdapter spinnerAdapter = this.g;
      if (spinnerAdapter != null)
        spinnerAdapter.unregisterDataSetObserver(param1DataSetObserver); 
    }
  }
  
  class h extends d2 implements j {
    private CharSequence P;
    
    ListAdapter Q;
    
    private final Rect R = new Rect();
    
    private int S;
    
    public h(o0 this$0, Context param1Context, AttributeSet param1AttributeSet, int param1Int) {
      super(param1Context, param1AttributeSet, param1Int);
      D((View)this$0);
      J(true);
      P(0);
      L(new a(this, this$0));
    }
    
    void T() {
      int i;
      Drawable drawable = i();
      if (drawable != null) {
        drawable.getPadding(this.T.n);
        if (i3.b((View)this.T)) {
          i = this.T.n.right;
        } else {
          i = -this.T.n.left;
        } 
      } else {
        Rect rect = this.T.n;
        rect.right = 0;
        rect.left = 0;
        i = 0;
      } 
      int m = this.T.getPaddingLeft();
      int n = this.T.getPaddingRight();
      int i1 = this.T.getWidth();
      o0 o01 = this.T;
      int k = o01.m;
      if (k == -2) {
        int i2 = o01.a((SpinnerAdapter)this.Q, i());
        k = (this.T.getContext().getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.T.n;
        int i3 = k - rect.left - rect.right;
        k = i2;
        if (i2 > i3)
          k = i3; 
        F(Math.max(k, i1 - m - n));
      } else if (k == -1) {
        F(i1 - m - n);
      } else {
        F(k);
      } 
      if (i3.b((View)this.T)) {
        i += i1 - n - z() - U();
      } else {
        i += m + U();
      } 
      f(i);
    }
    
    public int U() {
      return this.S;
    }
    
    boolean V(View param1View) {
      return (e1.Z(param1View) && param1View.getGlobalVisibleRect(this.R));
    }
    
    public CharSequence g() {
      return this.P;
    }
    
    public void k(CharSequence param1CharSequence) {
      this.P = param1CharSequence;
    }
    
    public void m(int param1Int) {
      this.S = param1Int;
    }
    
    public void n(int param1Int1, int param1Int2) {
      boolean bool = a();
      T();
      I(2);
      b();
      ListView listView = j();
      listView.setChoiceMode(1);
      o0.d.d((View)listView, param1Int1);
      o0.d.c((View)listView, param1Int2);
      Q(this.T.getSelectedItemPosition());
      if (bool)
        return; 
      ViewTreeObserver viewTreeObserver = this.T.getViewTreeObserver();
      if (viewTreeObserver != null) {
        b b = new b(this);
        viewTreeObserver.addOnGlobalLayoutListener(b);
        K(new c(this, b));
      } 
    }
    
    public void p(ListAdapter param1ListAdapter) {
      super.p(param1ListAdapter);
      this.Q = param1ListAdapter;
    }
    
    class a implements AdapterView.OnItemClickListener {
      a(o0.h this$0, o0 param2o0) {}
      
      public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
        this.h.T.setSelection(param2Int);
        if (this.h.T.getOnItemClickListener() != null) {
          o0.h h1 = this.h;
          h1.T.performItemClick(param2View, param2Int, h1.Q.getItemId(param2Int));
        } 
        this.h.dismiss();
      }
    }
    
    class b implements ViewTreeObserver.OnGlobalLayoutListener {
      b(o0.h this$0) {}
      
      public void onGlobalLayout() {
        o0.h h1 = this.g;
        if (!h1.V((View)h1.T)) {
          this.g.dismiss();
          return;
        } 
        this.g.T();
        o0.h.S(this.g);
      }
    }
    
    class c implements PopupWindow.OnDismissListener {
      c(o0.h this$0, ViewTreeObserver.OnGlobalLayoutListener param2OnGlobalLayoutListener) {}
      
      public void onDismiss() {
        ViewTreeObserver viewTreeObserver = this.h.T.getViewTreeObserver();
        if (viewTreeObserver != null)
          viewTreeObserver.removeGlobalOnLayoutListener(this.g); 
      }
    }
  }
  
  class a implements AdapterView.OnItemClickListener {
    a(o0 this$0, o0 param1o0) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.h.T.setSelection(param1Int);
      if (this.h.T.getOnItemClickListener() != null) {
        o0.h h1 = this.h;
        h1.T.performItemClick(param1View, param1Int, h1.Q.getItemId(param1Int));
      } 
      this.h.dismiss();
    }
  }
  
  class b implements ViewTreeObserver.OnGlobalLayoutListener {
    b(o0 this$0) {}
    
    public void onGlobalLayout() {
      o0.h h1 = this.g;
      if (!h1.V((View)h1.T)) {
        this.g.dismiss();
        return;
      } 
      this.g.T();
      o0.h.S(this.g);
    }
  }
  
  class c implements PopupWindow.OnDismissListener {
    c(o0 this$0, ViewTreeObserver.OnGlobalLayoutListener param1OnGlobalLayoutListener) {}
    
    public void onDismiss() {
      ViewTreeObserver viewTreeObserver = this.h.T.getViewTreeObserver();
      if (viewTreeObserver != null)
        viewTreeObserver.removeGlobalOnLayoutListener(this.g); 
    }
  }
  
  static class i extends View.BaseSavedState {
    public static final Parcelable.Creator<i> CREATOR = new a();
    
    boolean g;
    
    i(Parcel param1Parcel) {
      super(param1Parcel);
      boolean bool;
      if (param1Parcel.readByte() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.g = bool;
    }
    
    i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeByte((byte)this.g);
    }
    
    class a implements Parcelable.Creator<i> {
      public o0.i a(Parcel param2Parcel) {
        return new o0.i(param2Parcel);
      }
      
      public o0.i[] b(int param2Int) {
        return new o0.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.Creator<i> {
    public o0.i a(Parcel param1Parcel) {
      return new o0.i(param1Parcel);
    }
    
    public o0.i[] b(int param1Int) {
      return new o0.i[param1Int];
    }
  }
  
  static interface j {
    boolean a();
    
    void c(Drawable param1Drawable);
    
    int d();
    
    void dismiss();
    
    void f(int param1Int);
    
    CharSequence g();
    
    Drawable i();
    
    void k(CharSequence param1CharSequence);
    
    void l(int param1Int);
    
    void m(int param1Int);
    
    void n(int param1Int1, int param1Int2);
    
    int o();
    
    void p(ListAdapter param1ListAdapter);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\o0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */