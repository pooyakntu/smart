package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.view.menu.p;
import androidx.core.view.e1;
import androidx.core.widget.k;
import f.j;
import java.lang.reflect.Method;

public class d2 implements p {
  private static Method M;
  
  private static Method N;
  
  private static Method O;
  
  private AdapterView.OnItemClickListener A;
  
  private AdapterView.OnItemSelectedListener B;
  
  final i C = new i(this);
  
  private final h D = new h(this);
  
  private final g E = new g(this);
  
  private final e F = new e(this);
  
  private Runnable G;
  
  final Handler H;
  
  private final Rect I = new Rect();
  
  private Rect J;
  
  private boolean K;
  
  PopupWindow L;
  
  private Context g;
  
  private ListAdapter h;
  
  z1 i;
  
  private int j = -2;
  
  private int k = -2;
  
  private int l;
  
  private int m;
  
  private int n = 1002;
  
  private boolean o;
  
  private boolean p;
  
  private boolean q;
  
  private int r = 0;
  
  private boolean s = false;
  
  private boolean t = false;
  
  int u = Integer.MAX_VALUE;
  
  private View v;
  
  private int w = 0;
  
  private DataSetObserver x;
  
  private View y;
  
  private Drawable z;
  
  static {
    if (Build.VERSION.SDK_INT <= 28) {
      try {
        M = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", new Class[] { boolean.class });
      } catch (NoSuchMethodException noSuchMethodException) {}
      try {
        O = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", new Class[] { Rect.class });
      } catch (NoSuchMethodException noSuchMethodException) {}
    } 
    if (Build.VERSION.SDK_INT <= 23)
      try {
        N = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", new Class[] { View.class, int.class, boolean.class });
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        return;
      }  
  }
  
  public d2(Context paramContext) {
    this(paramContext, null, f.a.E);
  }
  
  public d2(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    this(paramContext, paramAttributeSet, paramInt, 0);
  }
  
  public d2(Context paramContext, AttributeSet paramAttributeSet, int paramInt1, int paramInt2) {
    this.g = paramContext;
    this.H = new Handler(paramContext.getMainLooper());
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, j.l1, paramInt1, paramInt2);
    this.l = typedArray.getDimensionPixelOffset(j.m1, 0);
    int j = typedArray.getDimensionPixelOffset(j.n1, 0);
    this.m = j;
    if (j != 0)
      this.o = true; 
    typedArray.recycle();
    o o = new o(paramContext, paramAttributeSet, paramInt1, paramInt2);
    this.L = o;
    o.setInputMethodMode(1);
  }
  
  private void C() {
    View view = this.v;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(this.v); 
    } 
  }
  
  private void O(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = M;
      if (method != null)
        try {
          method.invoke(this.L, new Object[] { Boolean.valueOf(paramBoolean) });
          return;
        } catch (Exception exception) {
          return;
        }  
    } else {
      d.b(this.L, paramBoolean);
    } 
  }
  
  private int q() {
    byte b1;
    byte b2;
    z1 z11 = this.i;
    boolean bool = true;
    if (z11 == null) {
      LinearLayout.LayoutParams layoutParams1;
      LinearLayout.LayoutParams layoutParams2;
      Context context = this.g;
      this.G = new a(this);
      z1 z13 = s(context, this.K ^ true);
      this.i = z13;
      Drawable drawable1 = this.z;
      if (drawable1 != null)
        z13.setSelector(drawable1); 
      this.i.setAdapter(this.h);
      this.i.setOnItemClickListener(this.A);
      this.i.setFocusable(true);
      this.i.setFocusableInTouchMode(true);
      this.i.setOnItemSelectedListener(new b(this));
      this.i.setOnScrollListener(this.E);
      AdapterView.OnItemSelectedListener onItemSelectedListener = this.B;
      if (onItemSelectedListener != null)
        this.i.setOnItemSelectedListener(onItemSelectedListener); 
      z1 z12 = this.i;
      View view = this.v;
      if (view != null) {
        boolean bool1;
        StringBuilder stringBuilder;
        LinearLayout linearLayout = new LinearLayout(context);
        linearLayout.setOrientation(1);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0F);
        b1 = this.w;
        if (b1 != 0) {
          if (b1 != 1) {
            stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid hint position ");
            stringBuilder.append(this.w);
          } else {
            linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
            linearLayout.addView(view);
          } 
        } else {
          linearLayout.addView(view);
          linearLayout.addView((View)stringBuilder, (ViewGroup.LayoutParams)layoutParams);
        } 
        b1 = this.k;
        if (b1 >= 0) {
          bool1 = true;
        } else {
          b1 = 0;
          bool1 = false;
        } 
        view.measure(View.MeasureSpec.makeMeasureSpec(b1, bool1), 0);
        layoutParams2 = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
      } else {
        b1 = 0;
        layoutParams1 = layoutParams2;
      } 
      this.L.setContentView((View)layoutParams1);
    } else {
      ViewGroup viewGroup = (ViewGroup)this.L.getContentView();
      View view = this.v;
      if (view != null) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)view.getLayoutParams();
        b1 = view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
      } else {
        b1 = 0;
      } 
    } 
    Drawable drawable = this.L.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.I);
      Rect rect = this.I;
      int n = rect.top;
      int m = rect.bottom + n;
      b2 = m;
      if (!this.o) {
        this.m = -n;
        b2 = m;
      } 
    } else {
      this.I.setEmpty();
      b2 = 0;
    } 
    if (this.L.getInputMethodMode() != 2)
      bool = false; 
    int k = u(t(), this.m, bool);
    if (this.s || this.j == -1)
      return k + b2; 
    int j = this.k;
    if (j != -2) {
      if (j != -1) {
        j = View.MeasureSpec.makeMeasureSpec(j, 1073741824);
      } else {
        j = (this.g.getResources().getDisplayMetrics()).widthPixels;
        Rect rect = this.I;
        j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, 1073741824);
      } 
    } else {
      j = (this.g.getResources().getDisplayMetrics()).widthPixels;
      Rect rect = this.I;
      j = View.MeasureSpec.makeMeasureSpec(j - rect.left + rect.right, -2147483648);
    } 
    k = this.i.d(j, 0, -1, k - b1, -1);
    j = b1;
    if (k > 0)
      j = b1 + b2 + this.i.getPaddingTop() + this.i.getPaddingBottom(); 
    return k + j;
  }
  
  private int u(View paramView, int paramInt, boolean paramBoolean) {
    if (Build.VERSION.SDK_INT <= 23) {
      Method method = N;
      if (method != null)
        try {
          return ((Integer)method.invoke(this.L, new Object[] { paramView, Integer.valueOf(paramInt), Boolean.valueOf(paramBoolean) })).intValue();
        } catch (Exception exception) {} 
      return this.L.getMaxAvailableHeight(paramView, paramInt);
    } 
    return c.a(this.L, paramView, paramInt, paramBoolean);
  }
  
  public boolean A() {
    return (this.L.getInputMethodMode() == 2);
  }
  
  public boolean B() {
    return this.K;
  }
  
  public void D(View paramView) {
    this.y = paramView;
  }
  
  public void E(int paramInt) {
    this.L.setAnimationStyle(paramInt);
  }
  
  public void F(int paramInt) {
    Drawable drawable = this.L.getBackground();
    if (drawable != null) {
      drawable.getPadding(this.I);
      Rect rect = this.I;
      this.k = rect.left + rect.right + paramInt;
      return;
    } 
    R(paramInt);
  }
  
  public void G(int paramInt) {
    this.r = paramInt;
  }
  
  public void H(Rect paramRect) {
    if (paramRect != null) {
      paramRect = new Rect(paramRect);
    } else {
      paramRect = null;
    } 
    this.J = paramRect;
  }
  
  public void I(int paramInt) {
    this.L.setInputMethodMode(paramInt);
  }
  
  public void J(boolean paramBoolean) {
    this.K = paramBoolean;
    this.L.setFocusable(paramBoolean);
  }
  
  public void K(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.L.setOnDismissListener(paramOnDismissListener);
  }
  
  public void L(AdapterView.OnItemClickListener paramOnItemClickListener) {
    this.A = paramOnItemClickListener;
  }
  
  public void M(AdapterView.OnItemSelectedListener paramOnItemSelectedListener) {
    this.B = paramOnItemSelectedListener;
  }
  
  public void N(boolean paramBoolean) {
    this.q = true;
    this.p = paramBoolean;
  }
  
  public void P(int paramInt) {
    this.w = paramInt;
  }
  
  public void Q(int paramInt) {
    z1 z11 = this.i;
    if (a() && z11 != null) {
      z11.setListSelectionHidden(false);
      z11.setSelection(paramInt);
      if (z11.getChoiceMode() != 0)
        z11.setItemChecked(paramInt, true); 
    } 
  }
  
  public void R(int paramInt) {
    this.k = paramInt;
  }
  
  public boolean a() {
    return this.L.isShowing();
  }
  
  public void b() {
    int j;
    int k = q();
    boolean bool1 = A();
    k.b(this.L, this.n);
    boolean bool2 = this.L.isShowing();
    boolean bool = true;
    if (bool2) {
      if (!e1.Z(t()))
        return; 
      int n = this.k;
      if (n == -1) {
        j = -1;
      } else {
        j = n;
        if (n == -2)
          j = t().getWidth(); 
      } 
      n = this.j;
      if (n == -1) {
        if (!bool1)
          k = -1; 
        if (bool1) {
          PopupWindow popupWindow2 = this.L;
          if (this.k == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.L.setHeight(0);
        } else {
          PopupWindow popupWindow2 = this.L;
          if (this.k == -1) {
            n = -1;
          } else {
            n = 0;
          } 
          popupWindow2.setWidth(n);
          this.L.setHeight(-1);
        } 
      } else if (n != -2) {
        k = n;
      } 
      PopupWindow popupWindow1 = this.L;
      if (this.t || this.s)
        bool = false; 
      popupWindow1.setOutsideTouchable(bool);
      popupWindow1 = this.L;
      View view = t();
      n = this.l;
      int i1 = this.m;
      if (j < 0)
        j = -1; 
      if (k < 0)
        k = -1; 
      popupWindow1.update(view, n, i1, j, k);
      return;
    } 
    int m = this.k;
    if (m == -1) {
      j = -1;
    } else {
      j = m;
      if (m == -2)
        j = t().getWidth(); 
    } 
    m = this.j;
    if (m == -1) {
      k = -1;
    } else if (m != -2) {
      k = m;
    } 
    this.L.setWidth(j);
    this.L.setHeight(k);
    O(true);
    PopupWindow popupWindow = this.L;
    if (!this.t && !this.s) {
      bool = true;
    } else {
      bool = false;
    } 
    popupWindow.setOutsideTouchable(bool);
    this.L.setTouchInterceptor(this.D);
    if (this.q)
      k.a(this.L, this.p); 
    if (Build.VERSION.SDK_INT <= 28) {
      Method method = O;
      if (method != null)
        try {
          method.invoke(this.L, new Object[] { this.J });
        } catch (Exception exception) {} 
    } else {
      d.a(this.L, this.J);
    } 
    k.c(this.L, t(), this.l, this.m, this.r);
    this.i.setSelection(-1);
    if (!this.K || this.i.isInTouchMode())
      r(); 
    if (!this.K)
      this.H.post(this.F); 
  }
  
  public void c(Drawable paramDrawable) {
    this.L.setBackgroundDrawable(paramDrawable);
  }
  
  public int d() {
    return this.l;
  }
  
  public void dismiss() {
    this.L.dismiss();
    C();
    this.L.setContentView(null);
    this.i = null;
    this.H.removeCallbacks(this.C);
  }
  
  public void f(int paramInt) {
    this.l = paramInt;
  }
  
  public Drawable i() {
    return this.L.getBackground();
  }
  
  public ListView j() {
    return this.i;
  }
  
  public void l(int paramInt) {
    this.m = paramInt;
    this.o = true;
  }
  
  public int o() {
    return !this.o ? 0 : this.m;
  }
  
  public void p(ListAdapter paramListAdapter) {
    DataSetObserver dataSetObserver = this.x;
    if (dataSetObserver == null) {
      this.x = new f(this);
    } else {
      ListAdapter listAdapter = this.h;
      if (listAdapter != null)
        listAdapter.unregisterDataSetObserver(dataSetObserver); 
    } 
    this.h = paramListAdapter;
    if (paramListAdapter != null)
      paramListAdapter.registerDataSetObserver(this.x); 
    z1 z11 = this.i;
    if (z11 != null)
      z11.setAdapter(this.h); 
  }
  
  public void r() {
    z1 z11 = this.i;
    if (z11 != null) {
      z11.setListSelectionHidden(true);
      z11.requestLayout();
    } 
  }
  
  z1 s(Context paramContext, boolean paramBoolean) {
    return new z1(paramContext, paramBoolean);
  }
  
  public View t() {
    return this.y;
  }
  
  public Object v() {
    return !a() ? null : this.i.getSelectedItem();
  }
  
  public long w() {
    return !a() ? Long.MIN_VALUE : this.i.getSelectedItemId();
  }
  
  public int x() {
    return !a() ? -1 : this.i.getSelectedItemPosition();
  }
  
  public View y() {
    return !a() ? null : this.i.getSelectedView();
  }
  
  public int z() {
    return this.k;
  }
  
  class a implements Runnable {
    a(d2 this$0) {}
    
    public void run() {
      View view = this.g.t();
      if (view != null && view.getWindowToken() != null)
        this.g.b(); 
    }
  }
  
  class b implements AdapterView.OnItemSelectedListener {
    b(d2 this$0) {}
    
    public void onItemSelected(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (param1Int != -1) {
        z1 z1 = this.g.i;
        if (z1 != null)
          z1.setListSelectionHidden(false); 
      } 
    }
    
    public void onNothingSelected(AdapterView<?> param1AdapterView) {}
  }
  
  static class c {
    static int a(PopupWindow param1PopupWindow, View param1View, int param1Int, boolean param1Boolean) {
      return e2.a(param1PopupWindow, param1View, param1Int, param1Boolean);
    }
  }
  
  static class d {
    static void a(PopupWindow param1PopupWindow, Rect param1Rect) {
      f2.a(param1PopupWindow, param1Rect);
    }
    
    static void b(PopupWindow param1PopupWindow, boolean param1Boolean) {
      g2.a(param1PopupWindow, param1Boolean);
    }
  }
  
  private class e implements Runnable {
    e(d2 this$0) {}
    
    public void run() {
      this.g.r();
    }
  }
  
  private class f extends DataSetObserver {
    f(d2 this$0) {}
    
    public void onChanged() {
      if (this.a.a())
        this.a.b(); 
    }
    
    public void onInvalidated() {
      this.a.dismiss();
    }
  }
  
  private class g implements AbsListView.OnScrollListener {
    g(d2 this$0) {}
    
    public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {}
    
    public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {
      if (param1Int == 1 && !this.a.A() && this.a.L.getContentView() != null) {
        d2 d21 = this.a;
        d21.H.removeCallbacks(d21.C);
        this.a.C.run();
      } 
    }
  }
  
  private class h implements View.OnTouchListener {
    h(d2 this$0) {}
    
    public boolean onTouch(View param1View, MotionEvent param1MotionEvent) {
      int i = param1MotionEvent.getAction();
      int j = (int)param1MotionEvent.getX();
      int k = (int)param1MotionEvent.getY();
      if (i == 0) {
        PopupWindow popupWindow = this.g.L;
        if (popupWindow != null && popupWindow.isShowing() && j >= 0 && j < this.g.L.getWidth() && k >= 0 && k < this.g.L.getHeight()) {
          d2 d21 = this.g;
          d21.H.postDelayed(d21.C, 250L);
          return false;
        } 
      } 
      if (i == 1) {
        d2 d21 = this.g;
        d21.H.removeCallbacks(d21.C);
      } 
      return false;
    }
  }
  
  private class i implements Runnable {
    i(d2 this$0) {}
    
    public void run() {
      z1 z1 = this.g.i;
      if (z1 != null && e1.Z((View)z1) && this.g.i.getCount() > this.g.i.getChildCount()) {
        int j = this.g.i.getChildCount();
        d2 d21 = this.g;
        if (j <= d21.u) {
          d21.L.setInputMethodMode(2);
          this.g.b();
        } 
      } 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\d2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */