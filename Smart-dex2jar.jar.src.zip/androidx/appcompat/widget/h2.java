package androidx.appcompat.widget;

import android.view.MenuItem;
import androidx.appcompat.view.menu.g;

public interface h2 {
  void e(g paramg, MenuItem paramMenuItem);
  
  void h(g paramg, MenuItem paramMenuItem);
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\h2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */