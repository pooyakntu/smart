package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import androidx.core.graphics.g;
import androidx.core.text.w;
import androidx.core.widget.e0;
import androidx.core.widget.q;
import java.util.concurrent.Future;

public class AppCompatTextView extends TextView implements e0 {
  private final d g;
  
  private final v0 h;
  
  private final u0 i;
  
  private k j;
  
  private boolean k = false;
  
  private a l = null;
  
  private Future<w> m;
  
  public AppCompatTextView(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 16842884);
  }
  
  public AppCompatTextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    d d1 = new d((View)this);
    this.g = d1;
    d1.e(paramAttributeSet, paramInt);
    v0 v01 = new v0(this);
    this.h = v01;
    v01.m(paramAttributeSet, paramInt);
    v01.b();
    this.i = new u0(this);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private k getEmojiTextViewHelper() {
    if (this.j == null)
      this.j = new k(this); 
    return this.j;
  }
  
  private void q() {
    Future<w> future = this.m;
    if (future != null)
      try {
        this.m = null;
        q.n(this, future.get());
        return;
      } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
        return;
      }  
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.g;
    if (d1 != null)
      d1.b(); 
    v0 v01 = this.h;
    if (v01 != null)
      v01.b(); 
  }
  
  public int getAutoSizeMaxTextSize() {
    if (i3.b)
      return getSuperCaller().d(); 
    v0 v01 = this.h;
    return (v01 != null) ? v01.e() : -1;
  }
  
  public int getAutoSizeMinTextSize() {
    if (i3.b)
      return getSuperCaller().i(); 
    v0 v01 = this.h;
    return (v01 != null) ? v01.f() : -1;
  }
  
  public int getAutoSizeStepGranularity() {
    if (i3.b)
      return getSuperCaller().k(); 
    v0 v01 = this.h;
    return (v01 != null) ? v01.g() : -1;
  }
  
  public int[] getAutoSizeTextAvailableSizes() {
    if (i3.b)
      return getSuperCaller().b(); 
    v0 v01 = this.h;
    return (v01 != null) ? v01.h() : new int[0];
  }
  
  @SuppressLint({"WrongConstant"})
  public int getAutoSizeTextType() {
    boolean bool1 = i3.b;
    boolean bool = false;
    if (bool1) {
      if (getSuperCaller().h() == 1)
        bool = true; 
      return bool;
    } 
    v0 v01 = this.h;
    return (v01 != null) ? v01.i() : 0;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return q.q(super.getCustomSelectionActionModeCallback());
  }
  
  public int getFirstBaselineToTopHeight() {
    return q.b(this);
  }
  
  public int getLastBaselineToBottomHeight() {
    return q.c(this);
  }
  
  a getSuperCaller() {
    if (this.l == null) {
      int i = Build.VERSION.SDK_INT;
      if (i >= 28) {
        this.l = new c(this);
      } else if (i >= 26) {
        this.l = new b(this);
      } 
    } 
    return this.l;
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.g;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.g;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.h.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.h.k();
  }
  
  public CharSequence getText() {
    q();
    return super.getText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      u0 u01 = this.i;
      if (u01 != null)
        return u01.a(); 
    } 
    return getSuperCaller().c();
  }
  
  public w.a getTextMetricsParamsCompat() {
    return q.g(this);
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = super.onCreateInputConnection(paramEditorInfo);
    this.h.r(this, inputConnection, paramEditorInfo);
    return l.a(inputConnection, paramEditorInfo, (View)this);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.o(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    q();
    super.onMeasure(paramInt1, paramInt2);
  }
  
  protected void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {
    super.onTextChanged(paramCharSequence, paramInt1, paramInt2, paramInt3);
    v0 v01 = this.h;
    if (v01 != null && !i3.b && v01.l()) {
      paramInt1 = 1;
    } else {
      paramInt1 = 0;
    } 
    if (paramInt1 != 0)
      this.h.c(); 
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setAutoSizeTextTypeUniformWithConfiguration(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws IllegalArgumentException {
    if (i3.b) {
      getSuperCaller().g(paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    v0 v01 = this.h;
    if (v01 != null)
      v01.t(paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  public void setAutoSizeTextTypeUniformWithPresetSizes(int[] paramArrayOfint, int paramInt) throws IllegalArgumentException {
    if (i3.b) {
      getSuperCaller().a(paramArrayOfint, paramInt);
      return;
    } 
    v0 v01 = this.h;
    if (v01 != null)
      v01.u(paramArrayOfint, paramInt); 
  }
  
  public void setAutoSizeTextTypeWithDefaults(int paramInt) {
    if (i3.b) {
      getSuperCaller().l(paramInt);
      return;
    } 
    v0 v01 = this.h;
    if (v01 != null)
      v01.v(paramInt); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.g;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.g;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = g.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = g.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = g.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = g.a.b(context, paramInt4); 
    setCompoundDrawablesRelativeWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelativeWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    Drawable drawable1;
    Drawable drawable2;
    Drawable drawable3;
    Context context = getContext();
    Drawable drawable4 = null;
    if (paramInt1 != 0) {
      drawable1 = g.a.b(context, paramInt1);
    } else {
      drawable1 = null;
    } 
    if (paramInt2 != 0) {
      drawable2 = g.a.b(context, paramInt2);
    } else {
      drawable2 = null;
    } 
    if (paramInt3 != 0) {
      drawable3 = g.a.b(context, paramInt3);
    } else {
      drawable3 = null;
    } 
    if (paramInt4 != 0)
      drawable4 = g.a.b(context, paramInt4); 
    setCompoundDrawablesWithIntrinsicBounds(drawable1, drawable2, drawable3, drawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesWithIntrinsicBounds(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesWithIntrinsicBounds(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(q.r(this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setFirstBaselineToTopHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().j(paramInt);
      return;
    } 
    q.k(this, paramInt);
  }
  
  public void setLastBaselineToBottomHeight(int paramInt) {
    if (Build.VERSION.SDK_INT >= 28) {
      getSuperCaller().f(paramInt);
      return;
    } 
    q.l(this, paramInt);
  }
  
  public void setLineHeight(int paramInt) {
    q.m(this, paramInt);
  }
  
  public void setPrecomputedText(w paramw) {
    q.n(this, paramw);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.g;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.g;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.h.w(paramColorStateList);
    this.h.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.h.x(paramMode);
    this.h.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    v0 v01 = this.h;
    if (v01 != null)
      v01.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      u0 u01 = this.i;
      if (u01 != null) {
        u01.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().e(paramTextClassifier);
  }
  
  public void setTextFuture(Future<w> paramFuture) {
    this.m = paramFuture;
    if (paramFuture != null)
      requestLayout(); 
  }
  
  public void setTextMetricsParamsCompat(w.a parama) {
    q.p(this, parama);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    if (i3.b) {
      super.setTextSize(paramInt, paramFloat);
      return;
    } 
    v0 v01 = this.h;
    if (v01 != null)
      v01.A(paramInt, paramFloat); 
  }
  
  public void setTypeface(Typeface paramTypeface, int paramInt) {
    Typeface typeface;
    if (this.k)
      return; 
    if (paramTypeface != null && paramInt > 0) {
      typeface = g.a(getContext(), paramTypeface, paramInt);
    } else {
      typeface = null;
    } 
    this.k = true;
    if (typeface != null)
      paramTypeface = typeface; 
    try {
      super.setTypeface(paramTypeface, paramInt);
      return;
    } finally {
      this.k = false;
    } 
  }
  
  private static interface a {
    void a(int[] param1ArrayOfint, int param1Int);
    
    int[] b();
    
    TextClassifier c();
    
    int d();
    
    void e(TextClassifier param1TextClassifier);
    
    void f(int param1Int);
    
    void g(int param1Int1, int param1Int2, int param1Int3, int param1Int4);
    
    int h();
    
    int i();
    
    void j(int param1Int);
    
    int k();
    
    void l(int param1Int);
  }
  
  class b implements a {
    b(AppCompatTextView this$0) {}
    
    public void a(int[] param1ArrayOfint, int param1Int) {
      AppCompatTextView.n(this.a, param1ArrayOfint, param1Int);
    }
    
    public int[] b() {
      return AppCompatTextView.j(this.a);
    }
    
    public TextClassifier c() {
      return AppCompatTextView.l(this.a);
    }
    
    public int d() {
      return AppCompatTextView.e(this.a);
    }
    
    public void e(TextClassifier param1TextClassifier) {
      AppCompatTextView.p(this.a, param1TextClassifier);
    }
    
    public void f(int param1Int) {}
    
    public void g(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      AppCompatTextView.m(this.a, param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public int h() {
      return AppCompatTextView.k(this.a);
    }
    
    public int i() {
      return AppCompatTextView.g(this.a);
    }
    
    public void j(int param1Int) {}
    
    public int k() {
      return AppCompatTextView.i(this.a);
    }
    
    public void l(int param1Int) {
      AppCompatTextView.o(this.a, param1Int);
    }
  }
  
  class c extends b {
    c(AppCompatTextView this$0) {
      super(this$0);
    }
    
    public void f(int param1Int) {
      AppCompatTextView.h(this.b, param1Int);
    }
    
    public void j(int param1Int) {
      AppCompatTextView.f(this.b, param1Int);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\AppCompatTextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */