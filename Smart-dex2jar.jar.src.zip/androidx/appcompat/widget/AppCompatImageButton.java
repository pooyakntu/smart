package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import f.a;

public class AppCompatImageButton extends ImageButton {
  private final d g;
  
  private final m h;
  
  private boolean i = false;
  
  public AppCompatImageButton(Context paramContext) {
    this(paramContext, null);
  }
  
  public AppCompatImageButton(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.C);
  }
  
  public AppCompatImageButton(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    d d1 = new d((View)this);
    this.g = d1;
    d1.e(paramAttributeSet, paramInt);
    m m1 = new m((ImageView)this);
    this.h = m1;
    m1.g(paramAttributeSet, paramInt);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.g;
    if (d1 != null)
      d1.b(); 
    m m1 = this.h;
    if (m1 != null)
      m1.c(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.g;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.g;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportImageTintList() {
    m m1 = this.h;
    return (m1 != null) ? m1.d() : null;
  }
  
  public PorterDuff.Mode getSupportImageTintMode() {
    m m1 = this.h;
    return (m1 != null) ? m1.e() : null;
  }
  
  public boolean hasOverlappingRendering() {
    return (this.h.f() && super.hasOverlappingRendering());
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.g;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.g;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setImageBitmap(Bitmap paramBitmap) {
    super.setImageBitmap(paramBitmap);
    m m1 = this.h;
    if (m1 != null)
      m1.c(); 
  }
  
  public void setImageDrawable(Drawable paramDrawable) {
    m m2 = this.h;
    if (m2 != null && paramDrawable != null && !this.i)
      m2.h(paramDrawable); 
    super.setImageDrawable(paramDrawable);
    m m1 = this.h;
    if (m1 != null) {
      m1.c();
      if (!this.i)
        this.h.b(); 
    } 
  }
  
  public void setImageLevel(int paramInt) {
    super.setImageLevel(paramInt);
    this.i = true;
  }
  
  public void setImageResource(int paramInt) {
    this.h.i(paramInt);
  }
  
  public void setImageURI(Uri paramUri) {
    super.setImageURI(paramUri);
    m m1 = this.h;
    if (m1 != null)
      m1.c(); 
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.g;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.g;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportImageTintList(ColorStateList paramColorStateList) {
    m m1 = this.h;
    if (m1 != null)
      m1.j(paramColorStateList); 
  }
  
  public void setSupportImageTintMode(PorterDuff.Mode paramMode) {
    m m1 = this.h;
    if (m1 != null)
      m1.k(paramMode); 
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\AppCompatImageButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */