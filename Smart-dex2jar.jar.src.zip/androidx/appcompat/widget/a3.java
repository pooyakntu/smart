package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.e1;
import androidx.core.view.e3;
import androidx.core.view.f3;
import androidx.core.view.g3;
import f.e;
import f.f;
import f.h;
import f.j;

public class a3 implements s1 {
  Toolbar a;
  
  private int b;
  
  private View c;
  
  private View d;
  
  private Drawable e;
  
  private Drawable f;
  
  private Drawable g;
  
  private boolean h;
  
  CharSequence i;
  
  private CharSequence j;
  
  private CharSequence k;
  
  Window.Callback l;
  
  boolean m;
  
  private c n;
  
  private int o;
  
  private int p;
  
  private Drawable q;
  
  public a3(Toolbar paramToolbar, boolean paramBoolean) {
    this(paramToolbar, paramBoolean, h.a, e.n);
  }
  
  public a3(Toolbar paramToolbar, boolean paramBoolean, int paramInt1, int paramInt2) {
    boolean bool;
    this.o = 0;
    this.p = 0;
    this.a = paramToolbar;
    this.i = paramToolbar.getTitle();
    this.j = paramToolbar.getSubtitle();
    if (this.i != null) {
      bool = true;
    } else {
      bool = false;
    } 
    this.h = bool;
    this.g = paramToolbar.getNavigationIcon();
    x2 x2 = x2.v(paramToolbar.getContext(), null, j.a, f.a.c, 0);
    this.q = x2.g(j.l);
    if (paramBoolean) {
      CharSequence charSequence = x2.p(j.r);
      if (!TextUtils.isEmpty(charSequence))
        E(charSequence); 
      charSequence = x2.p(j.p);
      if (!TextUtils.isEmpty(charSequence))
        D(charSequence); 
      Drawable drawable = x2.g(j.n);
      if (drawable != null)
        z(drawable); 
      drawable = x2.g(j.m);
      if (drawable != null)
        setIcon(drawable); 
      if (this.g == null) {
        drawable = this.q;
        if (drawable != null)
          C(drawable); 
      } 
      k(x2.k(j.h, 0));
      paramInt2 = x2.n(j.g, 0);
      if (paramInt2 != 0) {
        x(LayoutInflater.from(this.a.getContext()).inflate(paramInt2, this.a, false));
        k(this.b | 0x10);
      } 
      paramInt2 = x2.m(j.j, 0);
      if (paramInt2 > 0) {
        ViewGroup.LayoutParams layoutParams = this.a.getLayoutParams();
        layoutParams.height = paramInt2;
        this.a.setLayoutParams(layoutParams);
      } 
      paramInt2 = x2.e(j.f, -1);
      int i = x2.e(j.e, -1);
      if (paramInt2 >= 0 || i >= 0)
        this.a.J(Math.max(paramInt2, 0), Math.max(i, 0)); 
      paramInt2 = x2.n(j.s, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.N(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = x2.n(j.q, 0);
      if (paramInt2 != 0) {
        Toolbar toolbar = this.a;
        toolbar.M(toolbar.getContext(), paramInt2);
      } 
      paramInt2 = x2.n(j.o, 0);
      if (paramInt2 != 0)
        this.a.setPopupTheme(paramInt2); 
    } else {
      this.b = w();
    } 
    x2.w();
    y(paramInt1);
    this.k = this.a.getNavigationContentDescription();
    this.a.setNavigationOnClickListener(new a(this));
  }
  
  private void F(CharSequence paramCharSequence) {
    this.i = paramCharSequence;
    if ((this.b & 0x8) != 0) {
      this.a.setTitle(paramCharSequence);
      if (this.h)
        e1.z0(this.a.getRootView(), paramCharSequence); 
    } 
  }
  
  private void G() {
    if ((this.b & 0x4) != 0) {
      if (TextUtils.isEmpty(this.k)) {
        this.a.setNavigationContentDescription(this.p);
        return;
      } 
      this.a.setNavigationContentDescription(this.k);
    } 
  }
  
  private void H() {
    if ((this.b & 0x4) != 0) {
      Toolbar toolbar = this.a;
      Drawable drawable = this.g;
      if (drawable == null)
        drawable = this.q; 
      toolbar.setNavigationIcon(drawable);
      return;
    } 
    this.a.setNavigationIcon((Drawable)null);
  }
  
  private void I() {
    Drawable drawable;
    int i = this.b;
    if ((i & 0x2) != 0) {
      if ((i & 0x1) != 0) {
        drawable = this.f;
        if (drawable == null)
          drawable = this.e; 
      } else {
        drawable = this.e;
      } 
    } else {
      drawable = null;
    } 
    this.a.setLogo(drawable);
  }
  
  private int w() {
    if (this.a.getNavigationIcon() != null) {
      this.q = this.a.getNavigationIcon();
      return 15;
    } 
    return 11;
  }
  
  public void A(int paramInt) {
    String str;
    if (paramInt == 0) {
      str = null;
    } else {
      str = getContext().getString(paramInt);
    } 
    B(str);
  }
  
  public void B(CharSequence paramCharSequence) {
    this.k = paramCharSequence;
    G();
  }
  
  public void C(Drawable paramDrawable) {
    this.g = paramDrawable;
    H();
  }
  
  public void D(CharSequence paramCharSequence) {
    this.j = paramCharSequence;
    if ((this.b & 0x8) != 0)
      this.a.setSubtitle(paramCharSequence); 
  }
  
  public void E(CharSequence paramCharSequence) {
    this.h = true;
    F(paramCharSequence);
  }
  
  public void a(Menu paramMenu, m.a parama) {
    if (this.n == null) {
      c c1 = new c(this.a.getContext());
      this.n = c1;
      c1.p(f.g);
    } 
    this.n.h(parama);
    this.a.K((g)paramMenu, this.n);
  }
  
  public boolean b() {
    return this.a.B();
  }
  
  public void c() {
    this.m = true;
  }
  
  public void collapseActionView() {
    this.a.e();
  }
  
  public boolean d() {
    return this.a.d();
  }
  
  public boolean e() {
    return this.a.A();
  }
  
  public boolean f() {
    return this.a.w();
  }
  
  public boolean g() {
    return this.a.Q();
  }
  
  public Context getContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public void h() {
    this.a.f();
  }
  
  public void i(p2 paramp2) {
    View view = this.c;
    if (view != null) {
      ViewParent viewParent = view.getParent();
      Toolbar toolbar = this.a;
      if (viewParent == toolbar)
        toolbar.removeView(this.c); 
    } 
    this.c = (View)paramp2;
    if (paramp2 != null && this.o == 2) {
      this.a.addView((View)paramp2, 0);
      Toolbar.g g = (Toolbar.g)this.c.getLayoutParams();
      ((ViewGroup.MarginLayoutParams)g).width = -2;
      ((ViewGroup.MarginLayoutParams)g).height = -2;
      g.a = 8388691;
      paramp2.setAllowCollapse(true);
    } 
  }
  
  public boolean j() {
    return this.a.v();
  }
  
  public void k(int paramInt) {
    int i = this.b ^ paramInt;
    this.b = paramInt;
    if (i != 0) {
      if ((i & 0x4) != 0) {
        if ((paramInt & 0x4) != 0)
          G(); 
        H();
      } 
      if ((i & 0x3) != 0)
        I(); 
      if ((i & 0x8) != 0)
        if ((paramInt & 0x8) != 0) {
          this.a.setTitle(this.i);
          this.a.setSubtitle(this.j);
        } else {
          this.a.setTitle((CharSequence)null);
          this.a.setSubtitle((CharSequence)null);
        }  
      if ((i & 0x10) != 0) {
        View view = this.d;
        if (view != null) {
          if ((paramInt & 0x10) != 0) {
            this.a.addView(view);
            return;
          } 
          this.a.removeView(view);
        } 
      } 
    } 
  }
  
  public Menu l() {
    return this.a.getMenu();
  }
  
  public void m(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    z(drawable);
  }
  
  public int n() {
    return this.o;
  }
  
  public e3 o(int paramInt, long paramLong) {
    float f;
    e3 e3 = e1.e((View)this.a);
    if (paramInt == 0) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    return e3.b(f).f(paramLong).h((f3)new b(this, paramInt));
  }
  
  public void p(m.a parama, g.a parama1) {
    this.a.L(parama, parama1);
  }
  
  public ViewGroup q() {
    return this.a;
  }
  
  public void r(boolean paramBoolean) {}
  
  public int s() {
    return this.b;
  }
  
  public void setIcon(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = g.a.b(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setIcon(drawable);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.e = paramDrawable;
    I();
  }
  
  public void setVisibility(int paramInt) {
    this.a.setVisibility(paramInt);
  }
  
  public void setWindowCallback(Window.Callback paramCallback) {
    this.l = paramCallback;
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    if (!this.h)
      F(paramCharSequence); 
  }
  
  public void t() {}
  
  public void u() {}
  
  public void v(boolean paramBoolean) {
    this.a.setCollapsible(paramBoolean);
  }
  
  public void x(View paramView) {
    View view = this.d;
    if (view != null && (this.b & 0x10) != 0)
      this.a.removeView(view); 
    this.d = paramView;
    if (paramView != null && (this.b & 0x10) != 0)
      this.a.addView(paramView); 
  }
  
  public void y(int paramInt) {
    if (paramInt == this.p)
      return; 
    this.p = paramInt;
    if (TextUtils.isEmpty(this.a.getNavigationContentDescription()))
      A(this.p); 
  }
  
  public void z(Drawable paramDrawable) {
    this.f = paramDrawable;
    I();
  }
  
  class a implements View.OnClickListener {
    final androidx.appcompat.view.menu.a g;
    
    a(a3 this$0) {
      this.g = new androidx.appcompat.view.menu.a(this$0.a.getContext(), 0, 16908332, 0, 0, this$0.i);
    }
    
    public void onClick(View param1View) {
      a3 a31 = this.h;
      Window.Callback callback = a31.l;
      if (callback != null && a31.m)
        callback.onMenuItemSelected(0, (MenuItem)this.g); 
    }
  }
  
  class b extends g3 {
    private boolean a = false;
    
    b(a3 this$0, int param1Int) {}
    
    public void a(View param1View) {
      this.a = true;
    }
    
    public void b(View param1View) {
      if (!this.a)
        this.c.a.setVisibility(this.b); 
    }
    
    public void c(View param1View) {
      this.c.a.setVisibility(0);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\a3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */