package androidx.appcompat.widget;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Resources;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class u2 extends ContextWrapper {
  private static final Object c = new Object();
  
  private static ArrayList<WeakReference<u2>> d;
  
  private final Resources a;
  
  private final Resources.Theme b;
  
  private u2(Context paramContext) {
    super(paramContext);
    if (h3.d()) {
      h3 h3 = new h3((Context)this, paramContext.getResources());
      this.a = h3;
      Resources.Theme theme = h3.newTheme();
      this.b = theme;
      theme.setTo(paramContext.getTheme());
      return;
    } 
    this.a = new w2((Context)this, paramContext.getResources());
    this.b = null;
  }
  
  private static boolean a(Context paramContext) {
    boolean bool = paramContext instanceof u2;
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (!bool) {
      bool1 = bool2;
      if (!(paramContext.getResources() instanceof w2)) {
        if (paramContext.getResources() instanceof h3)
          return false; 
        bool1 = bool2;
        if (h3.d())
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  public static Context b(Context paramContext) {
    if (a(paramContext))
      synchronized (c) {
        ArrayList<WeakReference<u2>> arrayList = d;
        if (arrayList == null) {
          d = new ArrayList<WeakReference<u2>>();
        } else {
          for (int i = arrayList.size() - 1;; i--) {
            if (i >= 0) {
              WeakReference weakReference = d.get(i);
              if (weakReference == null || weakReference.get() == null)
                d.remove(i); 
            } else {
              for (i = d.size() - 1;; i--) {
                if (i >= 0) {
                  WeakReference<u2> weakReference = d.get(i);
                  if (weakReference != null) {
                    u2 u22 = weakReference.get();
                  } else {
                    weakReference = null;
                  } 
                  if (weakReference != null && weakReference.getBaseContext() == paramContext)
                    return (Context)weakReference; 
                } else {
                  u21 = new u2(paramContext);
                  d.add(new WeakReference<u2>(u21));
                  return (Context)u21;
                } 
              } 
            } 
          } 
          i--;
        } 
        u2 u21 = new u2((Context)u21);
        d.add(new WeakReference<u2>(u21));
        return (Context)u21;
      }  
    return paramContext;
  }
  
  public AssetManager getAssets() {
    return this.a.getAssets();
  }
  
  public Resources getResources() {
    return this.a;
  }
  
  public Resources.Theme getTheme() {
    Resources.Theme theme2 = this.b;
    Resources.Theme theme1 = theme2;
    if (theme2 == null)
      theme1 = super.getTheme(); 
    return theme1;
  }
  
  public void setTheme(int paramInt) {
    Resources.Theme theme = this.b;
    if (theme == null) {
      super.setTheme(paramInt);
      return;
    } 
    theme.applyStyle(paramInt, true);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widge\\u2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */