package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.core.view.e1;
import androidx.core.widget.h;
import f.j;
import g.a;

public class m {
  private final ImageView a;
  
  private v2 b;
  
  private v2 c;
  
  private v2 d;
  
  private int e = 0;
  
  public m(ImageView paramImageView) {
    this.a = paramImageView;
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.d == null)
      this.d = new v2(); 
    v2 v21 = this.d;
    v21.a();
    ColorStateList colorStateList = h.a(this.a);
    if (colorStateList != null) {
      v21.d = true;
      v21.a = colorStateList;
    } 
    PorterDuff.Mode mode = h.b(this.a);
    if (mode != null) {
      v21.c = true;
      v21.b = mode;
    } 
    if (v21.d || v21.c) {
      i.i(paramDrawable, v21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean l() {
    int i = Build.VERSION.SDK_INT;
    return (i > 21) ? ((this.b != null)) : ((i == 21));
  }
  
  void b() {
    if (this.a.getDrawable() != null)
      this.a.getDrawable().setLevel(this.e); 
  }
  
  void c() {
    Drawable drawable = this.a.getDrawable();
    if (drawable != null)
      x1.b(drawable); 
    if (drawable != null) {
      if (l() && a(drawable))
        return; 
      v2 v21 = this.c;
      if (v21 != null) {
        i.i(drawable, v21, this.a.getDrawableState());
        return;
      } 
      v21 = this.b;
      if (v21 != null)
        i.i(drawable, v21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList d() {
    v2 v21 = this.c;
    return (v21 != null) ? v21.a : null;
  }
  
  PorterDuff.Mode e() {
    v2 v21 = this.c;
    return (v21 != null) ? v21.b : null;
  }
  
  boolean f() {
    return !(this.a.getBackground() instanceof android.graphics.drawable.RippleDrawable);
  }
  
  public void g(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.P;
    x2 x2 = x2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    ImageView imageView = this.a;
    e1.u0((View)imageView, imageView.getContext(), arrayOfInt, paramAttributeSet, x2.r(), paramInt, 0);
    try {
      Drawable drawable2 = this.a.getDrawable();
      Drawable drawable1 = drawable2;
      if (drawable2 == null) {
        paramInt = x2.n(j.Q, -1);
        drawable1 = drawable2;
        if (paramInt != -1) {
          drawable2 = a.b(this.a.getContext(), paramInt);
          drawable1 = drawable2;
          if (drawable2 != null) {
            this.a.setImageDrawable(drawable2);
            drawable1 = drawable2;
          } 
        } 
      } 
      if (drawable1 != null)
        x1.b(drawable1); 
      paramInt = j.R;
      if (x2.s(paramInt))
        h.c(this.a, x2.c(paramInt)); 
      paramInt = j.S;
      if (x2.s(paramInt))
        h.d(this.a, x1.e(x2.k(paramInt, -1), null)); 
      return;
    } finally {
      x2.w();
    } 
  }
  
  void h(Drawable paramDrawable) {
    this.e = paramDrawable.getLevel();
  }
  
  public void i(int paramInt) {
    if (paramInt != 0) {
      Drawable drawable = a.b(this.a.getContext(), paramInt);
      if (drawable != null)
        x1.b(drawable); 
      this.a.setImageDrawable(drawable);
    } else {
      this.a.setImageDrawable(null);
    } 
    c();
  }
  
  void j(ColorStateList paramColorStateList) {
    if (this.c == null)
      this.c = new v2(); 
    v2 v21 = this.c;
    v21.a = paramColorStateList;
    v21.d = true;
    c();
  }
  
  void k(PorterDuff.Mode paramMode) {
    if (this.c == null)
      this.c = new v2(); 
    v2 v21 = this.c;
    v21.b = paramMode;
    v21.c = true;
    c();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */