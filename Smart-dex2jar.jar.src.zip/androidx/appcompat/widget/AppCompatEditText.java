package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.Editable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.DragEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.EditText;
import android.widget.TextView;
import androidx.core.view.c;
import androidx.core.view.e1;
import androidx.core.view.w0;
import androidx.core.widget.c0;
import androidx.core.widget.e0;
import androidx.core.widget.q;
import w.d;
import w.f;

public class AppCompatEditText extends EditText implements w0, e0 {
  private final d g;
  
  private final v0 h;
  
  private final u0 i;
  
  private final c0 j;
  
  private final j k;
  
  private a l;
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.B);
  }
  
  public AppCompatEditText(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    d d1 = new d((View)this);
    this.g = d1;
    d1.e(paramAttributeSet, paramInt);
    v0 v01 = new v0((TextView)this);
    this.h = v01;
    v01.m(paramAttributeSet, paramInt);
    v01.b();
    this.i = new u0((TextView)this);
    this.j = new c0();
    j j1 = new j(this);
    this.k = j1;
    j1.c(paramAttributeSet, paramInt);
    d(j1);
  }
  
  private a getSuperCaller() {
    if (this.l == null)
      this.l = new a(this); 
    return this.l;
  }
  
  public c a(c paramc) {
    return this.j.a((View)this, paramc);
  }
  
  void d(j paramj) {
    KeyListener keyListener = getKeyListener();
    if (paramj.b(keyListener)) {
      boolean bool1 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool3 = isLongClickable();
      int i = getInputType();
      KeyListener keyListener1 = paramj.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool1);
      setClickable(bool2);
      setLongClickable(bool3);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.g;
    if (d1 != null)
      d1.b(); 
    v0 v01 = this.h;
    if (v01 != null)
      v01.b(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return q.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.g;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.g;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.h.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.h.k();
  }
  
  public Editable getText() {
    return (Build.VERSION.SDK_INT >= 28) ? super.getText() : getEditableText();
  }
  
  public TextClassifier getTextClassifier() {
    if (Build.VERSION.SDK_INT < 28) {
      u0 u01 = this.i;
      if (u01 != null)
        return u01.a(); 
    } 
    return getSuperCaller().a();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection1 = super.onCreateInputConnection(paramEditorInfo);
    this.h.r((TextView)this, inputConnection1, paramEditorInfo);
    InputConnection inputConnection2 = l.a(inputConnection1, paramEditorInfo, (View)this);
    inputConnection1 = inputConnection2;
    if (inputConnection2 != null) {
      inputConnection1 = inputConnection2;
      if (Build.VERSION.SDK_INT <= 30) {
        String[] arrayOfString = e1.J((View)this);
        inputConnection1 = inputConnection2;
        if (arrayOfString != null) {
          d.d(paramEditorInfo, arrayOfString);
          inputConnection1 = f.c((View)this, inputConnection2, paramEditorInfo);
        } 
      } 
    } 
    return this.k.d(inputConnection1, paramEditorInfo);
  }
  
  public boolean onDragEvent(DragEvent paramDragEvent) {
    return l0.a((View)this, paramDragEvent) ? true : super.onDragEvent(paramDragEvent);
  }
  
  public boolean onTextContextMenuItem(int paramInt) {
    return l0.b((TextView)this, paramInt) ? true : super.onTextContextMenuItem(paramInt);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.g;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.g;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(q.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.k.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.k.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.g;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.g;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.h.w(paramColorStateList);
    this.h.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.h.x(paramMode);
    this.h.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    v0 v01 = this.h;
    if (v01 != null)
      v01.q(paramContext, paramInt); 
  }
  
  public void setTextClassifier(TextClassifier paramTextClassifier) {
    if (Build.VERSION.SDK_INT < 28) {
      u0 u01 = this.i;
      if (u01 != null) {
        u01.b(paramTextClassifier);
        return;
      } 
    } 
    getSuperCaller().b(paramTextClassifier);
  }
  
  class a {
    a(AppCompatEditText this$0) {}
    
    public TextClassifier a() {
      return AppCompatEditText.b(this.a);
    }
    
    public void b(TextClassifier param1TextClassifier) {
      AppCompatEditText.c(this.a, param1TextClassifier);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\AppCompatEditText.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */