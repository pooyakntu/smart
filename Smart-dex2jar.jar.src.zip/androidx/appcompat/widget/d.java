package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.core.view.e1;
import f.j;

class d {
  private final View a;
  
  private final i b;
  
  private int c = -1;
  
  private v2 d;
  
  private v2 e;
  
  private v2 f;
  
  d(View paramView) {
    this.a = paramView;
    this.b = i.b();
  }
  
  private boolean a(Drawable paramDrawable) {
    if (this.f == null)
      this.f = new v2(); 
    v2 v21 = this.f;
    v21.a();
    ColorStateList colorStateList = e1.w(this.a);
    if (colorStateList != null) {
      v21.d = true;
      v21.a = colorStateList;
    } 
    PorterDuff.Mode mode = e1.x(this.a);
    if (mode != null) {
      v21.c = true;
      v21.b = mode;
    } 
    if (v21.d || v21.c) {
      i.i(paramDrawable, v21, this.a.getDrawableState());
      return true;
    } 
    return false;
  }
  
  private boolean k() {
    int j = Build.VERSION.SDK_INT;
    return (j > 21) ? ((this.d != null)) : ((j == 21));
  }
  
  void b() {
    Drawable drawable = this.a.getBackground();
    if (drawable != null) {
      if (k() && a(drawable))
        return; 
      v2 v21 = this.e;
      if (v21 != null) {
        i.i(drawable, v21, this.a.getDrawableState());
        return;
      } 
      v21 = this.d;
      if (v21 != null)
        i.i(drawable, v21, this.a.getDrawableState()); 
    } 
  }
  
  ColorStateList c() {
    v2 v21 = this.e;
    return (v21 != null) ? v21.a : null;
  }
  
  PorterDuff.Mode d() {
    v2 v21 = this.e;
    return (v21 != null) ? v21.b : null;
  }
  
  void e(AttributeSet paramAttributeSet, int paramInt) {
    Context context = this.a.getContext();
    int[] arrayOfInt = j.M3;
    x2 x2 = x2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    View view = this.a;
    e1.u0(view, view.getContext(), arrayOfInt, paramAttributeSet, x2.r(), paramInt, 0);
    try {
      paramInt = j.N3;
      if (x2.s(paramInt)) {
        this.c = x2.n(paramInt, -1);
        ColorStateList colorStateList = this.b.f(this.a.getContext(), this.c);
        if (colorStateList != null)
          h(colorStateList); 
      } 
      paramInt = j.O3;
      if (x2.s(paramInt))
        e1.C0(this.a, x2.c(paramInt)); 
      paramInt = j.P3;
      if (x2.s(paramInt))
        e1.D0(this.a, x1.e(x2.k(paramInt, -1), null)); 
      return;
    } finally {
      x2.w();
    } 
  }
  
  void f(Drawable paramDrawable) {
    this.c = -1;
    h(null);
    b();
  }
  
  void g(int paramInt) {
    this.c = paramInt;
    i i1 = this.b;
    if (i1 != null) {
      ColorStateList colorStateList = i1.f(this.a.getContext(), paramInt);
    } else {
      i1 = null;
    } 
    h((ColorStateList)i1);
    b();
  }
  
  void h(ColorStateList paramColorStateList) {
    if (paramColorStateList != null) {
      if (this.d == null)
        this.d = new v2(); 
      v2 v21 = this.d;
      v21.a = paramColorStateList;
      v21.d = true;
    } else {
      this.d = null;
    } 
    b();
  }
  
  void i(ColorStateList paramColorStateList) {
    if (this.e == null)
      this.e = new v2(); 
    v2 v21 = this.e;
    v21.a = paramColorStateList;
    v21.d = true;
    b();
  }
  
  void j(PorterDuff.Mode paramMode) {
    if (this.e == null)
      this.e = new v2(); 
    v2 v21 = this.e;
    v21.b = paramMode;
    v21.c = true;
    b();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */