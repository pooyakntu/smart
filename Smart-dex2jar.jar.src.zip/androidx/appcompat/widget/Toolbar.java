package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.activity.j;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.view.menu.r;
import androidx.core.view.e1;
import androidx.core.view.s;
import androidx.core.view.v;
import androidx.core.view.y;
import f.j;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Toolbar extends ViewGroup {
  private int A;
  
  private int B;
  
  private int C = 8388627;
  
  private CharSequence D;
  
  private CharSequence E;
  
  private ColorStateList F;
  
  private ColorStateList G;
  
  private boolean H;
  
  private boolean I;
  
  private final ArrayList<View> J = new ArrayList<View>();
  
  private final ArrayList<View> K = new ArrayList<View>();
  
  private final int[] L = new int[2];
  
  final y M = new y(new y2(this));
  
  private ArrayList<MenuItem> N = new ArrayList<MenuItem>();
  
  h O;
  
  private final ActionMenuView.e P = new a(this);
  
  private a3 Q;
  
  private c R;
  
  private f S;
  
  private m.a T;
  
  androidx.appcompat.view.menu.g.a U;
  
  private boolean V;
  
  private OnBackInvokedCallback W;
  
  private OnBackInvokedDispatcher a0;
  
  private boolean b0;
  
  private final Runnable c0 = new b(this);
  
  ActionMenuView g;
  
  private TextView h;
  
  private TextView i;
  
  private ImageButton j;
  
  private ImageView k;
  
  private Drawable l;
  
  private CharSequence m;
  
  ImageButton n;
  
  View o;
  
  private Context p;
  
  private int q;
  
  private int r;
  
  private int s;
  
  int t;
  
  private int u;
  
  private int v;
  
  private int w;
  
  private int x;
  
  private int y;
  
  private o2 z;
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.O);
  }
  
  public Toolbar(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    Context context = getContext();
    int[] arrayOfInt = j.f3;
    x2 x2 = x2.v(context, paramAttributeSet, arrayOfInt, paramInt, 0);
    e1.u0((View)this, paramContext, arrayOfInt, paramAttributeSet, x2.r(), paramInt, 0);
    this.r = x2.n(j.H3, 0);
    this.s = x2.n(j.y3, 0);
    this.C = x2.l(j.g3, this.C);
    this.t = x2.l(j.h3, 48);
    int i = x2.e(j.B3, 0);
    int j = j.G3;
    paramInt = i;
    if (x2.s(j))
      paramInt = x2.e(j, i); 
    this.y = paramInt;
    this.x = paramInt;
    this.w = paramInt;
    this.v = paramInt;
    paramInt = x2.e(j.E3, -1);
    if (paramInt >= 0)
      this.v = paramInt; 
    paramInt = x2.e(j.D3, -1);
    if (paramInt >= 0)
      this.w = paramInt; 
    paramInt = x2.e(j.F3, -1);
    if (paramInt >= 0)
      this.x = paramInt; 
    paramInt = x2.e(j.C3, -1);
    if (paramInt >= 0)
      this.y = paramInt; 
    this.u = x2.f(j.s3, -1);
    paramInt = x2.e(j.o3, -2147483648);
    i = x2.e(j.k3, -2147483648);
    j = x2.f(j.m3, 0);
    int k = x2.f(j.n3, 0);
    h();
    this.z.e(j, k);
    if (paramInt != Integer.MIN_VALUE || i != Integer.MIN_VALUE)
      this.z.g(paramInt, i); 
    this.A = x2.e(j.p3, -2147483648);
    this.B = x2.e(j.l3, -2147483648);
    this.l = x2.g(j.j3);
    this.m = x2.p(j.i3);
    CharSequence charSequence3 = x2.p(j.A3);
    if (!TextUtils.isEmpty(charSequence3))
      setTitle(charSequence3); 
    charSequence3 = x2.p(j.x3);
    if (!TextUtils.isEmpty(charSequence3))
      setSubtitle(charSequence3); 
    this.p = getContext();
    setPopupTheme(x2.n(j.w3, 0));
    Drawable drawable2 = x2.g(j.v3);
    if (drawable2 != null)
      setNavigationIcon(drawable2); 
    CharSequence charSequence2 = x2.p(j.u3);
    if (!TextUtils.isEmpty(charSequence2))
      setNavigationContentDescription(charSequence2); 
    Drawable drawable1 = x2.g(j.q3);
    if (drawable1 != null)
      setLogo(drawable1); 
    CharSequence charSequence1 = x2.p(j.r3);
    if (!TextUtils.isEmpty(charSequence1))
      setLogoDescription(charSequence1); 
    paramInt = j.I3;
    if (x2.s(paramInt))
      setTitleTextColor(x2.c(paramInt)); 
    paramInt = j.z3;
    if (x2.s(paramInt))
      setSubtitleTextColor(x2.c(paramInt)); 
    paramInt = j.t3;
    if (x2.s(paramInt))
      x(x2.n(paramInt, 0)); 
    x2.w();
  }
  
  private int C(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).leftMargin - paramArrayOfint[0];
    paramInt1 += Math.max(0, i);
    paramArrayOfint[0] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1, paramInt2, paramInt1 + i, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 + i + ((ViewGroup.MarginLayoutParams)g).rightMargin;
  }
  
  private int D(View paramView, int paramInt1, int[] paramArrayOfint, int paramInt2) {
    g g = (g)paramView.getLayoutParams();
    int i = ((ViewGroup.MarginLayoutParams)g).rightMargin - paramArrayOfint[1];
    paramInt1 -= Math.max(0, i);
    paramArrayOfint[1] = Math.max(0, -i);
    paramInt2 = q(paramView, paramInt2);
    i = paramView.getMeasuredWidth();
    paramView.layout(paramInt1 - i, paramInt2, paramInt1, paramView.getMeasuredHeight() + paramInt2);
    return paramInt1 - i + ((ViewGroup.MarginLayoutParams)g).leftMargin;
  }
  
  private int E(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = marginLayoutParams.leftMargin - paramArrayOfint[0];
    int j = marginLayoutParams.rightMargin - paramArrayOfint[1];
    int k = Math.max(0, i) + Math.max(0, j);
    paramArrayOfint[0] = Math.max(0, -i);
    paramArrayOfint[1] = Math.max(0, -j);
    paramView.measure(ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + k + paramInt2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height));
    return paramView.getMeasuredWidth() + k;
  }
  
  private void F(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    int i = ViewGroup.getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + paramInt2, marginLayoutParams.width);
    paramInt2 = ViewGroup.getChildMeasureSpec(paramInt3, getPaddingTop() + getPaddingBottom() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + paramInt4, marginLayoutParams.height);
    paramInt3 = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = paramInt2;
    if (paramInt3 != 1073741824) {
      paramInt1 = paramInt2;
      if (paramInt5 >= 0) {
        paramInt1 = paramInt5;
        if (paramInt3 != 0)
          paramInt1 = Math.min(View.MeasureSpec.getSize(paramInt2), paramInt5); 
        paramInt1 = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
      } 
    } 
    paramView.measure(i, paramInt1);
  }
  
  private void G() {
    Menu menu = getMenu();
    ArrayList<MenuItem> arrayList1 = getCurrentMenuItems();
    this.M.h(menu, getMenuInflater());
    ArrayList<MenuItem> arrayList2 = getCurrentMenuItems();
    arrayList2.removeAll(arrayList1);
    this.N = arrayList2;
  }
  
  private void H() {
    removeCallbacks(this.c0);
    post(this.c0);
  }
  
  private boolean O() {
    if (!this.V)
      return false; 
    int j = getChildCount();
    for (int i = 0; i < j; i++) {
      View view = getChildAt(i);
      if (P(view) && view.getMeasuredWidth() > 0 && view.getMeasuredHeight() > 0)
        return false; 
    } 
    return true;
  }
  
  private boolean P(View paramView) {
    return (paramView != null && paramView.getParent() == this && paramView.getVisibility() != 8);
  }
  
  private void b(List<View> paramList, int paramInt) {
    int i = e1.G((View)this);
    boolean bool = false;
    if (i == 1) {
      i = 1;
    } else {
      i = 0;
    } 
    int k = getChildCount();
    int j = s.b(paramInt, e1.G((View)this));
    paramList.clear();
    paramInt = bool;
    if (i != 0) {
      for (paramInt = k - 1; paramInt >= 0; paramInt--) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && P(view) && p(g.a) == j)
          paramList.add(view); 
      } 
    } else {
      while (paramInt < k) {
        View view = getChildAt(paramInt);
        g g = (g)view.getLayoutParams();
        if (g.b == 0 && P(view) && p(g.a) == j)
          paramList.add(view); 
        paramInt++;
      } 
    } 
  }
  
  private void c(View paramView, boolean paramBoolean) {
    g g;
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    if (layoutParams == null) {
      g = m();
    } else if (!checkLayoutParams((ViewGroup.LayoutParams)g)) {
      g = o((ViewGroup.LayoutParams)g);
    } else {
      g = g;
    } 
    g.b = 1;
    if (paramBoolean && this.o != null) {
      paramView.setLayoutParams((ViewGroup.LayoutParams)g);
      this.K.add(paramView);
      return;
    } 
    addView(paramView, (ViewGroup.LayoutParams)g);
  }
  
  private ArrayList<MenuItem> getCurrentMenuItems() {
    ArrayList<MenuItem> arrayList = new ArrayList();
    Menu menu = getMenu();
    for (int i = 0; i < menu.size(); i++)
      arrayList.add(menu.getItem(i)); 
    return arrayList;
  }
  
  private MenuInflater getMenuInflater() {
    return (MenuInflater)new androidx.appcompat.view.g(getContext());
  }
  
  private void h() {
    if (this.z == null)
      this.z = new o2(); 
  }
  
  private void i() {
    if (this.k == null)
      this.k = new AppCompatImageView(getContext()); 
  }
  
  private void j() {
    k();
    if (this.g.L() == null) {
      androidx.appcompat.view.menu.g g = (androidx.appcompat.view.menu.g)this.g.getMenu();
      if (this.S == null)
        this.S = new f(this); 
      this.g.setExpandedActionViewsExclusive(true);
      g.c(this.S, this.p);
      R();
    } 
  }
  
  private void k() {
    if (this.g == null) {
      ActionMenuView actionMenuView = new ActionMenuView(getContext());
      this.g = actionMenuView;
      actionMenuView.setPopupTheme(this.q);
      this.g.setOnMenuItemClickListener(this.P);
      this.g.M(this.T, new c(this));
      g g = m();
      g.a = this.t & 0x70 | 0x800005;
      this.g.setLayoutParams((ViewGroup.LayoutParams)g);
      c((View)this.g, false);
    } 
  }
  
  private void l() {
    if (this.j == null) {
      this.j = new AppCompatImageButton(getContext(), null, f.a.N);
      g g = m();
      g.a = this.t & 0x70 | 0x800003;
      this.j.setLayoutParams((ViewGroup.LayoutParams)g);
    } 
  }
  
  private int p(int paramInt) {
    int i = e1.G((View)this);
    int j = s.b(paramInt, i) & 0x7;
    if (j != 1) {
      paramInt = 3;
      if (j != 3 && j != 5) {
        if (i == 1)
          paramInt = 5; 
        return paramInt;
      } 
    } 
    return j;
  }
  
  private int q(View paramView, int paramInt) {
    g g = (g)paramView.getLayoutParams();
    int j = paramView.getMeasuredHeight();
    if (paramInt > 0) {
      paramInt = (j - paramInt) / 2;
    } else {
      paramInt = 0;
    } 
    int i = r(g.a);
    if (i != 48) {
      if (i != 80) {
        int k = getPaddingTop();
        int m = getPaddingBottom();
        int n = getHeight();
        i = (n - k - m - j) / 2;
        paramInt = ((ViewGroup.MarginLayoutParams)g).topMargin;
        if (i >= paramInt) {
          j = n - m - j - i - k;
          m = ((ViewGroup.MarginLayoutParams)g).bottomMargin;
          paramInt = i;
          if (j < m)
            paramInt = Math.max(0, i - m - j); 
        } 
        return k + paramInt;
      } 
      return getHeight() - getPaddingBottom() - j - ((ViewGroup.MarginLayoutParams)g).bottomMargin - paramInt;
    } 
    return getPaddingTop() - paramInt;
  }
  
  private int r(int paramInt) {
    int i = paramInt & 0x70;
    paramInt = i;
    if (i != 16) {
      paramInt = i;
      if (i != 48) {
        paramInt = i;
        if (i != 80)
          paramInt = this.C & 0x70; 
      } 
    } 
    return paramInt;
  }
  
  private int s(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return v.b(marginLayoutParams) + v.a(marginLayoutParams);
  }
  
  private int t(View paramView) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
  }
  
  private int u(List<View> paramList, int[] paramArrayOfint) {
    int m = paramArrayOfint[0];
    int k = paramArrayOfint[1];
    int n = paramList.size();
    int i = 0;
    int j = 0;
    while (i < n) {
      View view = paramList.get(i);
      g g = (g)view.getLayoutParams();
      m = ((ViewGroup.MarginLayoutParams)g).leftMargin - m;
      k = ((ViewGroup.MarginLayoutParams)g).rightMargin - k;
      int i1 = Math.max(0, m);
      int i2 = Math.max(0, k);
      m = Math.max(0, -m);
      k = Math.max(0, -k);
      j += i1 + view.getMeasuredWidth() + i2;
      i++;
    } 
    return j;
  }
  
  private boolean z(View paramView) {
    return (paramView.getParent() == this || this.K.contains(paramView));
  }
  
  public boolean A() {
    ActionMenuView actionMenuView = this.g;
    return (actionMenuView != null && actionMenuView.G());
  }
  
  public boolean B() {
    ActionMenuView actionMenuView = this.g;
    return (actionMenuView != null && actionMenuView.H());
  }
  
  void I() {
    for (int i = getChildCount() - 1; i >= 0; i--) {
      View view = getChildAt(i);
      if (((g)view.getLayoutParams()).b != 2 && view != this.g) {
        removeViewAt(i);
        this.K.add(view);
      } 
    } 
  }
  
  public void J(int paramInt1, int paramInt2) {
    h();
    this.z.g(paramInt1, paramInt2);
  }
  
  public void K(androidx.appcompat.view.menu.g paramg, c paramc) {
    if (paramg == null && this.g == null)
      return; 
    k();
    androidx.appcompat.view.menu.g g1 = this.g.L();
    if (g1 == paramg)
      return; 
    if (g1 != null) {
      g1.O((m)this.R);
      g1.O(this.S);
    } 
    if (this.S == null)
      this.S = new f(this); 
    paramc.G(true);
    if (paramg != null) {
      paramg.c((m)paramc, this.p);
      paramg.c(this.S, this.p);
    } else {
      paramc.i(this.p, null);
      this.S.i(this.p, null);
      paramc.d(true);
      this.S.d(true);
    } 
    this.g.setPopupTheme(this.q);
    this.g.setPresenter(paramc);
    this.R = paramc;
    R();
  }
  
  public void L(m.a parama, androidx.appcompat.view.menu.g.a parama1) {
    this.T = parama;
    this.U = parama1;
    ActionMenuView actionMenuView = this.g;
    if (actionMenuView != null)
      actionMenuView.M(parama, parama1); 
  }
  
  public void M(Context paramContext, int paramInt) {
    this.s = paramInt;
    TextView textView = this.i;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public void N(Context paramContext, int paramInt) {
    this.r = paramInt;
    TextView textView = this.h;
    if (textView != null)
      textView.setTextAppearance(paramContext, paramInt); 
  }
  
  public boolean Q() {
    ActionMenuView actionMenuView = this.g;
    return (actionMenuView != null && actionMenuView.N());
  }
  
  void R() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool;
      OnBackInvokedDispatcher onBackInvokedDispatcher = e.a((View)this);
      if (v() && onBackInvokedDispatcher != null && e1.Z((View)this) && this.b0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool && this.a0 == null) {
        if (this.W == null)
          this.W = e.b(new z2(this)); 
        e.c(onBackInvokedDispatcher, this.W);
        this.a0 = onBackInvokedDispatcher;
        return;
      } 
      if (!bool) {
        onBackInvokedDispatcher = this.a0;
        if (onBackInvokedDispatcher != null) {
          e.d(onBackInvokedDispatcher, this.W);
          this.a0 = null;
        } 
      } 
    } 
  }
  
  void a() {
    for (int i = this.K.size() - 1; i >= 0; i--)
      addView(this.K.get(i)); 
    this.K.clear();
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (super.checkLayoutParams(paramLayoutParams) && paramLayoutParams instanceof g);
  }
  
  public boolean d() {
    if (getVisibility() == 0) {
      ActionMenuView actionMenuView = this.g;
      if (actionMenuView != null && actionMenuView.I())
        return true; 
    } 
    return false;
  }
  
  public void e() {
    androidx.appcompat.view.menu.i i;
    f f1 = this.S;
    if (f1 == null) {
      f1 = null;
    } else {
      i = f1.h;
    } 
    if (i != null)
      i.collapseActionView(); 
  }
  
  public void f() {
    ActionMenuView actionMenuView = this.g;
    if (actionMenuView != null)
      actionMenuView.z(); 
  }
  
  void g() {
    if (this.n == null) {
      AppCompatImageButton appCompatImageButton = new AppCompatImageButton(getContext(), null, f.a.N);
      this.n = appCompatImageButton;
      appCompatImageButton.setImageDrawable(this.l);
      this.n.setContentDescription(this.m);
      g g = m();
      g.a = this.t & 0x70 | 0x800003;
      g.b = 2;
      this.n.setLayoutParams((ViewGroup.LayoutParams)g);
      this.n.setOnClickListener(new d(this));
    } 
  }
  
  public CharSequence getCollapseContentDescription() {
    ImageButton imageButton = this.n;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getCollapseIcon() {
    ImageButton imageButton = this.n;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  public int getContentInsetEnd() {
    o2 o21 = this.z;
    return (o21 != null) ? o21.a() : 0;
  }
  
  public int getContentInsetEndWithActions() {
    int i = this.B;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetEnd();
  }
  
  public int getContentInsetLeft() {
    o2 o21 = this.z;
    return (o21 != null) ? o21.b() : 0;
  }
  
  public int getContentInsetRight() {
    o2 o21 = this.z;
    return (o21 != null) ? o21.c() : 0;
  }
  
  public int getContentInsetStart() {
    o2 o21 = this.z;
    return (o21 != null) ? o21.d() : 0;
  }
  
  public int getContentInsetStartWithNavigation() {
    int i = this.A;
    return (i != Integer.MIN_VALUE) ? i : getContentInsetStart();
  }
  
  public int getCurrentContentInsetEnd() {
    // Byte code:
    //   0: aload_0
    //   1: getfield g : Landroidx/appcompat/widget/ActionMenuView;
    //   4: astore_2
    //   5: aload_2
    //   6: ifnull -> 30
    //   9: aload_2
    //   10: invokevirtual L : ()Landroidx/appcompat/view/menu/g;
    //   13: astore_2
    //   14: aload_2
    //   15: ifnull -> 30
    //   18: aload_2
    //   19: invokevirtual hasVisibleItems : ()Z
    //   22: ifeq -> 30
    //   25: iconst_1
    //   26: istore_1
    //   27: goto -> 32
    //   30: iconst_0
    //   31: istore_1
    //   32: iload_1
    //   33: ifeq -> 52
    //   36: aload_0
    //   37: invokevirtual getContentInsetEnd : ()I
    //   40: aload_0
    //   41: getfield B : I
    //   44: iconst_0
    //   45: invokestatic max : (II)I
    //   48: invokestatic max : (II)I
    //   51: ireturn
    //   52: aload_0
    //   53: invokevirtual getContentInsetEnd : ()I
    //   56: ireturn
  }
  
  public int getCurrentContentInsetLeft() {
    return (e1.G((View)this) == 1) ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
  }
  
  public int getCurrentContentInsetRight() {
    return (e1.G((View)this) == 1) ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
  }
  
  public int getCurrentContentInsetStart() {
    return (getNavigationIcon() != null) ? Math.max(getContentInsetStart(), Math.max(this.A, 0)) : getContentInsetStart();
  }
  
  public Drawable getLogo() {
    ImageView imageView = this.k;
    return (imageView != null) ? imageView.getDrawable() : null;
  }
  
  public CharSequence getLogoDescription() {
    ImageView imageView = this.k;
    return (imageView != null) ? imageView.getContentDescription() : null;
  }
  
  public Menu getMenu() {
    j();
    return this.g.getMenu();
  }
  
  View getNavButtonView() {
    return (View)this.j;
  }
  
  public CharSequence getNavigationContentDescription() {
    ImageButton imageButton = this.j;
    return (imageButton != null) ? imageButton.getContentDescription() : null;
  }
  
  public Drawable getNavigationIcon() {
    ImageButton imageButton = this.j;
    return (imageButton != null) ? imageButton.getDrawable() : null;
  }
  
  c getOuterActionMenuPresenter() {
    return this.R;
  }
  
  public Drawable getOverflowIcon() {
    j();
    return this.g.getOverflowIcon();
  }
  
  Context getPopupContext() {
    return this.p;
  }
  
  public int getPopupTheme() {
    return this.q;
  }
  
  public CharSequence getSubtitle() {
    return this.E;
  }
  
  final TextView getSubtitleTextView() {
    return this.i;
  }
  
  public CharSequence getTitle() {
    return this.D;
  }
  
  public int getTitleMarginBottom() {
    return this.y;
  }
  
  public int getTitleMarginEnd() {
    return this.w;
  }
  
  public int getTitleMarginStart() {
    return this.v;
  }
  
  public int getTitleMarginTop() {
    return this.x;
  }
  
  final TextView getTitleTextView() {
    return this.h;
  }
  
  public s1 getWrapper() {
    if (this.Q == null)
      this.Q = new a3(this, true); 
    return this.Q;
  }
  
  protected g m() {
    return new g(-2, -2);
  }
  
  public g n(AttributeSet paramAttributeSet) {
    return new g(getContext(), paramAttributeSet);
  }
  
  protected g o(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof g) ? new g((g)paramLayoutParams) : ((paramLayoutParams instanceof androidx.appcompat.app.a.a) ? new g((androidx.appcompat.app.a.a)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new g((ViewGroup.MarginLayoutParams)paramLayoutParams) : new g(paramLayoutParams)));
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    R();
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    removeCallbacks(this.c0);
    R();
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 9)
      this.I = false; 
    if (!this.I) {
      boolean bool = super.onHoverEvent(paramMotionEvent);
      if (i == 9 && !bool)
        this.I = true; 
    } 
    if (i == 10 || i == 3)
      this.I = false; 
    return true;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (e1.G((View)this) == 1) {
      k = 1;
    } else {
      k = 0;
    } 
    int n = getWidth();
    int i3 = getHeight();
    int i = getPaddingLeft();
    int i1 = getPaddingRight();
    int i2 = getPaddingTop();
    int i4 = getPaddingBottom();
    int m = n - i1;
    int[] arrayOfInt = this.L;
    arrayOfInt[1] = 0;
    arrayOfInt[0] = 0;
    paramInt1 = e1.H((View)this);
    if (paramInt1 >= 0) {
      paramInt4 = Math.min(paramInt1, paramInt4 - paramInt2);
    } else {
      paramInt4 = 0;
    } 
    if (P((View)this.j)) {
      if (k) {
        j = D((View)this.j, m, arrayOfInt, paramInt4);
        paramInt3 = i;
      } else {
        paramInt3 = C((View)this.j, i, arrayOfInt, paramInt4);
        j = m;
      } 
    } else {
      paramInt3 = i;
      j = m;
    } 
    paramInt1 = paramInt3;
    paramInt2 = j;
    if (P((View)this.n))
      if (k) {
        paramInt2 = D((View)this.n, j, arrayOfInt, paramInt4);
        paramInt1 = paramInt3;
      } else {
        paramInt1 = C((View)this.n, paramInt3, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    int j = paramInt1;
    paramInt3 = paramInt2;
    if (P((View)this.g))
      if (k) {
        j = C((View)this.g, paramInt1, arrayOfInt, paramInt4);
        paramInt3 = paramInt2;
      } else {
        paramInt3 = D((View)this.g, paramInt2, arrayOfInt, paramInt4);
        j = paramInt1;
      }  
    paramInt2 = getCurrentContentInsetLeft();
    paramInt1 = getCurrentContentInsetRight();
    arrayOfInt[0] = Math.max(0, paramInt2 - j);
    arrayOfInt[1] = Math.max(0, paramInt1 - m - paramInt3);
    paramInt2 = Math.max(j, paramInt2);
    paramInt3 = Math.min(paramInt3, m - paramInt1);
    paramInt1 = paramInt2;
    j = paramInt3;
    if (P(this.o))
      if (k) {
        j = D(this.o, paramInt3, arrayOfInt, paramInt4);
        paramInt1 = paramInt2;
      } else {
        paramInt1 = C(this.o, paramInt2, arrayOfInt, paramInt4);
        j = paramInt3;
      }  
    paramInt3 = paramInt1;
    paramInt2 = j;
    if (P((View)this.k))
      if (k) {
        paramInt2 = D((View)this.k, j, arrayOfInt, paramInt4);
        paramInt3 = paramInt1;
      } else {
        paramInt3 = C((View)this.k, paramInt1, arrayOfInt, paramInt4);
        paramInt2 = j;
      }  
    paramBoolean = P((View)this.h);
    boolean bool = P((View)this.i);
    if (paramBoolean) {
      g g = (g)this.h.getLayoutParams();
      paramInt1 = ((ViewGroup.MarginLayoutParams)g).topMargin + this.h.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin + 0;
    } else {
      paramInt1 = 0;
    } 
    if (bool) {
      g g = (g)this.i.getLayoutParams();
      paramInt1 += ((ViewGroup.MarginLayoutParams)g).topMargin + this.i.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams)g).bottomMargin;
    } 
    if (paramBoolean || bool) {
      TextView textView1;
      TextView textView2;
      if (paramBoolean) {
        textView1 = this.h;
      } else {
        textView1 = this.i;
      } 
      if (bool) {
        textView2 = this.i;
      } else {
        textView2 = this.h;
      } 
      g g1 = (g)textView1.getLayoutParams();
      g g2 = (g)textView2.getLayoutParams();
      if ((paramBoolean && this.h.getMeasuredWidth() > 0) || (bool && this.i.getMeasuredWidth() > 0)) {
        j = 1;
      } else {
        j = 0;
      } 
      m = this.C & 0x70;
      if (m != 48) {
        if (m != 80) {
          m = (i3 - i2 - i4 - paramInt1) / 2;
          int i5 = ((ViewGroup.MarginLayoutParams)g1).topMargin;
          int i6 = this.x;
          if (m < i5 + i6) {
            paramInt1 = i5 + i6;
          } else {
            i3 = i3 - i4 - paramInt1 - m - i2;
            i4 = ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
            i5 = this.y;
            paramInt1 = m;
            if (i3 < i4 + i5)
              paramInt1 = Math.max(0, m - ((ViewGroup.MarginLayoutParams)g2).bottomMargin + i5 - i3); 
          } 
          paramInt1 = i2 + paramInt1;
        } else {
          paramInt1 = i3 - i4 - ((ViewGroup.MarginLayoutParams)g2).bottomMargin - this.y - paramInt1;
        } 
      } else {
        paramInt1 = getPaddingTop() + ((ViewGroup.MarginLayoutParams)g1).topMargin + this.x;
      } 
      if (k) {
        if (j != 0) {
          k = this.v;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[1];
        paramInt2 -= Math.max(0, k);
        arrayOfInt[1] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.h.getLayoutParams();
          m = paramInt2 - this.h.getMeasuredWidth();
          k = this.h.getMeasuredHeight() + paramInt1;
          this.h.layout(m, paramInt1, paramInt2, k);
          paramInt1 = m - this.w;
          m = k + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt2;
          m = paramInt1;
          paramInt1 = k;
        } 
        if (bool) {
          k = m + ((ViewGroup.MarginLayoutParams)this.i.getLayoutParams()).topMargin;
          m = this.i.getMeasuredWidth();
          i2 = this.i.getMeasuredHeight();
          this.i.layout(paramInt2 - m, k, paramInt2, i2 + k);
          k = paramInt2 - this.w;
        } else {
          k = paramInt2;
        } 
        if (j != 0)
          paramInt2 = Math.min(paramInt1, k); 
        paramInt1 = paramInt3;
      } else {
        if (j != 0) {
          k = this.v;
        } else {
          k = 0;
        } 
        k -= arrayOfInt[0];
        paramInt3 += Math.max(0, k);
        arrayOfInt[0] = Math.max(0, -k);
        if (paramBoolean) {
          g1 = (g)this.h.getLayoutParams();
          k = this.h.getMeasuredWidth() + paramInt3;
          m = this.h.getMeasuredHeight() + paramInt1;
          this.h.layout(paramInt3, paramInt1, k, m);
          k += this.w;
          paramInt1 = m + ((ViewGroup.MarginLayoutParams)g1).bottomMargin;
        } else {
          k = paramInt3;
        } 
        if (bool) {
          paramInt1 += ((ViewGroup.MarginLayoutParams)this.i.getLayoutParams()).topMargin;
          m = this.i.getMeasuredWidth() + paramInt3;
          i2 = this.i.getMeasuredHeight();
          this.i.layout(paramInt3, paramInt1, m, i2 + paramInt1);
          m += this.w;
        } else {
          m = paramInt3;
        } 
        paramInt1 = paramInt3;
        paramInt3 = paramInt2;
        if (j != 0) {
          paramInt1 = Math.max(k, m);
          paramInt3 = paramInt2;
        } 
        j = i;
        i = 0;
        b(this.J, 3);
        k = this.J.size();
        paramInt2 = 0;
      } 
    } else {
      paramInt1 = paramInt3;
    } 
    paramInt3 = paramInt2;
    j = i;
    i = 0;
    b(this.J, 3);
    int k = this.J.size();
    paramInt2 = 0;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.copyTypes(TypeTransformer.java:311)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.fixTypes(TypeTransformer.java:226)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:207)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof i)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    i i1 = (i)paramParcelable;
    super.onRestoreInstanceState(i1.a());
    ActionMenuView actionMenuView = this.g;
    if (actionMenuView != null) {
      androidx.appcompat.view.menu.g g = actionMenuView.L();
    } else {
      actionMenuView = null;
    } 
    int i = i1.i;
    if (i != 0 && this.S != null && actionMenuView != null) {
      MenuItem menuItem = actionMenuView.findItem(i);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
    if (i1.j)
      H(); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    super.onRtlPropertiesChanged(paramInt);
    h();
    o2 o21 = this.z;
    boolean bool = true;
    if (paramInt != 1)
      bool = false; 
    o21.f(bool);
  }
  
  protected Parcelable onSaveInstanceState() {
    i i = new i(super.onSaveInstanceState());
    f f1 = this.S;
    if (f1 != null) {
      androidx.appcompat.view.menu.i i1 = f1.h;
      if (i1 != null)
        i.i = i1.getItemId(); 
    } 
    i.j = B();
    return (Parcelable)i;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.H = false; 
    if (!this.H) {
      boolean bool = super.onTouchEvent(paramMotionEvent);
      if (i == 0 && !bool)
        this.H = true; 
    } 
    if (i == 1 || i == 3)
      this.H = false; 
    return true;
  }
  
  public void setBackInvokedCallbackEnabled(boolean paramBoolean) {
    if (this.b0 != paramBoolean) {
      this.b0 = paramBoolean;
      R();
    } 
  }
  
  public void setCollapseContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setCollapseContentDescription(charSequence);
  }
  
  public void setCollapseContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      g(); 
    ImageButton imageButton = this.n;
    if (imageButton != null)
      imageButton.setContentDescription(paramCharSequence); 
  }
  
  public void setCollapseIcon(int paramInt) {
    setCollapseIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setCollapseIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      g();
      this.n.setImageDrawable(paramDrawable);
      return;
    } 
    ImageButton imageButton = this.n;
    if (imageButton != null)
      imageButton.setImageDrawable(this.l); 
  }
  
  public void setCollapsible(boolean paramBoolean) {
    this.V = paramBoolean;
    requestLayout();
  }
  
  public void setContentInsetEndWithActions(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.B) {
      this.B = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setContentInsetStartWithNavigation(int paramInt) {
    int i = paramInt;
    if (paramInt < 0)
      i = Integer.MIN_VALUE; 
    if (i != this.A) {
      this.A = i;
      if (getNavigationIcon() != null)
        requestLayout(); 
    } 
  }
  
  public void setLogo(int paramInt) {
    setLogo(g.a.b(getContext(), paramInt));
  }
  
  public void setLogo(Drawable paramDrawable) {
    if (paramDrawable != null) {
      i();
      if (!z((View)this.k))
        c((View)this.k, true); 
    } else {
      ImageView imageView1 = this.k;
      if (imageView1 != null && z((View)imageView1)) {
        removeView((View)this.k);
        this.K.remove(this.k);
      } 
    } 
    ImageView imageView = this.k;
    if (imageView != null)
      imageView.setImageDrawable(paramDrawable); 
  }
  
  public void setLogoDescription(int paramInt) {
    setLogoDescription(getContext().getText(paramInt));
  }
  
  public void setLogoDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      i(); 
    ImageView imageView = this.k;
    if (imageView != null)
      imageView.setContentDescription(paramCharSequence); 
  }
  
  public void setNavigationContentDescription(int paramInt) {
    CharSequence charSequence;
    if (paramInt != 0) {
      charSequence = getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    setNavigationContentDescription(charSequence);
  }
  
  public void setNavigationContentDescription(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence))
      l(); 
    ImageButton imageButton = this.j;
    if (imageButton != null) {
      imageButton.setContentDescription(paramCharSequence);
      c3.a((View)this.j, paramCharSequence);
    } 
  }
  
  public void setNavigationIcon(int paramInt) {
    setNavigationIcon(g.a.b(getContext(), paramInt));
  }
  
  public void setNavigationIcon(Drawable paramDrawable) {
    if (paramDrawable != null) {
      l();
      if (!z((View)this.j))
        c((View)this.j, true); 
    } else {
      ImageButton imageButton1 = this.j;
      if (imageButton1 != null && z((View)imageButton1)) {
        removeView((View)this.j);
        this.K.remove(this.j);
      } 
    } 
    ImageButton imageButton = this.j;
    if (imageButton != null)
      imageButton.setImageDrawable(paramDrawable); 
  }
  
  public void setNavigationOnClickListener(View.OnClickListener paramOnClickListener) {
    l();
    this.j.setOnClickListener(paramOnClickListener);
  }
  
  public void setOnMenuItemClickListener(h paramh) {
    this.O = paramh;
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    j();
    this.g.setOverflowIcon(paramDrawable);
  }
  
  public void setPopupTheme(int paramInt) {
    if (this.q != paramInt) {
      this.q = paramInt;
      if (paramInt == 0) {
        this.p = getContext();
        return;
      } 
      this.p = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(getContext().getText(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.i == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.i = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.i.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.s;
        if (i != 0)
          this.i.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.G;
        if (colorStateList != null)
          this.i.setTextColor(colorStateList); 
      } 
      if (!z((View)this.i))
        c((View)this.i, true); 
    } else {
      TextView textView1 = this.i;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.i);
        this.K.remove(this.i);
      } 
    } 
    TextView textView = this.i;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.E = paramCharSequence;
  }
  
  public void setSubtitleTextColor(int paramInt) {
    setSubtitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setSubtitleTextColor(ColorStateList paramColorStateList) {
    this.G = paramColorStateList;
    TextView textView = this.i;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public void setTitle(int paramInt) {
    setTitle(getContext().getText(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (!TextUtils.isEmpty(paramCharSequence)) {
      if (this.h == null) {
        Context context = getContext();
        AppCompatTextView appCompatTextView = new AppCompatTextView(context);
        this.h = appCompatTextView;
        appCompatTextView.setSingleLine();
        this.h.setEllipsize(TextUtils.TruncateAt.END);
        int i = this.r;
        if (i != 0)
          this.h.setTextAppearance(context, i); 
        ColorStateList colorStateList = this.F;
        if (colorStateList != null)
          this.h.setTextColor(colorStateList); 
      } 
      if (!z((View)this.h))
        c((View)this.h, true); 
    } else {
      TextView textView1 = this.h;
      if (textView1 != null && z((View)textView1)) {
        removeView((View)this.h);
        this.K.remove(this.h);
      } 
    } 
    TextView textView = this.h;
    if (textView != null)
      textView.setText(paramCharSequence); 
    this.D = paramCharSequence;
  }
  
  public void setTitleMarginBottom(int paramInt) {
    this.y = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginEnd(int paramInt) {
    this.w = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginStart(int paramInt) {
    this.v = paramInt;
    requestLayout();
  }
  
  public void setTitleMarginTop(int paramInt) {
    this.x = paramInt;
    requestLayout();
  }
  
  public void setTitleTextColor(int paramInt) {
    setTitleTextColor(ColorStateList.valueOf(paramInt));
  }
  
  public void setTitleTextColor(ColorStateList paramColorStateList) {
    this.F = paramColorStateList;
    TextView textView = this.h;
    if (textView != null)
      textView.setTextColor(paramColorStateList); 
  }
  
  public boolean v() {
    f f1 = this.S;
    return (f1 != null && f1.h != null);
  }
  
  public boolean w() {
    ActionMenuView actionMenuView = this.g;
    return (actionMenuView != null && actionMenuView.F());
  }
  
  public void x(int paramInt) {
    getMenuInflater().inflate(paramInt, getMenu());
  }
  
  public void y() {
    for (MenuItem menuItem : this.N)
      getMenu().removeItem(menuItem.getItemId()); 
    G();
  }
  
  class a implements ActionMenuView.e {
    a(Toolbar this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      if (this.a.M.j(param1MenuItem))
        return true; 
      Toolbar.h h = this.a.O;
      return (h != null) ? h.onMenuItemClick(param1MenuItem) : false;
    }
  }
  
  class b implements Runnable {
    b(Toolbar this$0) {}
    
    public void run() {
      this.g.Q();
    }
  }
  
  class c implements androidx.appcompat.view.menu.g.a {
    c(Toolbar this$0) {}
    
    public boolean a(androidx.appcompat.view.menu.g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.menu.g.a a1 = this.g.U;
      return (a1 != null && a1.a(param1g, param1MenuItem));
    }
    
    public void b(androidx.appcompat.view.menu.g param1g) {
      if (!this.g.g.H())
        this.g.M.k((Menu)param1g); 
      androidx.appcompat.view.menu.g.a a1 = this.g.U;
      if (a1 != null)
        a1.b(param1g); 
    }
  }
  
  class d implements View.OnClickListener {
    d(Toolbar this$0) {}
    
    public void onClick(View param1View) {
      this.g.e();
    }
  }
  
  static class e {
    static OnBackInvokedDispatcher a(View param1View) {
      return param1View.findOnBackInvokedDispatcher();
    }
    
    static OnBackInvokedCallback b(Runnable param1Runnable) {
      Objects.requireNonNull(param1Runnable);
      return (OnBackInvokedCallback)new j(param1Runnable);
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).registerOnBackInvokedCallback(1000000, (OnBackInvokedCallback)param1Object2);
    }
    
    static void d(Object param1Object1, Object param1Object2) {
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  private class f implements m {
    androidx.appcompat.view.menu.g g;
    
    androidx.appcompat.view.menu.i h;
    
    f(Toolbar this$0) {}
    
    public void c(androidx.appcompat.view.menu.g param1g, boolean param1Boolean) {}
    
    public void d(boolean param1Boolean) {
      if (this.h != null) {
        androidx.appcompat.view.menu.g g1 = this.g;
        boolean bool2 = false;
        boolean bool1 = bool2;
        if (g1 != null) {
          int k = g1.size();
          int j = 0;
          while (true) {
            bool1 = bool2;
            if (j < k) {
              if (this.g.getItem(j) == this.h) {
                bool1 = true;
                break;
              } 
              j++;
              continue;
            } 
            break;
          } 
        } 
        if (!bool1)
          f(this.g, this.h); 
      } 
    }
    
    public boolean e() {
      return false;
    }
    
    public boolean f(androidx.appcompat.view.menu.g param1g, androidx.appcompat.view.menu.i param1i) {
      View view = this.i.o;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewCollapsed(); 
      Toolbar toolbar = this.i;
      toolbar.removeView(toolbar.o);
      toolbar = this.i;
      toolbar.removeView((View)toolbar.n);
      toolbar = this.i;
      toolbar.o = null;
      toolbar.a();
      this.h = null;
      this.i.requestLayout();
      param1i.r(false);
      this.i.R();
      return true;
    }
    
    public boolean g(androidx.appcompat.view.menu.g param1g, androidx.appcompat.view.menu.i param1i) {
      this.i.g();
      ViewParent viewParent = this.i.n.getParent();
      Toolbar toolbar = this.i;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView((View)toolbar.n); 
        Toolbar toolbar1 = this.i;
        toolbar1.addView((View)toolbar1.n);
      } 
      this.i.o = param1i.getActionView();
      this.h = param1i;
      viewParent = this.i.o.getParent();
      toolbar = this.i;
      if (viewParent != toolbar) {
        if (viewParent instanceof ViewGroup)
          ((ViewGroup)viewParent).removeView(toolbar.o); 
        Toolbar.g g1 = this.i.m();
        toolbar = this.i;
        g1.a = toolbar.t & 0x70 | 0x800003;
        g1.b = 2;
        toolbar.o.setLayoutParams((ViewGroup.LayoutParams)g1);
        Toolbar toolbar1 = this.i;
        toolbar1.addView(toolbar1.o);
      } 
      this.i.I();
      this.i.requestLayout();
      param1i.r(true);
      View view = this.i.o;
      if (view instanceof androidx.appcompat.view.c)
        ((androidx.appcompat.view.c)view).onActionViewExpanded(); 
      this.i.R();
      return true;
    }
    
    public void i(Context param1Context, androidx.appcompat.view.menu.g param1g) {
      androidx.appcompat.view.menu.g g1 = this.g;
      if (g1 != null) {
        androidx.appcompat.view.menu.i i1 = this.h;
        if (i1 != null)
          g1.f(i1); 
      } 
      this.g = param1g;
    }
    
    public boolean k(r param1r) {
      return false;
    }
  }
  
  public static class g extends androidx.appcompat.app.a.a {
    int b = 0;
    
    public g(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.a = 8388627;
    }
    
    public g(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public g(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public g(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super((ViewGroup.LayoutParams)param1MarginLayoutParams);
      a(param1MarginLayoutParams);
    }
    
    public g(androidx.appcompat.app.a.a param1a) {
      super(param1a);
    }
    
    public g(g param1g) {
      super(param1g);
      this.b = param1g.b;
    }
    
    void a(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      ((ViewGroup.MarginLayoutParams)this).leftMargin = param1MarginLayoutParams.leftMargin;
      ((ViewGroup.MarginLayoutParams)this).topMargin = param1MarginLayoutParams.topMargin;
      ((ViewGroup.MarginLayoutParams)this).rightMargin = param1MarginLayoutParams.rightMargin;
      ((ViewGroup.MarginLayoutParams)this).bottomMargin = param1MarginLayoutParams.bottomMargin;
    }
  }
  
  public static interface h {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
  
  public static class i extends y.a {
    public static final Parcelable.Creator<i> CREATOR = (Parcelable.Creator<i>)new a();
    
    int i;
    
    boolean j;
    
    public i(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      this.i = param1Parcel.readInt();
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.j = bool;
    }
    
    public i(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      throw new RuntimeException("d2j fail translate: java.lang.RuntimeException: can not merge I and Z\r\n\tat com.googlecode.dex2jar.ir.TypeClass.merge(TypeClass.java:100)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeRef.updateTypeClass(TypeTransformer.java:174)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.provideAs(TypeTransformer.java:780)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.e1expr(TypeTransformer.java:496)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:713)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.enexpr(TypeTransformer.java:698)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:719)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.exExpr(TypeTransformer.java:703)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.s1stmt(TypeTransformer.java:810)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.sxStmt(TypeTransformer.java:840)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer$TypeAnalyze.analyze(TypeTransformer.java:206)\r\n\tat com.googlecode.dex2jar.ir.ts.TypeTransformer.transform(TypeTransformer.java:44)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.optimize(Dex2jar.java:162)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertCode(Dex2Asm.java:414)\r\n\tat com.googlecode.d2j.dex.ExDex2Asm.convertCode(ExDex2Asm.java:42)\r\n\tat com.googlecode.d2j.dex.Dex2jar$2.convertCode(Dex2jar.java:128)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertMethod(Dex2Asm.java:509)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertClass(Dex2Asm.java:406)\r\n\tat com.googlecode.d2j.dex.Dex2Asm.convertDex(Dex2Asm.java:422)\r\n\tat com.googlecode.d2j.dex.Dex2jar.doTranslate(Dex2jar.java:172)\r\n\tat com.googlecode.d2j.dex.Dex2jar.to(Dex2jar.java:272)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.doCommandLine(Dex2jarCmd.java:108)\r\n\tat com.googlecode.dex2jar.tools.BaseCmd.doMain(BaseCmd.java:288)\r\n\tat com.googlecode.dex2jar.tools.Dex2jarCmd.main(Dex2jarCmd.java:32)\r\n");
    }
    
    class a implements Parcelable.ClassLoaderCreator<i> {
      public Toolbar.i a(Parcel param2Parcel) {
        return new Toolbar.i(param2Parcel, null);
      }
      
      public Toolbar.i b(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return new Toolbar.i(param2Parcel, param2ClassLoader);
      }
      
      public Toolbar.i[] c(int param2Int) {
        return new Toolbar.i[param2Int];
      }
    }
  }
  
  class a implements Parcelable.ClassLoaderCreator<i> {
    public Toolbar.i a(Parcel param1Parcel) {
      return new Toolbar.i(param1Parcel, null);
    }
    
    public Toolbar.i b(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new Toolbar.i(param1Parcel, param1ClassLoader);
    }
    
    public Toolbar.i[] c(int param1Int) {
      return new Toolbar.i[param1Int];
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\Toolbar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */