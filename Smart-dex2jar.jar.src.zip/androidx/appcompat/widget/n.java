package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.text.method.KeyListener;
import android.util.AttributeSet;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.EditText;
import android.widget.MultiAutoCompleteTextView;
import android.widget.TextView;
import androidx.core.widget.e0;
import f.a;
import g.a;

public class n extends MultiAutoCompleteTextView implements e0 {
  private static final int[] j = new int[] { 16843126 };
  
  private final d g;
  
  private final v0 h;
  
  private final j i;
  
  public n(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.p);
  }
  
  public n(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    x2 x2 = x2.v(getContext(), paramAttributeSet, j, paramInt, 0);
    if (x2.s(0))
      setDropDownBackgroundDrawable(x2.g(0)); 
    x2.w();
    d d1 = new d((View)this);
    this.g = d1;
    d1.e(paramAttributeSet, paramInt);
    v0 v01 = new v0((TextView)this);
    this.h = v01;
    v01.m(paramAttributeSet, paramInt);
    v01.b();
    j j1 = new j((EditText)this);
    this.i = j1;
    j1.c(paramAttributeSet, paramInt);
    a(j1);
  }
  
  void a(j paramj) {
    KeyListener keyListener = getKeyListener();
    if (paramj.b(keyListener)) {
      boolean bool1 = isFocusable();
      boolean bool2 = isClickable();
      boolean bool3 = isLongClickable();
      int i = getInputType();
      KeyListener keyListener1 = paramj.a(keyListener);
      if (keyListener1 == keyListener)
        return; 
      super.setKeyListener(keyListener1);
      setRawInputType(i);
      setFocusable(bool1);
      setClickable(bool2);
      setLongClickable(bool3);
    } 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    d d1 = this.g;
    if (d1 != null)
      d1.b(); 
    v0 v01 = this.h;
    if (v01 != null)
      v01.b(); 
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.g;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.g;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.h.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.h.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    InputConnection inputConnection = l.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
    return this.i.d(inputConnection, paramEditorInfo);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.g;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.g;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.h;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setDropDownBackgroundResource(int paramInt) {
    setDropDownBackgroundDrawable(a.b(getContext(), paramInt));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    this.i.e(paramBoolean);
  }
  
  public void setKeyListener(KeyListener paramKeyListener) {
    super.setKeyListener(this.i.a(paramKeyListener));
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.g;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.g;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.h.w(paramColorStateList);
    this.h.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.h.x(paramMode);
    this.h.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    v0 v01 = this.h;
    if (v01 != null)
      v01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */