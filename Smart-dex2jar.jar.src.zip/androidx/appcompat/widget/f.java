package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;
import androidx.core.widget.e0;
import androidx.core.widget.q;
import f.a;
import g.a;

public class f extends CheckedTextView implements e0 {
  private final g g;
  
  private final d h;
  
  private final v0 i;
  
  private k j;
  
  public f(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.s);
  }
  
  public f(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(u2.b(paramContext), paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    v0 v01 = new v0((TextView)this);
    this.i = v01;
    v01.m(paramAttributeSet, paramInt);
    v01.b();
    d d1 = new d((View)this);
    this.h = d1;
    d1.e(paramAttributeSet, paramInt);
    g g1 = new g(this);
    this.g = g1;
    g1.d(paramAttributeSet, paramInt);
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
  }
  
  private k getEmojiTextViewHelper() {
    if (this.j == null)
      this.j = new k((TextView)this); 
    return this.j;
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    v0 v01 = this.i;
    if (v01 != null)
      v01.b(); 
    d d1 = this.h;
    if (d1 != null)
      d1.b(); 
    g g1 = this.g;
    if (g1 != null)
      g1.a(); 
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return q.q(super.getCustomSelectionActionModeCallback());
  }
  
  public ColorStateList getSupportBackgroundTintList() {
    d d1 = this.h;
    return (d1 != null) ? d1.c() : null;
  }
  
  public PorterDuff.Mode getSupportBackgroundTintMode() {
    d d1 = this.h;
    return (d1 != null) ? d1.d() : null;
  }
  
  public ColorStateList getSupportCheckMarkTintList() {
    g g1 = this.g;
    return (g1 != null) ? g1.b() : null;
  }
  
  public PorterDuff.Mode getSupportCheckMarkTintMode() {
    g g1 = this.g;
    return (g1 != null) ? g1.c() : null;
  }
  
  public ColorStateList getSupportCompoundDrawablesTintList() {
    return this.i.j();
  }
  
  public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
    return this.i.k();
  }
  
  public InputConnection onCreateInputConnection(EditorInfo paramEditorInfo) {
    return l.a(super.onCreateInputConnection(paramEditorInfo), paramEditorInfo, (View)this);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    super.setBackgroundDrawable(paramDrawable);
    d d1 = this.h;
    if (d1 != null)
      d1.f(paramDrawable); 
  }
  
  public void setBackgroundResource(int paramInt) {
    super.setBackgroundResource(paramInt);
    d d1 = this.h;
    if (d1 != null)
      d1.g(paramInt); 
  }
  
  public void setCheckMarkDrawable(int paramInt) {
    setCheckMarkDrawable(a.b(getContext(), paramInt));
  }
  
  public void setCheckMarkDrawable(Drawable paramDrawable) {
    super.setCheckMarkDrawable(paramDrawable);
    g g1 = this.g;
    if (g1 != null)
      g1.e(); 
  }
  
  public void setCompoundDrawables(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawables(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.i;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCompoundDrawablesRelative(Drawable paramDrawable1, Drawable paramDrawable2, Drawable paramDrawable3, Drawable paramDrawable4) {
    super.setCompoundDrawablesRelative(paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
    v0 v01 = this.i;
    if (v01 != null)
      v01.p(); 
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(q.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
  }
  
  public void setSupportBackgroundTintList(ColorStateList paramColorStateList) {
    d d1 = this.h;
    if (d1 != null)
      d1.i(paramColorStateList); 
  }
  
  public void setSupportBackgroundTintMode(PorterDuff.Mode paramMode) {
    d d1 = this.h;
    if (d1 != null)
      d1.j(paramMode); 
  }
  
  public void setSupportCheckMarkTintList(ColorStateList paramColorStateList) {
    g g1 = this.g;
    if (g1 != null)
      g1.f(paramColorStateList); 
  }
  
  public void setSupportCheckMarkTintMode(PorterDuff.Mode paramMode) {
    g g1 = this.g;
    if (g1 != null)
      g1.g(paramMode); 
  }
  
  public void setSupportCompoundDrawablesTintList(ColorStateList paramColorStateList) {
    this.i.w(paramColorStateList);
    this.i.b();
  }
  
  public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode paramMode) {
    this.i.x(paramMode);
    this.i.b();
  }
  
  public void setTextAppearance(Context paramContext, int paramInt) {
    super.setTextAppearance(paramContext, paramInt);
    v0 v01 = this.i;
    if (v01 != null)
      v01.q(paramContext, paramInt); 
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */