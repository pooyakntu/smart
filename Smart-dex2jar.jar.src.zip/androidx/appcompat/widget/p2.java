package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class p2 extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {
  private static final Interpolator p = (Interpolator)new DecelerateInterpolator();
  
  Runnable g;
  
  private c h;
  
  c2 i;
  
  private Spinner j;
  
  private boolean k;
  
  int l;
  
  int m;
  
  private int n;
  
  private int o;
  
  private Spinner b() {
    o0 o0 = new o0(getContext(), null, f.a.h);
    o0.setLayoutParams((ViewGroup.LayoutParams)new c2.a(-2, -1));
    o0.setOnItemSelectedListener(this);
    return o0;
  }
  
  private boolean d() {
    Spinner spinner = this.j;
    return (spinner != null && spinner.getParent() == this);
  }
  
  private void e() {
    if (d())
      return; 
    if (this.j == null)
      this.j = b(); 
    removeView((View)this.i);
    addView((View)this.j, new ViewGroup.LayoutParams(-2, -1));
    if (this.j.getAdapter() == null)
      this.j.setAdapter((SpinnerAdapter)new b(this)); 
    Runnable runnable = this.g;
    if (runnable != null) {
      removeCallbacks(runnable);
      this.g = null;
    } 
    this.j.setSelection(this.o);
  }
  
  private boolean f() {
    if (!d())
      return false; 
    removeView((View)this.j);
    addView((View)this.i, new ViewGroup.LayoutParams(-2, -1));
    setTabSelected(this.j.getSelectedItemPosition());
    return false;
  }
  
  public void a(int paramInt) {
    View view = this.i.getChildAt(paramInt);
    Runnable runnable = this.g;
    if (runnable != null)
      removeCallbacks(runnable); 
    a a = new a(this, view);
    this.g = a;
    post(a);
  }
  
  d c(androidx.appcompat.app.a.c paramc, boolean paramBoolean) {
    d d = new d(this, getContext(), paramc, paramBoolean);
    if (paramBoolean) {
      d.setBackgroundDrawable(null);
      d.setLayoutParams((ViewGroup.LayoutParams)new AbsListView.LayoutParams(-1, this.n));
      return d;
    } 
    d.setFocusable(true);
    if (this.h == null)
      this.h = new c(this); 
    d.setOnClickListener(this.h);
    return d;
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    Runnable runnable = this.g;
    if (runnable != null)
      post(runnable); 
  }
  
  protected void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    androidx.appcompat.view.a a = androidx.appcompat.view.a.b(getContext());
    setContentHeight(a.f());
    this.m = a.e();
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    Runnable runnable = this.g;
    if (runnable != null)
      removeCallbacks(runnable); 
  }
  
  public void onItemSelected(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    ((d)paramView).b().e();
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    boolean bool;
    int i = View.MeasureSpec.getMode(paramInt1);
    paramInt2 = 1;
    if (i == 1073741824) {
      bool = true;
    } else {
      bool = false;
    } 
    setFillViewport(bool);
    int j = this.i.getChildCount();
    if (j > 1 && (i == 1073741824 || i == Integer.MIN_VALUE)) {
      if (j > 2) {
        this.l = (int)(View.MeasureSpec.getSize(paramInt1) * 0.4F);
      } else {
        this.l = View.MeasureSpec.getSize(paramInt1) / 2;
      } 
      this.l = Math.min(this.l, this.m);
    } else {
      this.l = -1;
    } 
    i = View.MeasureSpec.makeMeasureSpec(this.n, 1073741824);
    if (bool || !this.k)
      paramInt2 = 0; 
    if (paramInt2 != 0) {
      this.i.measure(0, i);
      if (this.i.getMeasuredWidth() > View.MeasureSpec.getSize(paramInt1)) {
        e();
      } else {
        f();
      } 
    } else {
      f();
    } 
    paramInt2 = getMeasuredWidth();
    super.onMeasure(paramInt1, i);
    paramInt1 = getMeasuredWidth();
    if (bool && paramInt2 != paramInt1)
      setTabSelected(this.o); 
  }
  
  public void onNothingSelected(AdapterView<?> paramAdapterView) {}
  
  public void setAllowCollapse(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public void setContentHeight(int paramInt) {
    this.n = paramInt;
    requestLayout();
  }
  
  public void setTabSelected(int paramInt) {
    this.o = paramInt;
    int j = this.i.getChildCount();
    for (int i = 0; i < j; i++) {
      boolean bool;
      View view = this.i.getChildAt(i);
      if (i == paramInt) {
        bool = true;
      } else {
        bool = false;
      } 
      view.setSelected(bool);
      if (bool)
        a(paramInt); 
    } 
    Spinner spinner = this.j;
    if (spinner != null && paramInt >= 0)
      spinner.setSelection(paramInt); 
  }
  
  class a implements Runnable {
    a(p2 this$0, View param1View) {}
    
    public void run() {
      int i = this.g.getLeft();
      int j = (this.h.getWidth() - this.g.getWidth()) / 2;
      this.h.smoothScrollTo(i - j, 0);
      this.h.g = null;
    }
  }
  
  private class b extends BaseAdapter {
    b(p2 this$0) {}
    
    public int getCount() {
      return this.g.i.getChildCount();
    }
    
    public Object getItem(int param1Int) {
      return ((p2.d)this.g.i.getChildAt(param1Int)).b();
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        return (View)this.g.c((androidx.appcompat.app.a.c)getItem(param1Int), true); 
      ((p2.d)param1View).a((androidx.appcompat.app.a.c)getItem(param1Int));
      return param1View;
    }
  }
  
  private class c implements View.OnClickListener {
    c(p2 this$0) {}
    
    public void onClick(View param1View) {
      ((p2.d)param1View).b().e();
      int j = this.g.i.getChildCount();
      for (int i = 0; i < j; i++) {
        boolean bool;
        View view = this.g.i.getChildAt(i);
        if (view == param1View) {
          bool = true;
        } else {
          bool = false;
        } 
        view.setSelected(bool);
      } 
    }
  }
  
  private class d extends LinearLayout {
    private final int[] g;
    
    private androidx.appcompat.app.a.c h;
    
    private TextView i;
    
    private ImageView j;
    
    private View k;
    
    public d(p2 this$0, Context param1Context, androidx.appcompat.app.a.c param1c, boolean param1Boolean) {
      super(param1Context, null, i);
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = 16842964;
      this.g = arrayOfInt;
      this.h = param1c;
      x2 x2 = x2.v(param1Context, null, arrayOfInt, i, 0);
      if (x2.s(0))
        setBackgroundDrawable(x2.g(0)); 
      x2.w();
      if (param1Boolean)
        setGravity(8388627); 
      c();
    }
    
    public void a(androidx.appcompat.app.a.c param1c) {
      this.h = param1c;
      c();
    }
    
    public androidx.appcompat.app.a.c b() {
      return this.h;
    }
    
    public void c() {
      androidx.appcompat.app.a.c c1 = this.h;
      View view = c1.b();
      ViewParent viewParent = null;
      if (view != null) {
        viewParent = view.getParent();
        if (viewParent != this) {
          if (viewParent != null)
            ((ViewGroup)viewParent).removeView(view); 
          addView(view);
        } 
        this.k = view;
        TextView textView = this.i;
        if (textView != null)
          textView.setVisibility(8); 
        ImageView imageView = this.j;
        if (imageView != null) {
          imageView.setVisibility(8);
          this.j.setImageDrawable(null);
          return;
        } 
      } else {
        CharSequence charSequence1;
        view = this.k;
        if (view != null) {
          removeView(view);
          this.k = null;
        } 
        Drawable drawable = c1.c();
        CharSequence charSequence2 = c1.d();
        if (drawable != null) {
          if (this.j == null) {
            AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatImageView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatImageView, 0);
            this.j = appCompatImageView;
          } 
          this.j.setImageDrawable(drawable);
          this.j.setVisibility(0);
        } else {
          ImageView imageView1 = this.j;
          if (imageView1 != null) {
            imageView1.setVisibility(8);
            this.j.setImageDrawable(null);
          } 
        } 
        int i = TextUtils.isEmpty(charSequence2) ^ true;
        if (i != 0) {
          if (this.i == null) {
            AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, f.a.e);
            appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
            layoutParams.gravity = 16;
            appCompatTextView.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
            addView((View)appCompatTextView);
            this.i = appCompatTextView;
          } 
          this.i.setText(charSequence2);
          this.i.setVisibility(0);
        } else {
          TextView textView = this.i;
          if (textView != null) {
            textView.setVisibility(8);
            this.i.setText(null);
          } 
        } 
        ImageView imageView = this.j;
        if (imageView != null)
          imageView.setContentDescription(c1.a()); 
        if (i == 0)
          charSequence1 = c1.a(); 
        c3.a((View)this, charSequence1);
      } 
    }
    
    public void onInitializeAccessibilityEvent(AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo param1AccessibilityNodeInfo) {
      super.onInitializeAccessibilityNodeInfo(param1AccessibilityNodeInfo);
      param1AccessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
    }
    
    public void onMeasure(int param1Int1, int param1Int2) {
      super.onMeasure(param1Int1, param1Int2);
      if (this.l.l > 0) {
        param1Int1 = getMeasuredWidth();
        int i = this.l.l;
        if (param1Int1 > i)
          super.onMeasure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), param1Int2); 
      } 
    }
    
    public void setSelected(boolean param1Boolean) {
      boolean bool;
      if (isSelected() != param1Boolean) {
        bool = true;
      } else {
        bool = false;
      } 
      super.setSelected(param1Boolean);
      if (bool && param1Boolean)
        sendAccessibilityEvent(4); 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\p2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */