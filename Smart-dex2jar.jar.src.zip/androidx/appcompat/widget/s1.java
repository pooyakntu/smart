package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.core.view.e3;

public interface s1 {
  void a(Menu paramMenu, m.a parama);
  
  boolean b();
  
  void c();
  
  void collapseActionView();
  
  boolean d();
  
  boolean e();
  
  boolean f();
  
  boolean g();
  
  Context getContext();
  
  CharSequence getTitle();
  
  void h();
  
  void i(p2 paramp2);
  
  boolean j();
  
  void k(int paramInt);
  
  Menu l();
  
  void m(int paramInt);
  
  int n();
  
  e3 o(int paramInt, long paramLong);
  
  void p(m.a parama, g.a parama1);
  
  ViewGroup q();
  
  void r(boolean paramBoolean);
  
  int s();
  
  void setIcon(int paramInt);
  
  void setIcon(Drawable paramDrawable);
  
  void setVisibility(int paramInt);
  
  void setWindowCallback(Window.Callback paramCallback);
  
  void setWindowTitle(CharSequence paramCharSequence);
  
  void t();
  
  void u();
  
  void v(boolean paramBoolean);
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\s1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */