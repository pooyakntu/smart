package androidx.appcompat.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import android.widget.TextView;
import androidx.core.view.e1;
import androidx.core.widget.q;
import androidx.emoji2.text.e;
import f.h;
import f.j;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

public class SwitchCompat extends CompoundButton {
  private static final Property<SwitchCompat, Float> b0 = new a(Float.class, "thumbPos");
  
  private static final int[] c0 = new int[] { 16842912 };
  
  private int A;
  
  private float B;
  
  private float C;
  
  private VelocityTracker D = VelocityTracker.obtain();
  
  private int E;
  
  float F;
  
  private int G;
  
  private int H;
  
  private int I;
  
  private int J;
  
  private int K;
  
  private int L;
  
  private int M;
  
  private boolean N = true;
  
  private final TextPaint O;
  
  private ColorStateList P;
  
  private Layout Q;
  
  private Layout R;
  
  private TransformationMethod S;
  
  ObjectAnimator T;
  
  private final v0 U;
  
  private k V;
  
  private c W;
  
  private final Rect a0 = new Rect();
  
  private Drawable g;
  
  private ColorStateList h = null;
  
  private PorterDuff.Mode i = null;
  
  private boolean j = false;
  
  private boolean k = false;
  
  private Drawable l;
  
  private ColorStateList m = null;
  
  private PorterDuff.Mode n = null;
  
  private boolean o = false;
  
  private boolean p = false;
  
  private int q;
  
  private int r;
  
  private int s;
  
  private boolean t;
  
  private CharSequence u;
  
  private CharSequence v;
  
  private CharSequence w;
  
  private CharSequence x;
  
  private boolean y;
  
  private int z;
  
  public SwitchCompat(Context paramContext) {
    this(paramContext, null);
  }
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, f.a.L);
  }
  
  public SwitchCompat(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    s2.a((View)this, getContext());
    TextPaint textPaint = new TextPaint(1);
    this.O = textPaint;
    textPaint.density = (getResources().getDisplayMetrics()).density;
    int[] arrayOfInt = j.D2;
    x2 x2 = x2.v(paramContext, paramAttributeSet, arrayOfInt, paramInt, 0);
    e1.u0((View)this, paramContext, arrayOfInt, paramAttributeSet, x2.r(), paramInt, 0);
    Drawable drawable = x2.g(j.G2);
    this.g = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    drawable = x2.g(j.P2);
    this.l = drawable;
    if (drawable != null)
      drawable.setCallback((Drawable.Callback)this); 
    setTextOnInternal(x2.p(j.E2));
    setTextOffInternal(x2.p(j.F2));
    this.y = x2.a(j.H2, true);
    this.q = x2.f(j.M2, 0);
    this.r = x2.f(j.J2, 0);
    this.s = x2.f(j.K2, 0);
    this.t = x2.a(j.I2, false);
    ColorStateList colorStateList2 = x2.c(j.N2);
    if (colorStateList2 != null) {
      this.h = colorStateList2;
      this.j = true;
    } 
    PorterDuff.Mode mode2 = x1.e(x2.k(j.O2, -1), null);
    if (this.i != mode2) {
      this.i = mode2;
      this.k = true;
    } 
    if (this.j || this.k)
      b(); 
    ColorStateList colorStateList1 = x2.c(j.Q2);
    if (colorStateList1 != null) {
      this.m = colorStateList1;
      this.o = true;
    } 
    PorterDuff.Mode mode1 = x1.e(x2.k(j.R2, -1), null);
    if (this.n != mode1) {
      this.n = mode1;
      this.p = true;
    } 
    if (this.o || this.p)
      c(); 
    int i = x2.n(j.L2, 0);
    if (i != 0)
      m(paramContext, i); 
    v0 v01 = new v0((TextView)this);
    this.U = v01;
    v01.m(paramAttributeSet, paramInt);
    x2.w();
    ViewConfiguration viewConfiguration = ViewConfiguration.get(paramContext);
    this.A = viewConfiguration.getScaledTouchSlop();
    this.E = viewConfiguration.getScaledMinimumFlingVelocity();
    getEmojiTextViewHelper().c(paramAttributeSet, paramInt);
    refreshDrawableState();
    setChecked(isChecked());
  }
  
  private void a(boolean paramBoolean) {
    float f;
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    ObjectAnimator objectAnimator = ObjectAnimator.ofFloat(this, b0, new float[] { f });
    this.T = objectAnimator;
    objectAnimator.setDuration(250L);
    b.a(this.T, true);
    this.T.start();
  }
  
  private void b() {
    Drawable drawable = this.g;
    if (drawable != null && (this.j || this.k)) {
      drawable = androidx.core.graphics.drawable.a.r(drawable).mutate();
      this.g = drawable;
      if (this.j)
        androidx.core.graphics.drawable.a.o(drawable, this.h); 
      if (this.k)
        androidx.core.graphics.drawable.a.p(this.g, this.i); 
      if (this.g.isStateful())
        this.g.setState(getDrawableState()); 
    } 
  }
  
  private void c() {
    Drawable drawable = this.l;
    if (drawable != null && (this.o || this.p)) {
      drawable = androidx.core.graphics.drawable.a.r(drawable).mutate();
      this.l = drawable;
      if (this.o)
        androidx.core.graphics.drawable.a.o(drawable, this.m); 
      if (this.p)
        androidx.core.graphics.drawable.a.p(this.l, this.n); 
      if (this.l.isStateful())
        this.l.setState(getDrawableState()); 
    } 
  }
  
  private void d() {
    ObjectAnimator objectAnimator = this.T;
    if (objectAnimator != null)
      objectAnimator.cancel(); 
  }
  
  private void e(MotionEvent paramMotionEvent) {
    paramMotionEvent = MotionEvent.obtain(paramMotionEvent);
    paramMotionEvent.setAction(3);
    super.onTouchEvent(paramMotionEvent);
    paramMotionEvent.recycle();
  }
  
  private static float f(float paramFloat1, float paramFloat2, float paramFloat3) {
    if (paramFloat1 < paramFloat2)
      return paramFloat2; 
    paramFloat2 = paramFloat1;
    if (paramFloat1 > paramFloat3)
      paramFloat2 = paramFloat3; 
    return paramFloat2;
  }
  
  private CharSequence g(CharSequence paramCharSequence) {
    TransformationMethod transformationMethod = getEmojiTextViewHelper().f(this.S);
    CharSequence charSequence = paramCharSequence;
    if (transformationMethod != null)
      charSequence = transformationMethod.getTransformation(paramCharSequence, (View)this); 
    return charSequence;
  }
  
  private k getEmojiTextViewHelper() {
    if (this.V == null)
      this.V = new k((TextView)this); 
    return this.V;
  }
  
  private boolean getTargetCheckedState() {
    return (this.F > 0.5F);
  }
  
  private int getThumbOffset() {
    float f;
    if (i3.b((View)this)) {
      f = 1.0F - this.F;
    } else {
      f = this.F;
    } 
    return (int)(f * getThumbScrollRange() + 0.5F);
  }
  
  private int getThumbScrollRange() {
    Drawable drawable = this.l;
    if (drawable != null) {
      Rect rect1;
      Rect rect2 = this.a0;
      drawable.getPadding(rect2);
      drawable = this.g;
      if (drawable != null) {
        rect1 = x1.d(drawable);
      } else {
        rect1 = x1.c;
      } 
      return this.G - this.I - rect2.left - rect2.right - rect1.left - rect1.right;
    } 
    return 0;
  }
  
  private boolean h(float paramFloat1, float paramFloat2) {
    Drawable drawable = this.g;
    boolean bool2 = false;
    if (drawable == null)
      return false; 
    int m = getThumbOffset();
    this.g.getPadding(this.a0);
    int i = this.K;
    int j = this.A;
    m = this.J + m - j;
    int n = this.I;
    Rect rect = this.a0;
    int i1 = rect.left;
    int i2 = rect.right;
    int i3 = this.M;
    boolean bool1 = bool2;
    if (paramFloat1 > m) {
      bool1 = bool2;
      if (paramFloat1 < (n + m + i1 + i2 + j)) {
        bool1 = bool2;
        if (paramFloat2 > (i - j)) {
          bool1 = bool2;
          if (paramFloat2 < (i3 + j))
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  private Layout i(CharSequence paramCharSequence) {
    boolean bool;
    TextPaint textPaint = this.O;
    if (paramCharSequence != null) {
      bool = (int)Math.ceil(Layout.getDesiredWidth(paramCharSequence, textPaint));
    } else {
      bool = false;
    } 
    return (Layout)new StaticLayout(paramCharSequence, textPaint, bool, Layout.Alignment.ALIGN_NORMAL, 1.0F, 0.0F, true);
  }
  
  private void k() {
    if (Build.VERSION.SDK_INT >= 30) {
      CharSequence charSequence2 = this.w;
      CharSequence charSequence1 = charSequence2;
      if (charSequence2 == null)
        charSequence1 = getResources().getString(h.b); 
      e1.a1((View)this, charSequence1);
    } 
  }
  
  private void l() {
    if (Build.VERSION.SDK_INT >= 30) {
      CharSequence charSequence2 = this.u;
      CharSequence charSequence1 = charSequence2;
      if (charSequence2 == null)
        charSequence1 = getResources().getString(h.c); 
      e1.a1((View)this, charSequence1);
    } 
  }
  
  private void o(int paramInt1, int paramInt2) {
    Typeface typeface;
    if (paramInt1 != 1) {
      if (paramInt1 != 2) {
        if (paramInt1 != 3) {
          typeface = null;
        } else {
          typeface = Typeface.MONOSPACE;
        } 
      } else {
        typeface = Typeface.SERIF;
      } 
    } else {
      typeface = Typeface.SANS_SERIF;
    } 
    n(typeface, paramInt2);
  }
  
  private void p() {
    if (this.W == null) {
      if (!this.V.b())
        return; 
      if (e.h()) {
        e e = e.b();
        int i = e.d();
        if (i == 3 || i == 0) {
          c c1 = new c(this);
          this.W = c1;
          e.s(c1);
        } 
      } 
    } 
  }
  
  private void q(MotionEvent paramMotionEvent) {
    this.z = 0;
    int i = paramMotionEvent.getAction();
    boolean bool1 = true;
    if (i == 1 && isEnabled()) {
      i = 1;
    } else {
      i = 0;
    } 
    boolean bool2 = isChecked();
    if (i != 0) {
      this.D.computeCurrentVelocity(1000);
      float f = this.D.getXVelocity();
      if (Math.abs(f) > this.E) {
        if (i3.b((View)this) ? (f < 0.0F) : (f > 0.0F))
          bool1 = false; 
      } else {
        bool1 = getTargetCheckedState();
      } 
    } else {
      bool1 = bool2;
    } 
    if (bool1 != bool2)
      playSoundEffect(0); 
    setChecked(bool1);
    e(paramMotionEvent);
  }
  
  private void setTextOffInternal(CharSequence paramCharSequence) {
    this.w = paramCharSequence;
    this.x = g(paramCharSequence);
    this.R = null;
    if (this.y)
      p(); 
  }
  
  private void setTextOnInternal(CharSequence paramCharSequence) {
    this.u = paramCharSequence;
    this.v = g(paramCharSequence);
    this.Q = null;
    if (this.y)
      p(); 
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a0 : Landroid/graphics/Rect;
    //   4: astore #14
    //   6: aload_0
    //   7: getfield J : I
    //   10: istore #5
    //   12: aload_0
    //   13: getfield K : I
    //   16: istore #8
    //   18: aload_0
    //   19: getfield L : I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield M : I
    //   28: istore #9
    //   30: aload_0
    //   31: invokespecial getThumbOffset : ()I
    //   34: iload #5
    //   36: iadd
    //   37: istore_3
    //   38: aload_0
    //   39: getfield g : Landroid/graphics/drawable/Drawable;
    //   42: astore #13
    //   44: aload #13
    //   46: ifnull -> 59
    //   49: aload #13
    //   51: invokestatic d : (Landroid/graphics/drawable/Drawable;)Landroid/graphics/Rect;
    //   54: astore #13
    //   56: goto -> 64
    //   59: getstatic androidx/appcompat/widget/x1.c : Landroid/graphics/Rect;
    //   62: astore #13
    //   64: aload_0
    //   65: getfield l : Landroid/graphics/drawable/Drawable;
    //   68: astore #15
    //   70: iload_3
    //   71: istore_2
    //   72: aload #15
    //   74: ifnull -> 274
    //   77: aload #15
    //   79: aload #14
    //   81: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   84: pop
    //   85: aload #14
    //   87: getfield left : I
    //   90: istore #4
    //   92: iload_3
    //   93: iload #4
    //   95: iadd
    //   96: istore #10
    //   98: aload #13
    //   100: ifnull -> 238
    //   103: aload #13
    //   105: getfield left : I
    //   108: istore_3
    //   109: iload #5
    //   111: istore_2
    //   112: iload_3
    //   113: iload #4
    //   115: if_icmple -> 126
    //   118: iload #5
    //   120: iload_3
    //   121: iload #4
    //   123: isub
    //   124: iadd
    //   125: istore_2
    //   126: aload #13
    //   128: getfield top : I
    //   131: istore_3
    //   132: aload #14
    //   134: getfield top : I
    //   137: istore #4
    //   139: iload_3
    //   140: iload #4
    //   142: if_icmple -> 156
    //   145: iload_3
    //   146: iload #4
    //   148: isub
    //   149: iload #8
    //   151: iadd
    //   152: istore_3
    //   153: goto -> 159
    //   156: iload #8
    //   158: istore_3
    //   159: aload #13
    //   161: getfield right : I
    //   164: istore #5
    //   166: aload #14
    //   168: getfield right : I
    //   171: istore #7
    //   173: iload #6
    //   175: istore #4
    //   177: iload #5
    //   179: iload #7
    //   181: if_icmple -> 194
    //   184: iload #6
    //   186: iload #5
    //   188: iload #7
    //   190: isub
    //   191: isub
    //   192: istore #4
    //   194: aload #13
    //   196: getfield bottom : I
    //   199: istore #11
    //   201: aload #14
    //   203: getfield bottom : I
    //   206: istore #12
    //   208: iload_2
    //   209: istore #5
    //   211: iload #4
    //   213: istore #6
    //   215: iload_3
    //   216: istore #7
    //   218: iload #11
    //   220: iload #12
    //   222: if_icmple -> 242
    //   225: iload #9
    //   227: iload #11
    //   229: iload #12
    //   231: isub
    //   232: isub
    //   233: istore #7
    //   235: goto -> 258
    //   238: iload #8
    //   240: istore #7
    //   242: iload #9
    //   244: istore_2
    //   245: iload #7
    //   247: istore_3
    //   248: iload_2
    //   249: istore #7
    //   251: iload #6
    //   253: istore #4
    //   255: iload #5
    //   257: istore_2
    //   258: aload_0
    //   259: getfield l : Landroid/graphics/drawable/Drawable;
    //   262: iload_2
    //   263: iload_3
    //   264: iload #4
    //   266: iload #7
    //   268: invokevirtual setBounds : (IIII)V
    //   271: iload #10
    //   273: istore_2
    //   274: aload_0
    //   275: getfield g : Landroid/graphics/drawable/Drawable;
    //   278: astore #13
    //   280: aload #13
    //   282: ifnull -> 349
    //   285: aload #13
    //   287: aload #14
    //   289: invokevirtual getPadding : (Landroid/graphics/Rect;)Z
    //   292: pop
    //   293: iload_2
    //   294: aload #14
    //   296: getfield left : I
    //   299: isub
    //   300: istore_3
    //   301: iload_2
    //   302: aload_0
    //   303: getfield I : I
    //   306: iadd
    //   307: aload #14
    //   309: getfield right : I
    //   312: iadd
    //   313: istore_2
    //   314: aload_0
    //   315: getfield g : Landroid/graphics/drawable/Drawable;
    //   318: iload_3
    //   319: iload #8
    //   321: iload_2
    //   322: iload #9
    //   324: invokevirtual setBounds : (IIII)V
    //   327: aload_0
    //   328: invokevirtual getBackground : ()Landroid/graphics/drawable/Drawable;
    //   331: astore #13
    //   333: aload #13
    //   335: ifnull -> 349
    //   338: aload #13
    //   340: iload_3
    //   341: iload #8
    //   343: iload_2
    //   344: iload #9
    //   346: invokestatic l : (Landroid/graphics/drawable/Drawable;IIII)V
    //   349: aload_0
    //   350: aload_1
    //   351: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   354: return
  }
  
  public void drawableHotspotChanged(float paramFloat1, float paramFloat2) {
    super.drawableHotspotChanged(paramFloat1, paramFloat2);
    Drawable drawable = this.g;
    if (drawable != null)
      androidx.core.graphics.drawable.a.k(drawable, paramFloat1, paramFloat2); 
    drawable = this.l;
    if (drawable != null)
      androidx.core.graphics.drawable.a.k(drawable, paramFloat1, paramFloat2); 
  }
  
  protected void drawableStateChanged() {
    boolean bool;
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.g;
    int j = 0;
    int i = j;
    if (drawable != null) {
      i = j;
      if (drawable.isStateful())
        i = false | drawable.setState(arrayOfInt); 
    } 
    drawable = this.l;
    j = i;
    if (drawable != null) {
      j = i;
      if (drawable.isStateful())
        bool = i | drawable.setState(arrayOfInt); 
    } 
    if (bool)
      invalidate(); 
  }
  
  public int getCompoundPaddingLeft() {
    if (!i3.b((View)this))
      return super.getCompoundPaddingLeft(); 
    int j = super.getCompoundPaddingLeft() + this.G;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.s; 
    return i;
  }
  
  public int getCompoundPaddingRight() {
    if (i3.b((View)this))
      return super.getCompoundPaddingRight(); 
    int j = super.getCompoundPaddingRight() + this.G;
    int i = j;
    if (!TextUtils.isEmpty(getText()))
      i = j + this.s; 
    return i;
  }
  
  public ActionMode.Callback getCustomSelectionActionModeCallback() {
    return q.q(super.getCustomSelectionActionModeCallback());
  }
  
  public boolean getShowText() {
    return this.y;
  }
  
  public boolean getSplitTrack() {
    return this.t;
  }
  
  public int getSwitchMinWidth() {
    return this.r;
  }
  
  public int getSwitchPadding() {
    return this.s;
  }
  
  public CharSequence getTextOff() {
    return this.w;
  }
  
  public CharSequence getTextOn() {
    return this.u;
  }
  
  public Drawable getThumbDrawable() {
    return this.g;
  }
  
  protected final float getThumbPosition() {
    return this.F;
  }
  
  public int getThumbTextPadding() {
    return this.q;
  }
  
  public ColorStateList getThumbTintList() {
    return this.h;
  }
  
  public PorterDuff.Mode getThumbTintMode() {
    return this.i;
  }
  
  public Drawable getTrackDrawable() {
    return this.l;
  }
  
  public ColorStateList getTrackTintList() {
    return this.m;
  }
  
  public PorterDuff.Mode getTrackTintMode() {
    return this.n;
  }
  
  void j() {
    setTextOnInternal(this.u);
    setTextOffInternal(this.w);
    requestLayout();
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    drawable = this.l;
    if (drawable != null)
      drawable.jumpToCurrentState(); 
    ObjectAnimator objectAnimator = this.T;
    if (objectAnimator != null && objectAnimator.isStarted()) {
      this.T.end();
      this.T = null;
    } 
  }
  
  public void m(Context paramContext, int paramInt) {
    x2 x2 = x2.t(paramContext, paramInt, j.S2);
    ColorStateList colorStateList = x2.c(j.W2);
    if (colorStateList != null) {
      this.P = colorStateList;
    } else {
      this.P = getTextColors();
    } 
    paramInt = x2.f(j.T2, 0);
    if (paramInt != 0) {
      float f = paramInt;
      if (f != this.O.getTextSize()) {
        this.O.setTextSize(f);
        requestLayout();
      } 
    } 
    o(x2.k(j.U2, -1), x2.k(j.V2, -1));
    if (x2.a(j.d3, false)) {
      this.S = (TransformationMethod)new j.a(getContext());
    } else {
      this.S = null;
    } 
    setTextOnInternal(this.u);
    setTextOffInternal(this.w);
    x2.w();
  }
  
  public void n(Typeface paramTypeface, int paramInt) {
    TextPaint textPaint;
    float f = 0.0F;
    boolean bool = false;
    if (paramInt > 0) {
      int i;
      if (paramTypeface == null) {
        paramTypeface = Typeface.defaultFromStyle(paramInt);
      } else {
        paramTypeface = Typeface.create(paramTypeface, paramInt);
      } 
      setSwitchTypeface(paramTypeface);
      if (paramTypeface != null) {
        i = paramTypeface.getStyle();
      } else {
        i = 0;
      } 
      paramInt = i & paramInt;
      textPaint = this.O;
      if ((paramInt & 0x1) != 0)
        bool = true; 
      textPaint.setFakeBoldText(bool);
      textPaint = this.O;
      if ((paramInt & 0x2) != 0)
        f = -0.25F; 
      textPaint.setTextSkewX(f);
      return;
    } 
    this.O.setFakeBoldText(false);
    this.O.setTextSkewX(0.0F);
    setSwitchTypeface((Typeface)textPaint);
  }
  
  protected int[] onCreateDrawableState(int paramInt) {
    int[] arrayOfInt = super.onCreateDrawableState(paramInt + 1);
    if (isChecked())
      View.mergeDrawableStates(arrayOfInt, c0); 
    return arrayOfInt;
  }
  
  protected void onDraw(Canvas paramCanvas) {
    Layout layout;
    super.onDraw(paramCanvas);
    Rect rect = this.a0;
    Drawable drawable2 = this.l;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
    } else {
      rect.setEmpty();
    } 
    int j = this.K;
    int m = this.M;
    int n = rect.top;
    int i1 = rect.bottom;
    Drawable drawable1 = this.g;
    if (drawable2 != null)
      if (this.t && drawable1 != null) {
        Rect rect1 = x1.d(drawable1);
        drawable1.copyBounds(rect);
        rect.left += rect1.left;
        rect.right -= rect1.right;
        int i2 = paramCanvas.save();
        paramCanvas.clipRect(rect, Region.Op.DIFFERENCE);
        drawable2.draw(paramCanvas);
        paramCanvas.restoreToCount(i2);
      } else {
        drawable2.draw(paramCanvas);
      }  
    int i = paramCanvas.save();
    if (drawable1 != null)
      drawable1.draw(paramCanvas); 
    if (getTargetCheckedState()) {
      layout = this.Q;
    } else {
      layout = this.R;
    } 
    if (layout != null) {
      int i2;
      int[] arrayOfInt = getDrawableState();
      ColorStateList colorStateList = this.P;
      if (colorStateList != null)
        this.O.setColor(colorStateList.getColorForState(arrayOfInt, 0)); 
      this.O.drawableState = arrayOfInt;
      if (drawable1 != null) {
        Rect rect1 = drawable1.getBounds();
        i2 = rect1.left + rect1.right;
      } else {
        i2 = getWidth();
      } 
      i2 /= 2;
      int i3 = layout.getWidth() / 2;
      j = (j + n + m - i1) / 2;
      m = layout.getHeight() / 2;
      paramCanvas.translate((i2 - i3), (j - m));
      layout.draw(paramCanvas);
    } 
    paramCanvas.restoreToCount(i);
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName("android.widget.Switch");
  }
  
  public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo paramAccessibilityNodeInfo) {
    super.onInitializeAccessibilityNodeInfo(paramAccessibilityNodeInfo);
    paramAccessibilityNodeInfo.setClassName("android.widget.Switch");
    if (Build.VERSION.SDK_INT < 30) {
      CharSequence charSequence;
      if (isChecked()) {
        charSequence = this.u;
      } else {
        charSequence = this.w;
      } 
      if (!TextUtils.isEmpty(charSequence)) {
        CharSequence charSequence1 = paramAccessibilityNodeInfo.getText();
        if (TextUtils.isEmpty(charSequence1)) {
          paramAccessibilityNodeInfo.setText(charSequence);
          return;
        } 
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(charSequence1);
        stringBuilder.append(' ');
        stringBuilder.append(charSequence);
        paramAccessibilityNodeInfo.setText(stringBuilder);
      } 
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    Drawable drawable = this.g;
    paramInt1 = 0;
    if (drawable != null) {
      Rect rect1 = this.a0;
      Drawable drawable1 = this.l;
      if (drawable1 != null) {
        drawable1.getPadding(rect1);
      } else {
        rect1.setEmpty();
      } 
      Rect rect2 = x1.d(this.g);
      paramInt2 = Math.max(0, rect2.left - rect1.left);
      paramInt1 = Math.max(0, rect2.right - rect1.right);
    } else {
      paramInt2 = 0;
    } 
    if (i3.b((View)this)) {
      paramInt3 = getPaddingLeft() + paramInt2;
      paramInt1 = this.G + paramInt3 - paramInt2 - paramInt1;
      paramInt2 = paramInt3;
      paramInt3 = paramInt1;
    } else {
      paramInt3 = getWidth() - getPaddingRight() - paramInt1;
      paramInt2 = paramInt3 - this.G + paramInt2 + paramInt1;
    } 
    paramInt1 = getGravity() & 0x70;
    if (paramInt1 != 16) {
      if (paramInt1 != 80) {
        paramInt1 = getPaddingTop();
        paramInt4 = this.H;
      } else {
        paramInt4 = getHeight() - getPaddingBottom();
        paramInt1 = paramInt4 - this.H;
        this.J = paramInt2;
        this.K = paramInt1;
        this.M = paramInt4;
        this.L = paramInt3;
      } 
    } else {
      paramInt1 = (getPaddingTop() + getHeight() - getPaddingBottom()) / 2;
      paramInt4 = this.H;
      paramInt1 -= paramInt4 / 2;
    } 
    paramInt4 += paramInt1;
    this.J = paramInt2;
    this.K = paramInt1;
    this.M = paramInt4;
    this.L = paramInt3;
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    int j;
    if (this.y) {
      if (this.Q == null)
        this.Q = i(this.v); 
      if (this.R == null)
        this.R = i(this.x); 
    } 
    Rect rect = this.a0;
    Drawable drawable2 = this.g;
    int n = 0;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.g.getIntrinsicWidth() - rect.left - rect.right;
      i = this.g.getIntrinsicHeight();
    } else {
      j = 0;
      i = 0;
    } 
    if (this.y) {
      m = Math.max(this.Q.getWidth(), this.R.getWidth()) + this.q * 2;
    } else {
      m = 0;
    } 
    this.I = Math.max(m, j);
    drawable2 = this.l;
    if (drawable2 != null) {
      drawable2.getPadding(rect);
      j = this.l.getIntrinsicHeight();
    } else {
      rect.setEmpty();
      j = n;
    } 
    int i2 = rect.left;
    int i1 = rect.right;
    Drawable drawable1 = this.g;
    n = i1;
    int m = i2;
    if (drawable1 != null) {
      Rect rect1 = x1.d(drawable1);
      m = Math.max(i2, rect1.left);
      n = Math.max(i1, rect1.right);
    } 
    if (this.N) {
      m = Math.max(this.r, this.I * 2 + m + n);
    } else {
      m = this.r;
    } 
    int i = Math.max(j, i);
    this.G = m;
    this.H = i;
    super.onMeasure(paramInt1, paramInt2);
    if (getMeasuredHeight() < i)
      setMeasuredDimension(getMeasuredWidthAndState(), i); 
  }
  
  public void onPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    CharSequence charSequence;
    super.onPopulateAccessibilityEvent(paramAccessibilityEvent);
    if (isChecked()) {
      charSequence = this.u;
    } else {
      charSequence = this.w;
    } 
    if (charSequence != null)
      paramAccessibilityEvent.getText().add(charSequence); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.D.addMovement(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return super.onTouchEvent(paramMotionEvent); 
        } else {
          i = this.z;
          if (i != 1) {
            if (i == 2) {
              float f3 = paramMotionEvent.getX();
              i = getThumbScrollRange();
              float f1 = f3 - this.B;
              if (i != 0) {
                f1 /= i;
              } else if (f1 > 0.0F) {
                f1 = 1.0F;
              } else {
                f1 = -1.0F;
              } 
              float f2 = f1;
              if (i3.b((View)this))
                f2 = -f1; 
              f1 = f(this.F + f2, 0.0F, 1.0F);
              if (f1 != this.F) {
                this.B = f3;
                setThumbPosition(f1);
              } 
              return true;
            } 
          } else {
            float f1 = paramMotionEvent.getX();
            float f2 = paramMotionEvent.getY();
            if (Math.abs(f1 - this.B) > this.A || Math.abs(f2 - this.C) > this.A) {
              this.z = 2;
              getParent().requestDisallowInterceptTouchEvent(true);
              this.B = f1;
              this.C = f2;
              return true;
            } 
          } 
          return super.onTouchEvent(paramMotionEvent);
        }  
      if (this.z == 2) {
        q(paramMotionEvent);
        super.onTouchEvent(paramMotionEvent);
        return true;
      } 
      this.z = 0;
      this.D.clear();
    } else {
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      if (isEnabled() && h(f1, f2)) {
        this.z = 1;
        this.B = f1;
        this.C = f2;
      } 
    } 
    return super.onTouchEvent(paramMotionEvent);
  }
  
  public void setAllCaps(boolean paramBoolean) {
    super.setAllCaps(paramBoolean);
    getEmojiTextViewHelper().d(paramBoolean);
  }
  
  public void setChecked(boolean paramBoolean) {
    float f;
    super.setChecked(paramBoolean);
    paramBoolean = isChecked();
    if (paramBoolean) {
      l();
    } else {
      k();
    } 
    if (getWindowToken() != null && e1.a0((View)this)) {
      a(paramBoolean);
      return;
    } 
    d();
    if (paramBoolean) {
      f = 1.0F;
    } else {
      f = 0.0F;
    } 
    setThumbPosition(f);
  }
  
  public void setCustomSelectionActionModeCallback(ActionMode.Callback paramCallback) {
    super.setCustomSelectionActionModeCallback(q.r((TextView)this, paramCallback));
  }
  
  public void setEmojiCompatEnabled(boolean paramBoolean) {
    getEmojiTextViewHelper().e(paramBoolean);
    setTextOnInternal(this.u);
    setTextOffInternal(this.w);
    requestLayout();
  }
  
  protected final void setEnforceSwitchWidth(boolean paramBoolean) {
    this.N = paramBoolean;
    invalidate();
  }
  
  public void setFilters(InputFilter[] paramArrayOfInputFilter) {
    super.setFilters(getEmojiTextViewHelper().a(paramArrayOfInputFilter));
  }
  
  public void setShowText(boolean paramBoolean) {
    if (this.y != paramBoolean) {
      this.y = paramBoolean;
      requestLayout();
      if (paramBoolean)
        p(); 
    } 
  }
  
  public void setSplitTrack(boolean paramBoolean) {
    this.t = paramBoolean;
    invalidate();
  }
  
  public void setSwitchMinWidth(int paramInt) {
    this.r = paramInt;
    requestLayout();
  }
  
  public void setSwitchPadding(int paramInt) {
    this.s = paramInt;
    requestLayout();
  }
  
  public void setSwitchTypeface(Typeface paramTypeface) {
    if ((this.O.getTypeface() != null && !this.O.getTypeface().equals(paramTypeface)) || (this.O.getTypeface() == null && paramTypeface != null)) {
      this.O.setTypeface(paramTypeface);
      requestLayout();
      invalidate();
    } 
  }
  
  public void setTextOff(CharSequence paramCharSequence) {
    setTextOffInternal(paramCharSequence);
    requestLayout();
    if (!isChecked())
      k(); 
  }
  
  public void setTextOn(CharSequence paramCharSequence) {
    setTextOnInternal(paramCharSequence);
    requestLayout();
    if (isChecked())
      l(); 
  }
  
  public void setThumbDrawable(Drawable paramDrawable) {
    Drawable drawable = this.g;
    if (drawable != null)
      drawable.setCallback(null); 
    this.g = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  void setThumbPosition(float paramFloat) {
    this.F = paramFloat;
    invalidate();
  }
  
  public void setThumbResource(int paramInt) {
    setThumbDrawable(g.a.b(getContext(), paramInt));
  }
  
  public void setThumbTextPadding(int paramInt) {
    this.q = paramInt;
    requestLayout();
  }
  
  public void setThumbTintList(ColorStateList paramColorStateList) {
    this.h = paramColorStateList;
    this.j = true;
    b();
  }
  
  public void setThumbTintMode(PorterDuff.Mode paramMode) {
    this.i = paramMode;
    this.k = true;
    b();
  }
  
  public void setTrackDrawable(Drawable paramDrawable) {
    Drawable drawable = this.l;
    if (drawable != null)
      drawable.setCallback(null); 
    this.l = paramDrawable;
    if (paramDrawable != null)
      paramDrawable.setCallback((Drawable.Callback)this); 
    requestLayout();
  }
  
  public void setTrackResource(int paramInt) {
    setTrackDrawable(g.a.b(getContext(), paramInt));
  }
  
  public void setTrackTintList(ColorStateList paramColorStateList) {
    this.m = paramColorStateList;
    this.o = true;
    c();
  }
  
  public void setTrackTintMode(PorterDuff.Mode paramMode) {
    this.n = paramMode;
    this.p = true;
    c();
  }
  
  public void toggle() {
    setChecked(isChecked() ^ true);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.g || paramDrawable == this.l);
  }
  
  class a extends Property<SwitchCompat, Float> {
    a(SwitchCompat this$0, String param1String) {
      super((Class)this$0, param1String);
    }
    
    public Float a(SwitchCompat param1SwitchCompat) {
      return Float.valueOf(param1SwitchCompat.F);
    }
    
    public void b(SwitchCompat param1SwitchCompat, Float param1Float) {
      param1SwitchCompat.setThumbPosition(param1Float.floatValue());
    }
  }
  
  static class b {
    static void a(ObjectAnimator param1ObjectAnimator, boolean param1Boolean) {
      param1ObjectAnimator.setAutoCancel(param1Boolean);
    }
  }
  
  static class c extends e.e {
    private final Reference<SwitchCompat> a;
    
    c(SwitchCompat param1SwitchCompat) {
      this.a = new WeakReference<SwitchCompat>(param1SwitchCompat);
    }
    
    public void a(Throwable param1Throwable) {
      SwitchCompat switchCompat = this.a.get();
      if (switchCompat != null)
        switchCompat.j(); 
    }
    
    public void b() {
      SwitchCompat switchCompat = this.a.get();
      if (switchCompat != null)
        switchCompat.j(); 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\SwitchCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */