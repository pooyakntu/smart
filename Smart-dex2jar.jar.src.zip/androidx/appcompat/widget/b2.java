package androidx.appcompat.widget;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import androidx.appcompat.view.menu.p;

public abstract class b2 implements View.OnTouchListener, View.OnAttachStateChangeListener {
  private final float g;
  
  private final int h;
  
  private final int i;
  
  final View j;
  
  private Runnable k;
  
  private Runnable l;
  
  private boolean m;
  
  private int n;
  
  private final int[] o = new int[2];
  
  public b2(View paramView) {
    this.j = paramView;
    paramView.setLongClickable(true);
    paramView.addOnAttachStateChangeListener(this);
    this.g = ViewConfiguration.get(paramView.getContext()).getScaledTouchSlop();
    int i = ViewConfiguration.getTapTimeout();
    this.h = i;
    this.i = (i + ViewConfiguration.getLongPressTimeout()) / 2;
  }
  
  private void a() {
    Runnable runnable = this.l;
    if (runnable != null)
      this.j.removeCallbacks(runnable); 
    runnable = this.k;
    if (runnable != null)
      this.j.removeCallbacks(runnable); 
  }
  
  private boolean f(MotionEvent paramMotionEvent) {
    View view = this.j;
    p p = b();
    boolean bool2 = false;
    boolean bool1 = bool2;
    if (p != null) {
      if (!p.a())
        return false; 
      z1 z1 = (z1)p.j();
      bool1 = bool2;
      if (z1 != null) {
        if (!z1.isShown())
          return false; 
        MotionEvent motionEvent = MotionEvent.obtainNoHistory(paramMotionEvent);
        i(view, motionEvent);
        j((View)z1, motionEvent);
        boolean bool = z1.e(motionEvent, this.n);
        motionEvent.recycle();
        int i = paramMotionEvent.getActionMasked();
        if (i != 1 && i != 3) {
          i = 1;
        } else {
          i = 0;
        } 
        bool1 = bool2;
        if (bool) {
          bool1 = bool2;
          if (i != 0)
            bool1 = true; 
        } 
      } 
    } 
    return bool1;
  }
  
  private boolean g(MotionEvent paramMotionEvent) {
    View view = this.j;
    if (!view.isEnabled())
      return false; 
    int i = paramMotionEvent.getActionMasked();
    if (i != 0) {
      if (i != 1)
        if (i != 2) {
          if (i != 3)
            return false; 
        } else {
          i = paramMotionEvent.findPointerIndex(this.n);
          if (i >= 0 && !h(view, paramMotionEvent.getX(i), paramMotionEvent.getY(i), this.g)) {
            a();
            view.getParent().requestDisallowInterceptTouchEvent(true);
            return true;
          } 
          return false;
        }  
      a();
      return false;
    } 
    this.n = paramMotionEvent.getPointerId(0);
    if (this.k == null)
      this.k = new a(this); 
    view.postDelayed(this.k, this.h);
    if (this.l == null)
      this.l = new b(this); 
    view.postDelayed(this.l, this.i);
    return false;
  }
  
  private static boolean h(View paramView, float paramFloat1, float paramFloat2, float paramFloat3) {
    float f = -paramFloat3;
    return (paramFloat1 >= f && paramFloat2 >= f && paramFloat1 < (paramView.getRight() - paramView.getLeft()) + paramFloat3 && paramFloat2 < (paramView.getBottom() - paramView.getTop()) + paramFloat3);
  }
  
  private boolean i(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.o;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(arrayOfInt[0], arrayOfInt[1]);
    return true;
  }
  
  private boolean j(View paramView, MotionEvent paramMotionEvent) {
    int[] arrayOfInt = this.o;
    paramView.getLocationOnScreen(arrayOfInt);
    paramMotionEvent.offsetLocation(-arrayOfInt[0], -arrayOfInt[1]);
    return true;
  }
  
  public abstract p b();
  
  protected abstract boolean c();
  
  protected boolean d() {
    p p = b();
    if (p != null && p.a())
      p.dismiss(); 
    return true;
  }
  
  void e() {
    a();
    View view = this.j;
    if (view.isEnabled()) {
      if (view.isLongClickable())
        return; 
      if (!c())
        return; 
      view.getParent().requestDisallowInterceptTouchEvent(true);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      view.onTouchEvent(motionEvent);
      motionEvent.recycle();
      this.m = true;
    } 
  }
  
  public boolean onTouch(View paramView, MotionEvent paramMotionEvent) {
    boolean bool1;
    boolean bool = this.m;
    boolean bool3 = true;
    if (bool) {
      if (f(paramMotionEvent) || !d()) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
    } else {
      boolean bool4;
      if (g(paramMotionEvent) && c()) {
        bool4 = true;
      } else {
        bool4 = false;
      } 
      bool1 = bool4;
      if (bool4) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        this.j.onTouchEvent(motionEvent);
        motionEvent.recycle();
        bool1 = bool4;
      } 
    } 
    this.m = bool1;
    boolean bool2 = bool3;
    if (!bool1) {
      if (bool)
        return true; 
      bool2 = false;
    } 
    return bool2;
  }
  
  public void onViewAttachedToWindow(View paramView) {}
  
  public void onViewDetachedFromWindow(View paramView) {
    this.m = false;
    this.n = -1;
    Runnable runnable = this.k;
    if (runnable != null)
      this.j.removeCallbacks(runnable); 
  }
  
  private class a implements Runnable {
    a(b2 this$0) {}
    
    public void run() {
      ViewParent viewParent = this.g.j.getParent();
      if (viewParent != null)
        viewParent.requestDisallowInterceptTouchEvent(true); 
    }
  }
  
  private class b implements Runnable {
    b(b2 this$0) {}
    
    public void run() {
      this.g.e();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\widget\b2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */