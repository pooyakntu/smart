package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h3;
import androidx.appcompat.widget.i3;
import androidx.appcompat.widget.r1;
import androidx.appcompat.widget.x2;
import androidx.core.view.e1;
import androidx.core.view.e3;
import androidx.core.view.f3;
import androidx.core.view.g3;
import androidx.core.view.t3;
import androidx.core.view.u0;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;

class i extends h implements g.a, LayoutInflater.Factory2 {
  private static final androidx.collection.g<String, Integer> p0 = new androidx.collection.g();
  
  private static final boolean q0 = false;
  
  private static final int[] r0 = new int[] { 16842836 };
  
  private static final boolean s0 = "robolectric".equals(Build.FINGERPRINT) ^ true;
  
  private static final boolean t0 = true;
  
  androidx.appcompat.view.b A;
  
  ActionBarContextView B;
  
  PopupWindow C;
  
  Runnable D;
  
  e3 E = null;
  
  private boolean F = true;
  
  private boolean G;
  
  ViewGroup H;
  
  private TextView I;
  
  private View J;
  
  private boolean K;
  
  private boolean L;
  
  boolean M;
  
  boolean N;
  
  boolean O;
  
  boolean P;
  
  boolean Q;
  
  private boolean R;
  
  private u[] S;
  
  private u T;
  
  private boolean U;
  
  private boolean V;
  
  private boolean W;
  
  boolean X;
  
  private Configuration Y;
  
  private int Z = -100;
  
  private int a0;
  
  private int b0;
  
  private boolean c0;
  
  private q d0;
  
  private q e0;
  
  boolean f0;
  
  int g0;
  
  private final Runnable h0 = new a(this);
  
  private boolean i0;
  
  private Rect j0;
  
  private Rect k0;
  
  private u l0;
  
  private y m0;
  
  private OnBackInvokedDispatcher n0;
  
  private OnBackInvokedCallback o0;
  
  final Object p;
  
  final Context q;
  
  Window r;
  
  private o s;
  
  final e t;
  
  a u;
  
  MenuInflater v;
  
  private CharSequence w;
  
  private r1 x;
  
  private h y;
  
  private v z;
  
  i(Activity paramActivity, e parame) {
    this((Context)paramActivity, null, parame, paramActivity);
  }
  
  i(Dialog paramDialog, e parame) {
    this(paramDialog.getContext(), paramDialog.getWindow(), parame, paramDialog);
  }
  
  private i(Context paramContext, Window paramWindow, e parame, Object paramObject) {
    this.q = paramContext;
    this.t = parame;
    this.p = paramObject;
    if (this.Z == -100 && paramObject instanceof Dialog) {
      d d = a1();
      if (d != null)
        this.Z = d.getDelegate().o(); 
    } 
    if (this.Z == -100) {
      androidx.collection.g<String, Integer> g1 = p0;
      Integer integer = (Integer)g1.get(paramObject.getClass().getName());
      if (integer != null) {
        this.Z = integer.intValue();
        g1.remove(paramObject.getClass().getName());
      } 
    } 
    if (paramWindow != null)
      W(paramWindow); 
    androidx.appcompat.widget.i.h();
  }
  
  private boolean A0(u paramu) {
    // Byte code:
    //   0: aload_0
    //   1: getfield q : Landroid/content/Context;
    //   4: astore #5
    //   6: aload_1
    //   7: getfield a : I
    //   10: istore_2
    //   11: iload_2
    //   12: ifeq -> 24
    //   15: aload #5
    //   17: astore_3
    //   18: iload_2
    //   19: bipush #108
    //   21: if_icmpne -> 197
    //   24: aload #5
    //   26: astore_3
    //   27: aload_0
    //   28: getfield x : Landroidx/appcompat/widget/r1;
    //   31: ifnull -> 197
    //   34: new android/util/TypedValue
    //   37: dup
    //   38: invokespecial <init> : ()V
    //   41: astore #6
    //   43: aload #5
    //   45: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   48: astore #7
    //   50: aload #7
    //   52: getstatic f/a.f : I
    //   55: aload #6
    //   57: iconst_1
    //   58: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   61: pop
    //   62: aload #6
    //   64: getfield resourceId : I
    //   67: ifeq -> 109
    //   70: aload #5
    //   72: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   75: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   78: astore_3
    //   79: aload_3
    //   80: aload #7
    //   82: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   85: aload_3
    //   86: aload #6
    //   88: getfield resourceId : I
    //   91: iconst_1
    //   92: invokevirtual applyStyle : (IZ)V
    //   95: aload_3
    //   96: getstatic f/a.g : I
    //   99: aload #6
    //   101: iconst_1
    //   102: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   105: pop
    //   106: goto -> 123
    //   109: aload #7
    //   111: getstatic f/a.g : I
    //   114: aload #6
    //   116: iconst_1
    //   117: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   120: pop
    //   121: aconst_null
    //   122: astore_3
    //   123: aload_3
    //   124: astore #4
    //   126: aload #6
    //   128: getfield resourceId : I
    //   131: ifeq -> 169
    //   134: aload_3
    //   135: astore #4
    //   137: aload_3
    //   138: ifnonnull -> 158
    //   141: aload #5
    //   143: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   146: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   149: astore #4
    //   151: aload #4
    //   153: aload #7
    //   155: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   158: aload #4
    //   160: aload #6
    //   162: getfield resourceId : I
    //   165: iconst_1
    //   166: invokevirtual applyStyle : (IZ)V
    //   169: aload #5
    //   171: astore_3
    //   172: aload #4
    //   174: ifnull -> 197
    //   177: new androidx/appcompat/view/d
    //   180: dup
    //   181: aload #5
    //   183: iconst_0
    //   184: invokespecial <init> : (Landroid/content/Context;I)V
    //   187: astore_3
    //   188: aload_3
    //   189: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   192: aload #4
    //   194: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   197: new androidx/appcompat/view/menu/g
    //   200: dup
    //   201: aload_3
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: astore_3
    //   206: aload_3
    //   207: aload_0
    //   208: invokevirtual R : (Landroidx/appcompat/view/menu/g$a;)V
    //   211: aload_1
    //   212: aload_3
    //   213: invokevirtual c : (Landroidx/appcompat/view/menu/g;)V
    //   216: iconst_1
    //   217: ireturn
  }
  
  private void B0(int paramInt) {
    this.g0 = 1 << paramInt | this.g0;
    if (!this.f0) {
      e1.o0(this.r.getDecorView(), this.h0);
      this.f0 = true;
    } 
  }
  
  private boolean G0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      u u1 = u0(paramInt, true);
      if (!u1.o)
        return Q0(u1, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean J0(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield A : Landroidx/appcompat/view/b;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: iconst_1
    //   10: istore #4
    //   12: aload_0
    //   13: iload_1
    //   14: iconst_1
    //   15: invokevirtual u0 : (IZ)Landroidx/appcompat/app/i$u;
    //   18: astore #5
    //   20: iload_1
    //   21: ifne -> 113
    //   24: aload_0
    //   25: getfield x : Landroidx/appcompat/widget/r1;
    //   28: astore #6
    //   30: aload #6
    //   32: ifnull -> 113
    //   35: aload #6
    //   37: invokeinterface d : ()Z
    //   42: ifeq -> 113
    //   45: aload_0
    //   46: getfield q : Landroid/content/Context;
    //   49: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   52: invokevirtual hasPermanentMenuKey : ()Z
    //   55: ifne -> 113
    //   58: aload_0
    //   59: getfield x : Landroidx/appcompat/widget/r1;
    //   62: invokeinterface b : ()Z
    //   67: ifne -> 100
    //   70: aload_0
    //   71: getfield X : Z
    //   74: ifne -> 186
    //   77: aload_0
    //   78: aload #5
    //   80: aload_2
    //   81: invokespecial Q0 : (Landroidx/appcompat/app/i$u;Landroid/view/KeyEvent;)Z
    //   84: ifeq -> 186
    //   87: aload_0
    //   88: getfield x : Landroidx/appcompat/widget/r1;
    //   91: invokeinterface g : ()Z
    //   96: istore_3
    //   97: goto -> 198
    //   100: aload_0
    //   101: getfield x : Landroidx/appcompat/widget/r1;
    //   104: invokeinterface f : ()Z
    //   109: istore_3
    //   110: goto -> 198
    //   113: aload #5
    //   115: getfield o : Z
    //   118: istore_3
    //   119: iload_3
    //   120: ifne -> 191
    //   123: aload #5
    //   125: getfield n : Z
    //   128: ifeq -> 134
    //   131: goto -> 191
    //   134: aload #5
    //   136: getfield m : Z
    //   139: ifeq -> 186
    //   142: aload #5
    //   144: getfield r : Z
    //   147: ifeq -> 167
    //   150: aload #5
    //   152: iconst_0
    //   153: putfield m : Z
    //   156: aload_0
    //   157: aload #5
    //   159: aload_2
    //   160: invokespecial Q0 : (Landroidx/appcompat/app/i$u;Landroid/view/KeyEvent;)Z
    //   163: istore_3
    //   164: goto -> 169
    //   167: iconst_1
    //   168: istore_3
    //   169: iload_3
    //   170: ifeq -> 186
    //   173: aload_0
    //   174: aload #5
    //   176: aload_2
    //   177: invokespecial N0 : (Landroidx/appcompat/app/i$u;Landroid/view/KeyEvent;)V
    //   180: iload #4
    //   182: istore_3
    //   183: goto -> 198
    //   186: iconst_0
    //   187: istore_3
    //   188: goto -> 198
    //   191: aload_0
    //   192: aload #5
    //   194: iconst_1
    //   195: invokevirtual d0 : (Landroidx/appcompat/app/i$u;Z)V
    //   198: iload_3
    //   199: ifeq -> 228
    //   202: aload_0
    //   203: getfield q : Landroid/content/Context;
    //   206: invokevirtual getApplicationContext : ()Landroid/content/Context;
    //   209: ldc_w 'audio'
    //   212: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   215: checkcast android/media/AudioManager
    //   218: astore_2
    //   219: aload_2
    //   220: ifnull -> 228
    //   223: aload_2
    //   224: iconst_0
    //   225: invokevirtual playSoundEffect : (I)V
    //   228: iload_3
    //   229: ireturn
  }
  
  private void N0(u paramu, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 416
    //   7: aload_0
    //   8: getfield X : Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 54
    //   22: aload_0
    //   23: getfield q : Landroid/content/Context;
    //   26: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   29: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   32: getfield screenLayout : I
    //   35: bipush #15
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 47
    //   42: iconst_1
    //   43: istore_3
    //   44: goto -> 49
    //   47: iconst_0
    //   48: istore_3
    //   49: iload_3
    //   50: ifeq -> 54
    //   53: return
    //   54: aload_0
    //   55: invokevirtual w0 : ()Landroid/view/Window$Callback;
    //   58: astore #4
    //   60: aload #4
    //   62: ifnull -> 90
    //   65: aload #4
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroidx/appcompat/view/menu/g;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual d0 : (Landroidx/appcompat/app/i$u;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield q : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #5
    //   105: aload #5
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial Q0 : (Landroidx/appcompat/app/i$u;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: astore_2
    //   126: aload_2
    //   127: ifnull -> 171
    //   130: aload_1
    //   131: getfield q : Z
    //   134: ifeq -> 140
    //   137: goto -> 171
    //   140: aload_1
    //   141: getfield i : Landroid/view/View;
    //   144: astore_2
    //   145: aload_2
    //   146: ifnull -> 331
    //   149: aload_2
    //   150: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   153: astore_2
    //   154: aload_2
    //   155: ifnull -> 331
    //   158: aload_2
    //   159: getfield width : I
    //   162: iconst_m1
    //   163: if_icmpne -> 331
    //   166: iconst_m1
    //   167: istore_3
    //   168: goto -> 334
    //   171: aload_2
    //   172: ifnonnull -> 191
    //   175: aload_0
    //   176: aload_1
    //   177: invokespecial z0 : (Landroidx/appcompat/app/i$u;)Z
    //   180: ifeq -> 190
    //   183: aload_1
    //   184: getfield g : Landroid/view/ViewGroup;
    //   187: ifnonnull -> 212
    //   190: return
    //   191: aload_1
    //   192: getfield q : Z
    //   195: ifeq -> 212
    //   198: aload_2
    //   199: invokevirtual getChildCount : ()I
    //   202: ifle -> 212
    //   205: aload_1
    //   206: getfield g : Landroid/view/ViewGroup;
    //   209: invokevirtual removeAllViews : ()V
    //   212: aload_0
    //   213: aload_1
    //   214: invokespecial y0 : (Landroidx/appcompat/app/i$u;)Z
    //   217: ifeq -> 411
    //   220: aload_1
    //   221: invokevirtual b : ()Z
    //   224: ifne -> 230
    //   227: goto -> 411
    //   230: aload_1
    //   231: getfield h : Landroid/view/View;
    //   234: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   237: astore #4
    //   239: aload #4
    //   241: astore_2
    //   242: aload #4
    //   244: ifnonnull -> 259
    //   247: new android/view/ViewGroup$LayoutParams
    //   250: dup
    //   251: bipush #-2
    //   253: bipush #-2
    //   255: invokespecial <init> : (II)V
    //   258: astore_2
    //   259: aload_1
    //   260: getfield b : I
    //   263: istore_3
    //   264: aload_1
    //   265: getfield g : Landroid/view/ViewGroup;
    //   268: iload_3
    //   269: invokevirtual setBackgroundResource : (I)V
    //   272: aload_1
    //   273: getfield h : Landroid/view/View;
    //   276: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   279: astore #4
    //   281: aload #4
    //   283: instanceof android/view/ViewGroup
    //   286: ifeq -> 301
    //   289: aload #4
    //   291: checkcast android/view/ViewGroup
    //   294: aload_1
    //   295: getfield h : Landroid/view/View;
    //   298: invokevirtual removeView : (Landroid/view/View;)V
    //   301: aload_1
    //   302: getfield g : Landroid/view/ViewGroup;
    //   305: aload_1
    //   306: getfield h : Landroid/view/View;
    //   309: aload_2
    //   310: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   313: aload_1
    //   314: getfield h : Landroid/view/View;
    //   317: invokevirtual hasFocus : ()Z
    //   320: ifne -> 331
    //   323: aload_1
    //   324: getfield h : Landroid/view/View;
    //   327: invokevirtual requestFocus : ()Z
    //   330: pop
    //   331: bipush #-2
    //   333: istore_3
    //   334: aload_1
    //   335: iconst_0
    //   336: putfield n : Z
    //   339: new android/view/WindowManager$LayoutParams
    //   342: dup
    //   343: iload_3
    //   344: bipush #-2
    //   346: aload_1
    //   347: getfield d : I
    //   350: aload_1
    //   351: getfield e : I
    //   354: sipush #1002
    //   357: ldc_w 8519680
    //   360: bipush #-3
    //   362: invokespecial <init> : (IIIIIII)V
    //   365: astore_2
    //   366: aload_2
    //   367: aload_1
    //   368: getfield c : I
    //   371: putfield gravity : I
    //   374: aload_2
    //   375: aload_1
    //   376: getfield f : I
    //   379: putfield windowAnimations : I
    //   382: aload #5
    //   384: aload_1
    //   385: getfield g : Landroid/view/ViewGroup;
    //   388: aload_2
    //   389: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   394: aload_1
    //   395: iconst_1
    //   396: putfield o : Z
    //   399: aload_1
    //   400: getfield a : I
    //   403: ifne -> 410
    //   406: aload_0
    //   407: invokevirtual d1 : ()V
    //   410: return
    //   411: aload_1
    //   412: iconst_1
    //   413: putfield q : Z
    //   416: return
  }
  
  private boolean P0(u paramu, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: istore #5
    //   6: iconst_0
    //   7: istore #6
    //   9: iload #5
    //   11: ifeq -> 16
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getfield m : Z
    //   20: ifne -> 36
    //   23: iload #6
    //   25: istore #5
    //   27: aload_0
    //   28: aload_1
    //   29: aload_3
    //   30: invokespecial Q0 : (Landroidx/appcompat/app/i$u;Landroid/view/KeyEvent;)Z
    //   33: ifeq -> 62
    //   36: aload_1
    //   37: getfield j : Landroidx/appcompat/view/menu/g;
    //   40: astore #7
    //   42: iload #6
    //   44: istore #5
    //   46: aload #7
    //   48: ifnull -> 62
    //   51: aload #7
    //   53: iload_2
    //   54: aload_3
    //   55: iload #4
    //   57: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   60: istore #5
    //   62: iload #5
    //   64: ifeq -> 87
    //   67: iload #4
    //   69: iconst_1
    //   70: iand
    //   71: ifne -> 87
    //   74: aload_0
    //   75: getfield x : Landroidx/appcompat/widget/r1;
    //   78: ifnonnull -> 87
    //   81: aload_0
    //   82: aload_1
    //   83: iconst_1
    //   84: invokevirtual d0 : (Landroidx/appcompat/app/i$u;Z)V
    //   87: iload #5
    //   89: ireturn
  }
  
  private boolean Q0(u paramu, KeyEvent paramKeyEvent) {
    r1 r11;
    if (this.X)
      return false; 
    if (paramu.m)
      return true; 
    u u1 = this.T;
    if (u1 != null && u1 != paramu)
      d0(u1, false); 
    Window.Callback callback = w0();
    if (callback != null)
      paramu.i = callback.onCreatePanelView(paramu.a); 
    int j = paramu.a;
    if (j == 0 || j == 108) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j != 0) {
      r1 r12 = this.x;
      if (r12 != null)
        r12.c(); 
    } 
    if (paramu.i == null && (j == 0 || !(O0() instanceof b0))) {
      r1 r12;
      boolean bool;
      g g1 = paramu.j;
      if (g1 == null || paramu.r) {
        if (g1 == null && (!A0(paramu) || paramu.j == null))
          return false; 
        if (j != 0 && this.x != null) {
          if (this.y == null)
            this.y = new h(this); 
          this.x.a((Menu)paramu.j, this.y);
        } 
        paramu.j.d0();
        if (!callback.onCreatePanelMenu(paramu.a, (Menu)paramu.j)) {
          paramu.c(null);
          if (j != 0) {
            r11 = this.x;
            if (r11 != null)
              r11.a(null, this.y); 
          } 
          return false;
        } 
        ((u)r11).r = false;
      } 
      ((u)r11).j.d0();
      Bundle bundle = ((u)r11).s;
      if (bundle != null) {
        ((u)r11).j.P(bundle);
        ((u)r11).s = null;
      } 
      if (!callback.onPreparePanel(0, ((u)r11).i, (Menu)((u)r11).j)) {
        if (j != 0) {
          r12 = this.x;
          if (r12 != null)
            r12.a(null, this.y); 
        } 
        ((u)r11).j.c0();
        return false;
      } 
      if (r12 != null) {
        j = r12.getDeviceId();
      } else {
        j = -1;
      } 
      if (KeyCharacterMap.load(j).getKeyboardType() != 1) {
        bool = true;
      } else {
        bool = false;
      } 
      ((u)r11).p = bool;
      ((u)r11).j.setQwertyMode(bool);
      ((u)r11).j.c0();
    } 
    ((u)r11).m = true;
    ((u)r11).n = false;
    this.T = (u)r11;
    return true;
  }
  
  private void R0(boolean paramBoolean) {
    r1 r11 = this.x;
    if (r11 != null && r11.d() && (!ViewConfiguration.get(this.q).hasPermanentMenuKey() || this.x.e())) {
      Window.Callback callback = w0();
      if (!this.x.b() || !paramBoolean) {
        if (callback != null && !this.X) {
          if (this.f0 && (this.g0 & 0x1) != 0) {
            this.r.getDecorView().removeCallbacks(this.h0);
            this.h0.run();
          } 
          u u2 = u0(0, true);
          g g1 = u2.j;
          if (g1 != null && !u2.r && callback.onPreparePanel(0, u2.i, (Menu)g1)) {
            callback.onMenuOpened(108, (Menu)u2.j);
            this.x.g();
          } 
        } 
        return;
      } 
      this.x.f();
      if (!this.X) {
        callback.onPanelClosed(108, (Menu)(u0(0, true)).j);
        return;
      } 
      return;
    } 
    u u1 = u0(0, true);
    u1.q = true;
    d0(u1, false);
    N0(u1, null);
  }
  
  private boolean S(boolean paramBoolean) {
    return T(paramBoolean, true);
  }
  
  private int S0(int paramInt) {
    if (paramInt == 8)
      return 108; 
    int j = paramInt;
    if (paramInt == 9)
      j = 109; 
    return j;
  }
  
  private boolean T(boolean paramBoolean1, boolean paramBoolean2) {
    androidx.core.os.g g1;
    if (this.X)
      return false; 
    int j = Y();
    int k = D0(this.q, j);
    if (Build.VERSION.SDK_INT < 33) {
      g1 = X(this.q);
    } else {
      g1 = null;
    } 
    androidx.core.os.g g2 = g1;
    if (!paramBoolean2) {
      g2 = g1;
      if (g1 != null)
        g2 = t0(this.q.getResources().getConfiguration()); 
    } 
    paramBoolean1 = c1(k, g2, paramBoolean1);
    if (j == 0) {
      s0(this.q).e();
    } else {
      q q2 = this.d0;
      if (q2 != null)
        q2.a(); 
    } 
    if (j == 3) {
      r0(this.q).e();
      return paramBoolean1;
    } 
    q q1 = this.e0;
    if (q1 != null)
      q1.a(); 
    return paramBoolean1;
  }
  
  private void V() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.H.findViewById(16908290);
    View view = this.r.getDecorView();
    contentFrameLayout.a(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.q.obtainStyledAttributes(f.j.y0);
    typedArray.getValue(f.j.K0, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(f.j.L0, contentFrameLayout.getMinWidthMinor());
    int j = f.j.I0;
    if (typedArray.hasValue(j))
      typedArray.getValue(j, contentFrameLayout.getFixedWidthMajor()); 
    j = f.j.J0;
    if (typedArray.hasValue(j))
      typedArray.getValue(j, contentFrameLayout.getFixedWidthMinor()); 
    j = f.j.G0;
    if (typedArray.hasValue(j))
      typedArray.getValue(j, contentFrameLayout.getFixedHeightMajor()); 
    j = f.j.H0;
    if (typedArray.hasValue(j))
      typedArray.getValue(j, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private void W(Window paramWindow) {
    if (this.r == null) {
      Window.Callback callback = paramWindow.getCallback();
      if (!(callback instanceof o)) {
        o o1 = new o(this, callback);
        this.s = o1;
        paramWindow.setCallback((Window.Callback)o1);
        x2 x2 = x2.u(this.q, null, r0);
        Drawable drawable = x2.h(0);
        if (drawable != null)
          paramWindow.setBackgroundDrawable(drawable); 
        x2.w();
        this.r = paramWindow;
        if (Build.VERSION.SDK_INT >= 33 && this.n0 == null)
          M(null); 
        return;
      } 
      throw new IllegalStateException("AppCompat has already installed itself into the Window");
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  private boolean W0(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.r.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (e1.Z((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private int Y() {
    int j = this.Z;
    return (j != -100) ? j : h.m();
  }
  
  private void Z0() {
    if (!this.G)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  private d a1() {
    Context context = this.q;
    while (context != null) {
      if (context instanceof d)
        return (d)context; 
      if (context instanceof ContextWrapper)
        context = ((ContextWrapper)context).getBaseContext(); 
    } 
    return null;
  }
  
  private void b0() {
    q q1 = this.d0;
    if (q1 != null)
      q1.a(); 
    q1 = this.e0;
    if (q1 != null)
      q1.a(); 
  }
  
  private void b1(Configuration paramConfiguration) {
    Activity activity = (Activity)this.p;
    if (activity instanceof LifecycleOwner) {
      if (((LifecycleOwner)activity).getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.CREATED)) {
        activity.onConfigurationChanged(paramConfiguration);
        return;
      } 
    } else if (this.W && !this.X) {
      activity.onConfigurationChanged(paramConfiguration);
    } 
  }
  
  private boolean c1(int paramInt, androidx.core.os.g paramg, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: aload_0
    //   2: getfield q : Landroid/content/Context;
    //   5: iload_1
    //   6: aload_2
    //   7: aconst_null
    //   8: iconst_0
    //   9: invokespecial e0 : (Landroid/content/Context;ILandroidx/core/os/g;Landroid/content/res/Configuration;Z)Landroid/content/res/Configuration;
    //   12: astore #12
    //   14: aload_0
    //   15: aload_0
    //   16: getfield q : Landroid/content/Context;
    //   19: invokespecial q0 : (Landroid/content/Context;)I
    //   22: istore #6
    //   24: aload_0
    //   25: getfield Y : Landroid/content/res/Configuration;
    //   28: astore #11
    //   30: aload #11
    //   32: astore #10
    //   34: aload #11
    //   36: ifnonnull -> 51
    //   39: aload_0
    //   40: getfield q : Landroid/content/Context;
    //   43: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   46: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   49: astore #10
    //   51: aload #10
    //   53: getfield uiMode : I
    //   56: istore #4
    //   58: aload #12
    //   60: getfield uiMode : I
    //   63: bipush #48
    //   65: iand
    //   66: istore #7
    //   68: aload_0
    //   69: aload #10
    //   71: invokevirtual t0 : (Landroid/content/res/Configuration;)Landroidx/core/os/g;
    //   74: astore #11
    //   76: aload_2
    //   77: ifnonnull -> 86
    //   80: aconst_null
    //   81: astore #10
    //   83: goto -> 94
    //   86: aload_0
    //   87: aload #12
    //   89: invokevirtual t0 : (Landroid/content/res/Configuration;)Landroidx/core/os/g;
    //   92: astore #10
    //   94: iconst_0
    //   95: istore #9
    //   97: iload #4
    //   99: bipush #48
    //   101: iand
    //   102: iload #7
    //   104: if_icmpeq -> 115
    //   107: sipush #512
    //   110: istore #4
    //   112: goto -> 118
    //   115: iconst_0
    //   116: istore #4
    //   118: iload #4
    //   120: istore #5
    //   122: aload #10
    //   124: ifnull -> 151
    //   127: iload #4
    //   129: istore #5
    //   131: aload #11
    //   133: aload #10
    //   135: invokevirtual equals : (Ljava/lang/Object;)Z
    //   138: ifne -> 151
    //   141: iload #4
    //   143: iconst_4
    //   144: ior
    //   145: sipush #8192
    //   148: ior
    //   149: istore #5
    //   151: iconst_1
    //   152: istore #8
    //   154: iload #6
    //   156: iload #5
    //   158: iand
    //   159: ifeq -> 226
    //   162: iload_3
    //   163: ifeq -> 226
    //   166: aload_0
    //   167: getfield V : Z
    //   170: ifeq -> 226
    //   173: getstatic androidx/appcompat/app/i.s0 : Z
    //   176: ifne -> 186
    //   179: aload_0
    //   180: getfield W : Z
    //   183: ifeq -> 226
    //   186: aload_0
    //   187: getfield p : Ljava/lang/Object;
    //   190: astore #11
    //   192: aload #11
    //   194: instanceof android/app/Activity
    //   197: ifeq -> 226
    //   200: aload #11
    //   202: checkcast android/app/Activity
    //   205: invokevirtual isChild : ()Z
    //   208: ifne -> 226
    //   211: aload_0
    //   212: getfield p : Ljava/lang/Object;
    //   215: checkcast android/app/Activity
    //   218: invokestatic r : (Landroid/app/Activity;)V
    //   221: iconst_1
    //   222: istore_3
    //   223: goto -> 228
    //   226: iconst_0
    //   227: istore_3
    //   228: iload_3
    //   229: ifne -> 268
    //   232: iload #5
    //   234: ifeq -> 268
    //   237: iload #9
    //   239: istore_3
    //   240: iload #5
    //   242: iload #6
    //   244: iand
    //   245: iload #5
    //   247: if_icmpne -> 252
    //   250: iconst_1
    //   251: istore_3
    //   252: aload_0
    //   253: iload #7
    //   255: aload #10
    //   257: iload_3
    //   258: aconst_null
    //   259: invokespecial e1 : (ILandroidx/core/os/g;ZLandroid/content/res/Configuration;)V
    //   262: iload #8
    //   264: istore_3
    //   265: goto -> 268
    //   268: iload_3
    //   269: ifeq -> 322
    //   272: aload_0
    //   273: getfield p : Ljava/lang/Object;
    //   276: astore #11
    //   278: aload #11
    //   280: instanceof androidx/appcompat/app/d
    //   283: ifeq -> 322
    //   286: iload #5
    //   288: sipush #512
    //   291: iand
    //   292: ifeq -> 304
    //   295: aload #11
    //   297: checkcast androidx/appcompat/app/d
    //   300: iload_1
    //   301: invokevirtual onNightModeChanged : (I)V
    //   304: iload #5
    //   306: iconst_4
    //   307: iand
    //   308: ifeq -> 322
    //   311: aload_0
    //   312: getfield p : Ljava/lang/Object;
    //   315: checkcast androidx/appcompat/app/d
    //   318: aload_2
    //   319: invokevirtual onLocalesChanged : (Landroidx/core/os/g;)V
    //   322: iload_3
    //   323: ifeq -> 349
    //   326: aload #10
    //   328: ifnull -> 349
    //   331: aload_0
    //   332: aload_0
    //   333: aload_0
    //   334: getfield q : Landroid/content/Context;
    //   337: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   340: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   343: invokevirtual t0 : (Landroid/content/res/Configuration;)Landroidx/core/os/g;
    //   346: invokevirtual U0 : (Landroidx/core/os/g;)V
    //   349: iload_3
    //   350: ireturn
  }
  
  private Configuration e0(Context paramContext, int paramInt, androidx.core.os.g paramg, Configuration paramConfiguration, boolean paramBoolean) {
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramBoolean) {
          paramInt = 0;
        } else {
          paramInt = (paramContext.getApplicationContext().getResources().getConfiguration()).uiMode & 0x30;
        } 
      } else {
        paramInt = 32;
      } 
    } else {
      paramInt = 16;
    } 
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration != null)
      configuration.setTo(paramConfiguration); 
    configuration.uiMode = paramInt | configuration.uiMode & 0xFFFFFFCF;
    if (paramg != null)
      T0(configuration, paramg); 
    return configuration;
  }
  
  private void e1(int paramInt, androidx.core.os.g paramg, boolean paramBoolean, Configuration paramConfiguration) {
    Resources resources = this.q.getResources();
    Configuration configuration = new Configuration(resources.getConfiguration());
    if (paramConfiguration != null)
      configuration.updateFrom(paramConfiguration); 
    configuration.uiMode = paramInt | (resources.getConfiguration()).uiMode & 0xFFFFFFCF;
    if (paramg != null)
      T0(configuration, paramg); 
    resources.updateConfiguration(configuration, null);
    paramInt = Build.VERSION.SDK_INT;
    if (paramInt < 26)
      a0.a(resources); 
    int j = this.a0;
    if (j != 0) {
      this.q.setTheme(j);
      if (paramInt >= 23)
        this.q.getTheme().applyStyle(this.a0, true); 
    } 
    if (paramBoolean && this.p instanceof Activity)
      b1(configuration); 
  }
  
  private ViewGroup f0() {
    StringBuilder stringBuilder;
    TypedArray typedArray = this.q.obtainStyledAttributes(f.j.y0);
    int j = f.j.D0;
    if (typedArray.hasValue(j)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(f.j.M0, false)) {
        H(1);
      } else if (typedArray.getBoolean(j, false)) {
        H(108);
      } 
      if (typedArray.getBoolean(f.j.E0, false))
        H(109); 
      if (typedArray.getBoolean(f.j.F0, false))
        H(10); 
      this.P = typedArray.getBoolean(f.j.z0, false);
      typedArray.recycle();
      m0();
      this.r.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.q);
      if (!this.Q) {
        if (this.P) {
          viewGroup = (ViewGroup)layoutInflater.inflate(f.g.f, null);
          this.N = false;
          this.M = false;
        } else if (this.M) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.q.getTheme().resolveAttribute(f.a.f, typedValue, true);
          if (typedValue.resourceId != 0) {
            androidx.appcompat.view.d d = new androidx.appcompat.view.d(this.q, typedValue.resourceId);
          } else {
            context = this.q;
          } 
          ViewGroup viewGroup1 = (ViewGroup)LayoutInflater.from(context).inflate(f.g.p, null);
          r1 r11 = (r1)viewGroup1.findViewById(f.f.p);
          this.x = r11;
          r11.setWindowCallback(w0());
          if (this.N)
            this.x.h(109); 
          if (this.K)
            this.x.h(2); 
          viewGroup = viewGroup1;
          if (this.L) {
            this.x.h(5);
            viewGroup = viewGroup1;
          } 
        } else {
          layoutInflater = null;
        } 
      } else if (this.O) {
        viewGroup = (ViewGroup)layoutInflater.inflate(f.g.o, null);
      } else {
        viewGroup = (ViewGroup)viewGroup.inflate(f.g.n, null);
      } 
      if (viewGroup != null) {
        e1.O0((View)viewGroup, new b(this));
        if (this.x == null)
          this.I = (TextView)viewGroup.findViewById(f.f.M); 
        i3.c((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(f.f.b);
        ViewGroup viewGroup1 = (ViewGroup)this.r.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.r.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new c(this));
        return viewGroup;
      } 
      stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.M);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.N);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.P);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.O);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.Q);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    stringBuilder.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void g1(View paramView) {
    int j;
    if ((e1.S(paramView) & 0x2000) != 0) {
      j = 1;
    } else {
      j = 0;
    } 
    if (j) {
      j = androidx.core.content.a.c(this.q, f.c.b);
    } else {
      j = androidx.core.content.a.c(this.q, f.c.a);
    } 
    paramView.setBackgroundColor(j);
  }
  
  private void l0() {
    if (!this.G) {
      this.H = f0();
      CharSequence charSequence = v0();
      if (!TextUtils.isEmpty(charSequence)) {
        r1 r11 = this.x;
        if (r11 != null) {
          r11.setWindowTitle(charSequence);
        } else if (O0() != null) {
          O0().u(charSequence);
        } else {
          TextView textView = this.I;
          if (textView != null)
            textView.setText(charSequence); 
        } 
      } 
      V();
      M0(this.H);
      this.G = true;
      u u1 = u0(0, false);
      if (!this.X && (u1 == null || u1.j == null))
        B0(108); 
    } 
  }
  
  private void m0() {
    if (this.r == null) {
      Object object = this.p;
      if (object instanceof Activity)
        W(((Activity)object).getWindow()); 
    } 
    if (this.r != null)
      return; 
    throw new IllegalStateException("We have not been given a Window");
  }
  
  private static Configuration o0(Configuration paramConfiguration1, Configuration paramConfiguration2) {
    Configuration configuration = new Configuration();
    configuration.fontScale = 0.0F;
    if (paramConfiguration2 != null) {
      if (paramConfiguration1.diff(paramConfiguration2) == 0)
        return configuration; 
      float f1 = paramConfiguration1.fontScale;
      float f2 = paramConfiguration2.fontScale;
      if (f1 != f2)
        configuration.fontScale = f2; 
      int j = paramConfiguration1.mcc;
      int k = paramConfiguration2.mcc;
      if (j != k)
        configuration.mcc = k; 
      j = paramConfiguration1.mnc;
      k = paramConfiguration2.mnc;
      if (j != k)
        configuration.mnc = k; 
      j = Build.VERSION.SDK_INT;
      if (j >= 24) {
        l.a(paramConfiguration1, paramConfiguration2, configuration);
      } else if (!androidx.core.util.c.a(paramConfiguration1.locale, paramConfiguration2.locale)) {
        configuration.locale = paramConfiguration2.locale;
      } 
      k = paramConfiguration1.touchscreen;
      int m = paramConfiguration2.touchscreen;
      if (k != m)
        configuration.touchscreen = m; 
      k = paramConfiguration1.keyboard;
      m = paramConfiguration2.keyboard;
      if (k != m)
        configuration.keyboard = m; 
      k = paramConfiguration1.keyboardHidden;
      m = paramConfiguration2.keyboardHidden;
      if (k != m)
        configuration.keyboardHidden = m; 
      k = paramConfiguration1.navigation;
      m = paramConfiguration2.navigation;
      if (k != m)
        configuration.navigation = m; 
      k = paramConfiguration1.navigationHidden;
      m = paramConfiguration2.navigationHidden;
      if (k != m)
        configuration.navigationHidden = m; 
      k = paramConfiguration1.orientation;
      m = paramConfiguration2.orientation;
      if (k != m)
        configuration.orientation = m; 
      k = paramConfiguration1.screenLayout;
      m = paramConfiguration2.screenLayout;
      if ((k & 0xF) != (m & 0xF))
        configuration.screenLayout |= m & 0xF; 
      k = paramConfiguration1.screenLayout;
      m = paramConfiguration2.screenLayout;
      if ((k & 0xC0) != (m & 0xC0))
        configuration.screenLayout |= m & 0xC0; 
      k = paramConfiguration1.screenLayout;
      m = paramConfiguration2.screenLayout;
      if ((k & 0x30) != (m & 0x30))
        configuration.screenLayout |= m & 0x30; 
      k = paramConfiguration1.screenLayout;
      m = paramConfiguration2.screenLayout;
      if ((k & 0x300) != (m & 0x300))
        configuration.screenLayout |= m & 0x300; 
      if (j >= 26)
        m.a(paramConfiguration1, paramConfiguration2, configuration); 
      j = paramConfiguration1.uiMode;
      k = paramConfiguration2.uiMode;
      if ((j & 0xF) != (k & 0xF))
        configuration.uiMode |= k & 0xF; 
      j = paramConfiguration1.uiMode;
      k = paramConfiguration2.uiMode;
      if ((j & 0x30) != (k & 0x30))
        configuration.uiMode |= k & 0x30; 
      j = paramConfiguration1.screenWidthDp;
      k = paramConfiguration2.screenWidthDp;
      if (j != k)
        configuration.screenWidthDp = k; 
      j = paramConfiguration1.screenHeightDp;
      k = paramConfiguration2.screenHeightDp;
      if (j != k)
        configuration.screenHeightDp = k; 
      j = paramConfiguration1.smallestScreenWidthDp;
      k = paramConfiguration2.smallestScreenWidthDp;
      if (j != k)
        configuration.smallestScreenWidthDp = k; 
      j.b(paramConfiguration1, paramConfiguration2, configuration);
    } 
    return configuration;
  }
  
  private int q0(Context paramContext) {
    if (!this.c0 && this.p instanceof Activity) {
      PackageManager packageManager = paramContext.getPackageManager();
      if (packageManager == null)
        return 0; 
      try {
        int j = Build.VERSION.SDK_INT;
        if (j >= 29) {
          j = 269221888;
        } else if (j >= 24) {
          j = 786432;
        } else {
          j = 0;
        } 
        ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(paramContext, this.p.getClass()), j);
        if (activityInfo != null)
          this.b0 = activityInfo.configChanges; 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        this.b0 = 0;
      } 
    } 
    this.c0 = true;
    return this.b0;
  }
  
  private q r0(Context paramContext) {
    if (this.e0 == null)
      this.e0 = new p(this, paramContext); 
    return this.e0;
  }
  
  private q s0(Context paramContext) {
    if (this.d0 == null)
      this.d0 = new r(this, d0.a(paramContext)); 
    return this.d0;
  }
  
  private void x0() {
    l0();
    if (this.M) {
      if (this.u != null)
        return; 
      Object object = this.p;
      if (object instanceof Activity) {
        this.u = new e0((Activity)this.p, this.N);
      } else if (object instanceof Dialog) {
        this.u = new e0((Dialog)this.p);
      } 
      object = this.u;
      if (object != null)
        object.r(this.i0); 
    } 
  }
  
  private boolean y0(u paramu) {
    View view = paramu.i;
    if (view != null) {
      paramu.h = view;
      return true;
    } 
    if (paramu.j == null)
      return false; 
    if (this.z == null)
      this.z = new v(this); 
    view = (View)paramu.a(this.z);
    paramu.h = view;
    return (view != null);
  }
  
  private boolean z0(u paramu) {
    paramu.d(p0());
    paramu.g = (ViewGroup)new t(this, paramu.l);
    paramu.c = 81;
    return true;
  }
  
  public void A(Bundle paramBundle) {
    l0();
  }
  
  public void B() {
    a a1 = s();
    if (a1 != null)
      a1.t(true); 
  }
  
  public void C(Bundle paramBundle) {}
  
  public boolean C0() {
    return this.F;
  }
  
  public void D() {
    T(true, false);
  }
  
  int D0(Context paramContext, int paramInt) {
    if (paramInt != -100) {
      if (paramInt != -1)
        if (paramInt != 0) {
          if (paramInt != 1 && paramInt != 2) {
            if (paramInt == 3)
              return r0(paramContext).c(); 
            throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
          } 
        } else {
          return (Build.VERSION.SDK_INT >= 23 && ((UiModeManager)paramContext.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) ? -1 : s0(paramContext).c();
        }  
      return paramInt;
    } 
    return -1;
  }
  
  public void E() {
    a a1 = s();
    if (a1 != null)
      a1.t(false); 
  }
  
  boolean E0() {
    boolean bool = this.U;
    this.U = false;
    u u1 = u0(0, false);
    if (u1 != null && u1.o) {
      if (!bool)
        d0(u1, true); 
      return true;
    } 
    androidx.appcompat.view.b b1 = this.A;
    if (b1 != null) {
      b1.c();
      return true;
    } 
    a a1 = s();
    return (a1 != null && a1.h());
  }
  
  boolean F0(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      G0(0, paramKeyEvent);
      return true;
    } 
    if ((paramKeyEvent.getFlags() & 0x80) == 0)
      bool = false; 
    this.U = bool;
    return false;
  }
  
  public boolean H(int paramInt) {
    paramInt = S0(paramInt);
    if (this.Q && paramInt == 108)
      return false; 
    if (this.M && paramInt == 1)
      this.M = false; 
    if (paramInt != 1) {
      if (paramInt != 2) {
        if (paramInt != 5) {
          if (paramInt != 10) {
            if (paramInt != 108) {
              if (paramInt != 109)
                return this.r.requestFeature(paramInt); 
              Z0();
              this.N = true;
              return true;
            } 
            Z0();
            this.M = true;
            return true;
          } 
          Z0();
          this.O = true;
          return true;
        } 
        Z0();
        this.L = true;
        return true;
      } 
      Z0();
      this.K = true;
      return true;
    } 
    Z0();
    this.Q = true;
    return true;
  }
  
  boolean H0(int paramInt, KeyEvent paramKeyEvent) {
    u u1;
    a a1 = s();
    if (a1 != null && a1.o(paramInt, paramKeyEvent))
      return true; 
    u u2 = this.T;
    if (u2 != null && P0(u2, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      u1 = this.T;
      if (u1 != null)
        u1.n = true; 
      return true;
    } 
    if (this.T == null) {
      u2 = u0(0, true);
      Q0(u2, (KeyEvent)u1);
      boolean bool = P0(u2, u1.getKeyCode(), (KeyEvent)u1, 1);
      u2.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  boolean I0(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      J0(0, paramKeyEvent);
      return true;
    } 
    return E0();
  }
  
  public void J(int paramInt) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.H.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.q).inflate(paramInt, viewGroup);
    this.s.c(this.r.getCallback());
  }
  
  public void K(View paramView) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.H.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.s.c(this.r.getCallback());
  }
  
  void K0(int paramInt) {
    if (paramInt == 108) {
      a a1 = s();
      if (a1 != null)
        a1.i(true); 
    } 
  }
  
  public void L(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    l0();
    ViewGroup viewGroup = (ViewGroup)this.H.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.s.c(this.r.getCallback());
  }
  
  void L0(int paramInt) {
    if (paramInt == 108) {
      a a1 = s();
      if (a1 != null) {
        a1.i(false);
        return;
      } 
    } else if (paramInt == 0) {
      u u1 = u0(paramInt, true);
      if (u1.o)
        d0(u1, false); 
    } 
  }
  
  public void M(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial M : (Landroid/window/OnBackInvokedDispatcher;)V
    //   5: aload_0
    //   6: getfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   9: astore_2
    //   10: aload_2
    //   11: ifnull -> 33
    //   14: aload_0
    //   15: getfield o0 : Landroid/window/OnBackInvokedCallback;
    //   18: astore_3
    //   19: aload_3
    //   20: ifnull -> 33
    //   23: aload_2
    //   24: aload_3
    //   25: invokestatic c : (Ljava/lang/Object;Ljava/lang/Object;)V
    //   28: aload_0
    //   29: aconst_null
    //   30: putfield o0 : Landroid/window/OnBackInvokedCallback;
    //   33: aload_1
    //   34: ifnonnull -> 76
    //   37: aload_0
    //   38: getfield p : Ljava/lang/Object;
    //   41: astore_2
    //   42: aload_2
    //   43: instanceof android/app/Activity
    //   46: ifeq -> 76
    //   49: aload_2
    //   50: checkcast android/app/Activity
    //   53: invokevirtual getWindow : ()Landroid/view/Window;
    //   56: ifnull -> 76
    //   59: aload_0
    //   60: aload_0
    //   61: getfield p : Ljava/lang/Object;
    //   64: checkcast android/app/Activity
    //   67: invokestatic a : (Landroid/app/Activity;)Landroid/window/OnBackInvokedDispatcher;
    //   70: putfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   73: goto -> 81
    //   76: aload_0
    //   77: aload_1
    //   78: putfield n0 : Landroid/window/OnBackInvokedDispatcher;
    //   81: aload_0
    //   82: invokevirtual d1 : ()V
    //   85: return
  }
  
  void M0(ViewGroup paramViewGroup) {}
  
  public void N(Toolbar paramToolbar) {
    if (!(this.p instanceof Activity))
      return; 
    a a1 = s();
    if (!(a1 instanceof e0)) {
      this.v = null;
      if (a1 != null)
        a1.n(); 
      this.u = null;
      if (paramToolbar != null) {
        a1 = new b0(paramToolbar, v0(), (Window.Callback)this.s);
        this.u = a1;
        this.s.e(((b0)a1).c);
        paramToolbar.setBackInvokedCallbackEnabled(true);
      } else {
        this.s.e(null);
      } 
      u();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public void O(int paramInt) {
    this.a0 = paramInt;
  }
  
  final a O0() {
    return this.u;
  }
  
  public final void P(CharSequence paramCharSequence) {
    this.w = paramCharSequence;
    r1 r11 = this.x;
    if (r11 != null) {
      r11.setWindowTitle(paramCharSequence);
      return;
    } 
    if (O0() != null) {
      O0().u(paramCharSequence);
      return;
    } 
    TextView textView = this.I;
    if (textView != null)
      textView.setText(paramCharSequence); 
  }
  
  public androidx.appcompat.view.b Q(androidx.appcompat.view.b.a parama) {
    if (parama != null) {
      androidx.appcompat.view.b b1 = this.A;
      if (b1 != null)
        b1.c(); 
      parama = new i(this, parama);
      a a1 = s();
      if (a1 != null) {
        androidx.appcompat.view.b b2 = a1.v(parama);
        this.A = b2;
        if (b2 != null) {
          e e1 = this.t;
          if (e1 != null)
            e1.onSupportActionModeStarted(b2); 
        } 
      } 
      if (this.A == null)
        this.A = Y0(parama); 
      d1();
      return this.A;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  void T0(Configuration paramConfiguration, androidx.core.os.g paramg) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.d(paramConfiguration, paramg);
      return;
    } 
    j.d(paramConfiguration, paramg.d(0));
    j.c(paramConfiguration, paramg.d(0));
  }
  
  public boolean U() {
    return S(true);
  }
  
  void U0(androidx.core.os.g paramg) {
    if (Build.VERSION.SDK_INT >= 24) {
      l.c(paramg);
      return;
    } 
    Locale.setDefault(paramg.d(0));
  }
  
  final boolean V0() {
    if (this.G) {
      ViewGroup viewGroup = this.H;
      if (viewGroup != null && e1.a0((View)viewGroup))
        return true; 
    } 
    return false;
  }
  
  androidx.core.os.g X(Context paramContext) {
    androidx.core.os.g g1;
    int j = Build.VERSION.SDK_INT;
    if (j >= 33)
      return null; 
    androidx.core.os.g g3 = h.r();
    if (g3 == null)
      return null; 
    androidx.core.os.g g2 = t0(paramContext.getApplicationContext().getResources().getConfiguration());
    if (j >= 24) {
      g1 = z.b(g3, g2);
    } else if (g3.f()) {
      g1 = androidx.core.os.g.e();
    } else {
      g1 = androidx.core.os.g.c(g3.d(0).toString());
    } 
    return g1.f() ? g2 : g1;
  }
  
  boolean X0() {
    if (this.n0 == null)
      return false; 
    u u1 = u0(0, false);
    return (u1 != null && u1.o) ? true : ((this.A != null));
  }
  
  androidx.appcompat.view.b Y0(androidx.appcompat.view.b.a parama) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual k0 : ()V
    //   4: aload_0
    //   5: getfield A : Landroidx/appcompat/view/b;
    //   8: astore #4
    //   10: aload #4
    //   12: ifnull -> 20
    //   15: aload #4
    //   17: invokevirtual c : ()V
    //   20: aload_1
    //   21: astore #4
    //   23: aload_1
    //   24: instanceof androidx/appcompat/app/i$i
    //   27: ifne -> 41
    //   30: new androidx/appcompat/app/i$i
    //   33: dup
    //   34: aload_0
    //   35: aload_1
    //   36: invokespecial <init> : (Landroidx/appcompat/app/i;Landroidx/appcompat/view/b$a;)V
    //   39: astore #4
    //   41: aload_0
    //   42: getfield t : Landroidx/appcompat/app/e;
    //   45: astore_1
    //   46: aload_1
    //   47: ifnull -> 69
    //   50: aload_0
    //   51: getfield X : Z
    //   54: ifne -> 69
    //   57: aload_1
    //   58: aload #4
    //   60: invokeinterface onWindowStartingSupportActionMode : (Landroidx/appcompat/view/b$a;)Landroidx/appcompat/view/b;
    //   65: astore_1
    //   66: goto -> 71
    //   69: aconst_null
    //   70: astore_1
    //   71: aload_1
    //   72: ifnull -> 83
    //   75: aload_0
    //   76: aload_1
    //   77: putfield A : Landroidx/appcompat/view/b;
    //   80: goto -> 565
    //   83: aload_0
    //   84: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   87: astore_1
    //   88: iconst_1
    //   89: istore_3
    //   90: aload_1
    //   91: ifnonnull -> 355
    //   94: aload_0
    //   95: getfield P : Z
    //   98: ifeq -> 315
    //   101: new android/util/TypedValue
    //   104: dup
    //   105: invokespecial <init> : ()V
    //   108: astore #5
    //   110: aload_0
    //   111: getfield q : Landroid/content/Context;
    //   114: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   117: astore_1
    //   118: aload_1
    //   119: getstatic f/a.f : I
    //   122: aload #5
    //   124: iconst_1
    //   125: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   128: pop
    //   129: aload #5
    //   131: getfield resourceId : I
    //   134: ifeq -> 191
    //   137: aload_0
    //   138: getfield q : Landroid/content/Context;
    //   141: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   144: invokevirtual newTheme : ()Landroid/content/res/Resources$Theme;
    //   147: astore #6
    //   149: aload #6
    //   151: aload_1
    //   152: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   155: aload #6
    //   157: aload #5
    //   159: getfield resourceId : I
    //   162: iconst_1
    //   163: invokevirtual applyStyle : (IZ)V
    //   166: new androidx/appcompat/view/d
    //   169: dup
    //   170: aload_0
    //   171: getfield q : Landroid/content/Context;
    //   174: iconst_0
    //   175: invokespecial <init> : (Landroid/content/Context;I)V
    //   178: astore_1
    //   179: aload_1
    //   180: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   183: aload #6
    //   185: invokevirtual setTo : (Landroid/content/res/Resources$Theme;)V
    //   188: goto -> 196
    //   191: aload_0
    //   192: getfield q : Landroid/content/Context;
    //   195: astore_1
    //   196: aload_0
    //   197: new androidx/appcompat/widget/ActionBarContextView
    //   200: dup
    //   201: aload_1
    //   202: invokespecial <init> : (Landroid/content/Context;)V
    //   205: putfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   208: new android/widget/PopupWindow
    //   211: dup
    //   212: aload_1
    //   213: aconst_null
    //   214: getstatic f/a.i : I
    //   217: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;I)V
    //   220: astore #6
    //   222: aload_0
    //   223: aload #6
    //   225: putfield C : Landroid/widget/PopupWindow;
    //   228: aload #6
    //   230: iconst_2
    //   231: invokestatic b : (Landroid/widget/PopupWindow;I)V
    //   234: aload_0
    //   235: getfield C : Landroid/widget/PopupWindow;
    //   238: aload_0
    //   239: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   242: invokevirtual setContentView : (Landroid/view/View;)V
    //   245: aload_0
    //   246: getfield C : Landroid/widget/PopupWindow;
    //   249: iconst_m1
    //   250: invokevirtual setWidth : (I)V
    //   253: aload_1
    //   254: invokevirtual getTheme : ()Landroid/content/res/Resources$Theme;
    //   257: getstatic f/a.b : I
    //   260: aload #5
    //   262: iconst_1
    //   263: invokevirtual resolveAttribute : (ILandroid/util/TypedValue;Z)Z
    //   266: pop
    //   267: aload #5
    //   269: getfield data : I
    //   272: aload_1
    //   273: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   276: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   279: invokestatic complexToDimensionPixelSize : (ILandroid/util/DisplayMetrics;)I
    //   282: istore_2
    //   283: aload_0
    //   284: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   287: iload_2
    //   288: invokevirtual setContentHeight : (I)V
    //   291: aload_0
    //   292: getfield C : Landroid/widget/PopupWindow;
    //   295: bipush #-2
    //   297: invokevirtual setHeight : (I)V
    //   300: aload_0
    //   301: new androidx/appcompat/app/i$d
    //   304: dup
    //   305: aload_0
    //   306: invokespecial <init> : (Landroidx/appcompat/app/i;)V
    //   309: putfield D : Ljava/lang/Runnable;
    //   312: goto -> 355
    //   315: aload_0
    //   316: getfield H : Landroid/view/ViewGroup;
    //   319: getstatic f/f.h : I
    //   322: invokevirtual findViewById : (I)Landroid/view/View;
    //   325: checkcast androidx/appcompat/widget/ViewStubCompat
    //   328: astore_1
    //   329: aload_1
    //   330: ifnull -> 355
    //   333: aload_1
    //   334: aload_0
    //   335: invokevirtual p0 : ()Landroid/content/Context;
    //   338: invokestatic from : (Landroid/content/Context;)Landroid/view/LayoutInflater;
    //   341: invokevirtual setLayoutInflater : (Landroid/view/LayoutInflater;)V
    //   344: aload_0
    //   345: aload_1
    //   346: invokevirtual a : ()Landroid/view/View;
    //   349: checkcast androidx/appcompat/widget/ActionBarContextView
    //   352: putfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   355: aload_0
    //   356: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   359: ifnull -> 565
    //   362: aload_0
    //   363: invokevirtual k0 : ()V
    //   366: aload_0
    //   367: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   370: invokevirtual k : ()V
    //   373: aload_0
    //   374: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   377: invokevirtual getContext : ()Landroid/content/Context;
    //   380: astore_1
    //   381: aload_0
    //   382: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   385: astore #5
    //   387: aload_0
    //   388: getfield C : Landroid/widget/PopupWindow;
    //   391: ifnonnull -> 397
    //   394: goto -> 399
    //   397: iconst_0
    //   398: istore_3
    //   399: new androidx/appcompat/view/e
    //   402: dup
    //   403: aload_1
    //   404: aload #5
    //   406: aload #4
    //   408: iload_3
    //   409: invokespecial <init> : (Landroid/content/Context;Landroidx/appcompat/widget/ActionBarContextView;Landroidx/appcompat/view/b$a;Z)V
    //   412: astore_1
    //   413: aload #4
    //   415: aload_1
    //   416: aload_1
    //   417: invokevirtual e : ()Landroid/view/Menu;
    //   420: invokeinterface b : (Landroidx/appcompat/view/b;Landroid/view/Menu;)Z
    //   425: ifeq -> 560
    //   428: aload_1
    //   429: invokevirtual k : ()V
    //   432: aload_0
    //   433: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   436: aload_1
    //   437: invokevirtual h : (Landroidx/appcompat/view/b;)V
    //   440: aload_0
    //   441: aload_1
    //   442: putfield A : Landroidx/appcompat/view/b;
    //   445: aload_0
    //   446: invokevirtual V0 : ()Z
    //   449: ifeq -> 493
    //   452: aload_0
    //   453: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   456: fconst_0
    //   457: invokevirtual setAlpha : (F)V
    //   460: aload_0
    //   461: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   464: invokestatic e : (Landroid/view/View;)Landroidx/core/view/e3;
    //   467: fconst_1
    //   468: invokevirtual b : (F)Landroidx/core/view/e3;
    //   471: astore_1
    //   472: aload_0
    //   473: aload_1
    //   474: putfield E : Landroidx/core/view/e3;
    //   477: aload_1
    //   478: new androidx/appcompat/app/i$e
    //   481: dup
    //   482: aload_0
    //   483: invokespecial <init> : (Landroidx/appcompat/app/i;)V
    //   486: invokevirtual h : (Landroidx/core/view/f3;)Landroidx/core/view/e3;
    //   489: pop
    //   490: goto -> 535
    //   493: aload_0
    //   494: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   497: fconst_1
    //   498: invokevirtual setAlpha : (F)V
    //   501: aload_0
    //   502: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   505: iconst_0
    //   506: invokevirtual setVisibility : (I)V
    //   509: aload_0
    //   510: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   513: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   516: instanceof android/view/View
    //   519: ifeq -> 535
    //   522: aload_0
    //   523: getfield B : Landroidx/appcompat/widget/ActionBarContextView;
    //   526: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   529: checkcast android/view/View
    //   532: invokestatic t0 : (Landroid/view/View;)V
    //   535: aload_0
    //   536: getfield C : Landroid/widget/PopupWindow;
    //   539: ifnull -> 565
    //   542: aload_0
    //   543: getfield r : Landroid/view/Window;
    //   546: invokevirtual getDecorView : ()Landroid/view/View;
    //   549: aload_0
    //   550: getfield D : Ljava/lang/Runnable;
    //   553: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   556: pop
    //   557: goto -> 565
    //   560: aload_0
    //   561: aconst_null
    //   562: putfield A : Landroidx/appcompat/view/b;
    //   565: aload_0
    //   566: getfield A : Landroidx/appcompat/view/b;
    //   569: astore_1
    //   570: aload_1
    //   571: ifnull -> 593
    //   574: aload_0
    //   575: getfield t : Landroidx/appcompat/app/e;
    //   578: astore #4
    //   580: aload #4
    //   582: ifnull -> 593
    //   585: aload #4
    //   587: aload_1
    //   588: invokeinterface onSupportActionModeStarted : (Landroidx/appcompat/view/b;)V
    //   593: aload_0
    //   594: invokevirtual d1 : ()V
    //   597: aload_0
    //   598: getfield A : Landroidx/appcompat/view/b;
    //   601: areturn
    //   602: astore_1
    //   603: goto -> 69
    // Exception table:
    //   from	to	target	type
    //   57	66	602	java/lang/AbstractMethodError
  }
  
  void Z(int paramInt, u paramu, Menu paramMenu) {
    g g1;
    u u1 = paramu;
    Menu menu = paramMenu;
    if (paramMenu == null) {
      u u2 = paramu;
      if (paramu == null) {
        u2 = paramu;
        if (paramInt >= 0) {
          u[] arrayOfU = this.S;
          u2 = paramu;
          if (paramInt < arrayOfU.length)
            u2 = arrayOfU[paramInt]; 
        } 
      } 
      u1 = u2;
      menu = paramMenu;
      if (u2 != null) {
        g1 = u2.j;
        u1 = u2;
      } 
    } 
    if (u1 != null && !u1.o)
      return; 
    if (!this.X)
      this.s.d(this.r.getCallback(), paramInt, (Menu)g1); 
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    Window.Callback callback = w0();
    if (callback != null && !this.X) {
      u u1 = n0((Menu)paramg.D());
      if (u1 != null)
        return callback.onMenuItemSelected(u1.a, paramMenuItem); 
    } 
    return false;
  }
  
  void a0(g paramg) {
    if (this.R)
      return; 
    this.R = true;
    this.x.i();
    Window.Callback callback = w0();
    if (callback != null && !this.X)
      callback.onPanelClosed(108, (Menu)paramg); 
    this.R = false;
  }
  
  public void b(g paramg) {
    R0(true);
  }
  
  void c0(int paramInt) {
    d0(u0(paramInt, true), true);
  }
  
  void d0(u paramu, boolean paramBoolean) {
    if (paramBoolean && paramu.a == 0) {
      r1 r11 = this.x;
      if (r11 != null && r11.b()) {
        a0(paramu.j);
        return;
      } 
    } 
    WindowManager windowManager = (WindowManager)this.q.getSystemService("window");
    if (windowManager != null && paramu.o) {
      ViewGroup viewGroup = paramu.g;
      if (viewGroup != null) {
        windowManager.removeView((View)viewGroup);
        if (paramBoolean)
          Z(paramu.a, paramu, null); 
      } 
    } 
    paramu.m = false;
    paramu.n = false;
    paramu.o = false;
    paramu.h = null;
    paramu.q = true;
    if (this.T == paramu)
      this.T = null; 
    if (paramu.a == 0)
      d1(); 
  }
  
  void d1() {
    if (Build.VERSION.SDK_INT >= 33) {
      boolean bool = X0();
      if (bool && this.o0 == null) {
        this.o0 = n.b(this.n0, this);
        return;
      } 
      if (!bool) {
        OnBackInvokedCallback onBackInvokedCallback = this.o0;
        if (onBackInvokedCallback != null)
          n.c(this.n0, onBackInvokedCallback); 
      } 
    } 
  }
  
  public void e(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    l0();
    ((ViewGroup)this.H.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.s.c(this.r.getCallback());
  }
  
  final int f1(t3 paramt3, Rect paramRect) {
    int j;
    int k;
    boolean bool1;
    boolean bool2 = false;
    if (paramt3 != null) {
      j = paramt3.l();
    } else if (paramRect != null) {
      j = paramRect.top;
    } else {
      j = 0;
    } 
    ActionBarContextView actionBarContextView = this.B;
    if (actionBarContextView != null && actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.B.getLayoutParams();
      boolean bool3 = this.B.isShown();
      int m = 1;
      bool1 = true;
      if (bool3) {
        int n;
        if (this.j0 == null) {
          this.j0 = new Rect();
          this.k0 = new Rect();
        } 
        Rect rect1 = this.j0;
        Rect rect2 = this.k0;
        if (paramt3 == null) {
          rect1.set(paramRect);
        } else {
          rect1.set(paramt3.j(), paramt3.l(), paramt3.k(), paramt3.i());
        } 
        i3.a((View)this.H, rect1, rect2);
        int i1 = rect1.top;
        bool = rect1.left;
        int i2 = rect1.right;
        paramt3 = e1.O((View)this.H);
        if (paramt3 == null) {
          m = 0;
        } else {
          m = paramt3.j();
        } 
        if (paramt3 == null) {
          n = 0;
        } else {
          n = paramt3.k();
        } 
        if (marginLayoutParams.topMargin != i1 || marginLayoutParams.leftMargin != bool || marginLayoutParams.rightMargin != i2) {
          marginLayoutParams.topMargin = i1;
          marginLayoutParams.leftMargin = bool;
          marginLayoutParams.rightMargin = i2;
          bool = true;
        } else {
          bool = false;
        } 
        if (i1 > 0 && this.J == null) {
          View view2 = new View(this.q);
          this.J = view2;
          view2.setVisibility(8);
          FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
          layoutParams.leftMargin = m;
          layoutParams.rightMargin = n;
          this.H.addView(this.J, -1, (ViewGroup.LayoutParams)layoutParams);
        } else {
          View view2 = this.J;
          if (view2 != null) {
            ViewGroup.MarginLayoutParams marginLayoutParams1 = (ViewGroup.MarginLayoutParams)view2.getLayoutParams();
            i1 = marginLayoutParams1.height;
            i2 = marginLayoutParams.topMargin;
            if (i1 != i2 || marginLayoutParams1.leftMargin != m || marginLayoutParams1.rightMargin != n) {
              marginLayoutParams1.height = i2;
              marginLayoutParams1.leftMargin = m;
              marginLayoutParams1.rightMargin = n;
              this.J.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams1);
            } 
          } 
        } 
        View view1 = this.J;
        if (view1 != null) {
          n = bool1;
        } else {
          n = 0;
        } 
        if (n != 0 && view1.getVisibility() != 0)
          g1(this.J); 
        m = j;
        if (!this.O) {
          m = j;
          if (n != 0)
            m = 0; 
        } 
        j = m;
        m = bool;
        bool = n;
      } else if (marginLayoutParams.topMargin != 0) {
        marginLayoutParams.topMargin = 0;
        bool = false;
      } else {
        bool = false;
        m = 0;
      } 
      k = j;
      bool1 = bool;
      if (m != 0) {
        this.B.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        k = j;
        bool1 = bool;
      } 
    } else {
      bool1 = false;
      k = j;
    } 
    View view = this.J;
    if (view != null) {
      if (bool1) {
        j = bool2;
      } else {
        j = 8;
      } 
      view.setVisibility(j);
    } 
    return k;
  }
  
  public Context g(Context paramContext) {
    int j = 1;
    this.V = true;
    int k = D0(paramContext, Y());
    if (h.v(paramContext))
      h.R(paramContext); 
    androidx.core.os.g g1 = X(paramContext);
    if (t0 && paramContext instanceof ContextThemeWrapper) {
      Configuration configuration = e0(paramContext, k, g1, null, false);
      try {
        s.a((ContextThemeWrapper)paramContext, configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (paramContext instanceof androidx.appcompat.view.d) {
      Configuration configuration = e0(paramContext, k, g1, null, false);
      try {
        ((androidx.appcompat.view.d)paramContext).a(configuration);
        return paramContext;
      } catch (IllegalStateException illegalStateException) {}
    } 
    if (!s0)
      return super.g(paramContext); 
    Configuration configuration1 = new Configuration();
    configuration1.uiMode = -1;
    configuration1.fontScale = 0.0F;
    configuration1 = j.a(paramContext, configuration1).getResources().getConfiguration();
    Configuration configuration3 = paramContext.getResources().getConfiguration();
    configuration1.uiMode = configuration3.uiMode;
    if (!configuration1.equals(configuration3)) {
      configuration1 = o0(configuration1, configuration3);
    } else {
      configuration1 = null;
    } 
    Configuration configuration2 = e0(paramContext, k, g1, configuration1, true);
    androidx.appcompat.view.d d = new androidx.appcompat.view.d(paramContext, f.i.c);
    d.a(configuration2);
    k = 0;
    try {
      Resources.Theme theme = paramContext.getTheme();
      if (theme == null)
        j = 0; 
    } catch (NullPointerException nullPointerException) {
      j = k;
    } 
    if (j != 0)
      androidx.core.content.res.h.f.a(d.getTheme()); 
    return super.g((Context)d);
  }
  
  public View g0(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    u u1 = this.l0;
    boolean bool1 = false;
    if (u1 == null) {
      String str = this.q.obtainStyledAttributes(f.j.y0).getString(f.j.C0);
      if (str == null) {
        this.l0 = new u();
      } else {
        try {
          this.l0 = this.q.getClassLoader().loadClass(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } finally {
          Exception exception = null;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
        } 
      } 
    } 
    boolean bool2 = q0;
    if (bool2) {
      if (this.m0 == null)
        this.m0 = new y(); 
      if (this.m0.a(paramAttributeSet)) {
        bool1 = true;
      } else if (paramAttributeSet instanceof XmlPullParser) {
        if (((XmlPullParser)paramAttributeSet).getDepth() > 1)
          bool1 = true; 
      } else {
        bool1 = W0((ViewParent)paramView);
      } 
    } else {
      bool1 = false;
    } 
    return this.l0.r(paramView, paramString, paramContext, paramAttributeSet, bool1, bool2, true, h3.d());
  }
  
  void h0() {
    r1 r11 = this.x;
    if (r11 != null)
      r11.i(); 
    if (this.C != null) {
      this.r.getDecorView().removeCallbacks(this.D);
      if (this.C.isShowing())
        try {
          this.C.dismiss();
        } catch (IllegalArgumentException illegalArgumentException) {} 
      this.C = null;
    } 
    k0();
    u u1 = u0(0, false);
    if (u1 != null) {
      g g1 = u1.j;
      if (g1 != null)
        g1.close(); 
    } 
  }
  
  boolean i0(KeyEvent paramKeyEvent) {
    Object object = this.p;
    boolean bool1 = object instanceof androidx.core.view.t.a;
    boolean bool = true;
    if (bool1 || object instanceof s) {
      object = this.r.getDecorView();
      if (object != null && androidx.core.view.t.d((View)object, paramKeyEvent))
        return true; 
    } 
    if (paramKeyEvent.getKeyCode() == 82 && this.s.b(this.r.getCallback(), paramKeyEvent))
      return true; 
    int j = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? F0(j, paramKeyEvent) : I0(j, paramKeyEvent);
  }
  
  public <T extends View> T j(int paramInt) {
    l0();
    return (T)this.r.findViewById(paramInt);
  }
  
  void j0(int paramInt) {
    u u1 = u0(paramInt, true);
    if (u1.j != null) {
      Bundle bundle = new Bundle();
      u1.j.Q(bundle);
      if (bundle.size() > 0)
        u1.s = bundle; 
      u1.j.d0();
      u1.j.clear();
    } 
    u1.r = true;
    u1.q = true;
    if ((paramInt == 108 || paramInt == 0) && this.x != null) {
      u1 = u0(0, false);
      if (u1 != null) {
        u1.m = false;
        Q0(u1, null);
      } 
    } 
  }
  
  void k0() {
    e3 e31 = this.E;
    if (e31 != null)
      e31.c(); 
  }
  
  public Context l() {
    return this.q;
  }
  
  public final b n() {
    return new f(this);
  }
  
  u n0(Menu paramMenu) {
    byte b1;
    u[] arrayOfU = this.S;
    int j = 0;
    if (arrayOfU != null) {
      b1 = arrayOfU.length;
    } else {
      b1 = 0;
    } 
    while (j < b1) {
      u u1 = arrayOfU[j];
      if (u1 != null && u1.j == paramMenu)
        return u1; 
      j++;
    } 
    return null;
  }
  
  public int o() {
    return this.Z;
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return g0(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  final Context p0() {
    Context context;
    a a1 = s();
    if (a1 != null) {
      Context context1 = a1.k();
    } else {
      a1 = null;
    } 
    a a2 = a1;
    if (a1 == null)
      context = this.q; 
    return context;
  }
  
  public MenuInflater q() {
    if (this.v == null) {
      Context context;
      x0();
      a a1 = this.u;
      if (a1 != null) {
        context = a1.k();
      } else {
        context = this.q;
      } 
      this.v = (MenuInflater)new androidx.appcompat.view.g(context);
    } 
    return this.v;
  }
  
  public a s() {
    x0();
    return this.u;
  }
  
  public void t() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.q);
    if (layoutInflater.getFactory() == null) {
      androidx.core.view.u.a(layoutInflater, this);
      return;
    } 
    boolean bool = layoutInflater.getFactory2() instanceof i;
  }
  
  androidx.core.os.g t0(Configuration paramConfiguration) {
    return (Build.VERSION.SDK_INT >= 24) ? l.b(paramConfiguration) : androidx.core.os.g.c(k.b(paramConfiguration.locale));
  }
  
  public void u() {
    if (O0() != null) {
      if (s().l())
        return; 
      B0(0);
    } 
  }
  
  protected u u0(int paramInt, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: getfield S : [Landroidx/appcompat/app/i$u;
    //   4: astore #4
    //   6: aload #4
    //   8: ifnull -> 21
    //   11: aload #4
    //   13: astore_3
    //   14: aload #4
    //   16: arraylength
    //   17: iload_1
    //   18: if_icmpgt -> 49
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: anewarray androidx/appcompat/app/i$u
    //   27: astore_3
    //   28: aload #4
    //   30: ifnull -> 44
    //   33: aload #4
    //   35: iconst_0
    //   36: aload_3
    //   37: iconst_0
    //   38: aload #4
    //   40: arraylength
    //   41: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
    //   44: aload_0
    //   45: aload_3
    //   46: putfield S : [Landroidx/appcompat/app/i$u;
    //   49: aload_3
    //   50: iload_1
    //   51: aaload
    //   52: astore #5
    //   54: aload #5
    //   56: astore #4
    //   58: aload #5
    //   60: ifnonnull -> 78
    //   63: new androidx/appcompat/app/i$u
    //   66: dup
    //   67: iload_1
    //   68: invokespecial <init> : (I)V
    //   71: astore #4
    //   73: aload_3
    //   74: iload_1
    //   75: aload #4
    //   77: aastore
    //   78: aload #4
    //   80: areturn
  }
  
  final CharSequence v0() {
    Object object = this.p;
    return (object instanceof Activity) ? ((Activity)object).getTitle() : this.w;
  }
  
  final Window.Callback w0() {
    return this.r.getCallback();
  }
  
  public void x(Configuration paramConfiguration) {
    if (this.M && this.G) {
      a a1 = s();
      if (a1 != null)
        a1.m(paramConfiguration); 
    } 
    androidx.appcompat.widget.i.b().g(this.q);
    this.Y = new Configuration(this.q.getResources().getConfiguration());
    T(false, false);
  }
  
  public void y(Bundle paramBundle) {
    this.V = true;
    S(false);
    m0();
    Object object = this.p;
    if (object instanceof Activity) {
      try {
        object = androidx.core.app.q.c((Activity)object);
      } catch (IllegalArgumentException illegalArgumentException) {
        illegalArgumentException = null;
      } 
      if (illegalArgumentException != null) {
        a a1 = O0();
        if (a1 == null) {
          this.i0 = true;
        } else {
          a1.r(true);
        } 
      } 
      h.d(this);
    } 
    this.Y = new Configuration(this.q.getResources().getConfiguration());
    this.W = true;
  }
  
  public void z() {
    // Byte code:
    //   0: aload_0
    //   1: getfield p : Ljava/lang/Object;
    //   4: instanceof android/app/Activity
    //   7: ifeq -> 14
    //   10: aload_0
    //   11: invokestatic F : (Landroidx/appcompat/app/h;)V
    //   14: aload_0
    //   15: getfield f0 : Z
    //   18: ifeq -> 36
    //   21: aload_0
    //   22: getfield r : Landroid/view/Window;
    //   25: invokevirtual getDecorView : ()Landroid/view/View;
    //   28: aload_0
    //   29: getfield h0 : Ljava/lang/Runnable;
    //   32: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   35: pop
    //   36: aload_0
    //   37: iconst_1
    //   38: putfield X : Z
    //   41: aload_0
    //   42: getfield Z : I
    //   45: bipush #-100
    //   47: if_icmpeq -> 99
    //   50: aload_0
    //   51: getfield p : Ljava/lang/Object;
    //   54: astore_1
    //   55: aload_1
    //   56: instanceof android/app/Activity
    //   59: ifeq -> 99
    //   62: aload_1
    //   63: checkcast android/app/Activity
    //   66: invokevirtual isChangingConfigurations : ()Z
    //   69: ifeq -> 99
    //   72: getstatic androidx/appcompat/app/i.p0 : Landroidx/collection/g;
    //   75: aload_0
    //   76: getfield p : Ljava/lang/Object;
    //   79: invokevirtual getClass : ()Ljava/lang/Class;
    //   82: invokevirtual getName : ()Ljava/lang/String;
    //   85: aload_0
    //   86: getfield Z : I
    //   89: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   92: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   95: pop
    //   96: goto -> 116
    //   99: getstatic androidx/appcompat/app/i.p0 : Landroidx/collection/g;
    //   102: aload_0
    //   103: getfield p : Ljava/lang/Object;
    //   106: invokevirtual getClass : ()Ljava/lang/Class;
    //   109: invokevirtual getName : ()Ljava/lang/String;
    //   112: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   115: pop
    //   116: aload_0
    //   117: getfield u : Landroidx/appcompat/app/a;
    //   120: astore_1
    //   121: aload_1
    //   122: ifnull -> 129
    //   125: aload_1
    //   126: invokevirtual n : ()V
    //   129: aload_0
    //   130: invokespecial b0 : ()V
    //   133: return
  }
  
  class a implements Runnable {
    a(i this$0) {}
    
    public void run() {
      i i1 = this.g;
      if ((i1.g0 & 0x1) != 0)
        i1.j0(0); 
      i1 = this.g;
      if ((i1.g0 & 0x1000) != 0)
        i1.j0(108); 
      i1 = this.g;
      i1.f0 = false;
      i1.g0 = 0;
    }
  }
  
  class b implements u0 {
    b(i this$0) {}
    
    public t3 a(View param1View, t3 param1t3) {
      int j = param1t3.l();
      int k = this.a.f1(param1t3, null);
      t3 t31 = param1t3;
      if (j != k)
        t31 = param1t3.p(param1t3.j(), k, param1t3.k(), param1t3.i()); 
      return e1.i0(param1View, t31);
    }
  }
  
  class c implements ContentFrameLayout.a {
    c(i this$0) {}
    
    public void a() {}
    
    public void onDetachedFromWindow() {
      this.a.h0();
    }
  }
  
  class d implements Runnable {
    d(i this$0) {}
    
    public void run() {
      i i1 = this.g;
      i1.C.showAtLocation((View)i1.B, 55, 0, 0);
      this.g.k0();
      if (this.g.V0()) {
        this.g.B.setAlpha(0.0F);
        i1 = this.g;
        i1.E = e1.e((View)i1.B).b(1.0F);
        this.g.E.h((f3)new a(this));
        return;
      } 
      this.g.B.setAlpha(1.0F);
      this.g.B.setVisibility(0);
    }
    
    class a extends g3 {
      a(i.d this$0) {}
      
      public void b(View param2View) {
        this.a.g.B.setAlpha(1.0F);
        this.a.g.E.h(null);
        this.a.g.E = null;
      }
      
      public void c(View param2View) {
        this.a.g.B.setVisibility(0);
      }
    }
  }
  
  class a extends g3 {
    a(i this$0) {}
    
    public void b(View param1View) {
      this.a.g.B.setAlpha(1.0F);
      this.a.g.E.h(null);
      this.a.g.E = null;
    }
    
    public void c(View param1View) {
      this.a.g.B.setVisibility(0);
    }
  }
  
  class e extends g3 {
    e(i this$0) {}
    
    public void b(View param1View) {
      this.a.B.setAlpha(1.0F);
      this.a.E.h(null);
      this.a.E = null;
    }
    
    public void c(View param1View) {
      this.a.B.setVisibility(0);
      if (this.a.B.getParent() instanceof View)
        e1.t0((View)this.a.B.getParent()); 
    }
  }
  
  private class f implements b {
    f(i this$0) {}
  }
  
  static interface g {
    boolean a(int param1Int);
    
    View onCreatePanelView(int param1Int);
  }
  
  private final class h implements androidx.appcompat.view.menu.m.a {
    h(i this$0) {}
    
    public void c(g param1g, boolean param1Boolean) {
      this.g.a0(param1g);
    }
    
    public boolean d(g param1g) {
      Window.Callback callback = this.g.w0();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1g); 
      return true;
    }
  }
  
  class i implements androidx.appcompat.view.b.a {
    private androidx.appcompat.view.b.a a;
    
    public i(i this$0, androidx.appcompat.view.b.a param1a) {
      this.a = param1a;
    }
    
    public void a(androidx.appcompat.view.b param1b) {
      this.a.a(param1b);
      i i1 = this.b;
      if (i1.C != null)
        i1.r.getDecorView().removeCallbacks(this.b.D); 
      i1 = this.b;
      if (i1.B != null) {
        i1.k0();
        i1 = this.b;
        i1.E = e1.e((View)i1.B).b(0.0F);
        this.b.E.h((f3)new a(this));
      } 
      i1 = this.b;
      e e = i1.t;
      if (e != null)
        e.onSupportActionModeFinished(i1.A); 
      i1 = this.b;
      i1.A = null;
      e1.t0((View)i1.H);
      this.b.d1();
    }
    
    public boolean b(androidx.appcompat.view.b param1b, Menu param1Menu) {
      return this.a.b(param1b, param1Menu);
    }
    
    public boolean c(androidx.appcompat.view.b param1b, Menu param1Menu) {
      e1.t0((View)this.b.H);
      return this.a.c(param1b, param1Menu);
    }
    
    public boolean d(androidx.appcompat.view.b param1b, MenuItem param1MenuItem) {
      return this.a.d(param1b, param1MenuItem);
    }
    
    class a extends g3 {
      a(i.i this$0) {}
      
      public void b(View param2View) {
        this.a.b.B.setVisibility(8);
        i i1 = this.a.b;
        PopupWindow popupWindow = i1.C;
        if (popupWindow != null) {
          popupWindow.dismiss();
        } else if (i1.B.getParent() instanceof View) {
          e1.t0((View)this.a.b.B.getParent());
        } 
        this.a.b.B.k();
        this.a.b.E.h(null);
        i1 = this.a.b;
        i1.E = null;
        e1.t0((View)i1.H);
      }
    }
  }
  
  class a extends g3 {
    a(i this$0) {}
    
    public void b(View param1View) {
      this.a.b.B.setVisibility(8);
      i i1 = this.a.b;
      PopupWindow popupWindow = i1.C;
      if (popupWindow != null) {
        popupWindow.dismiss();
      } else if (i1.B.getParent() instanceof View) {
        e1.t0((View)this.a.b.B.getParent());
      } 
      this.a.b.B.k();
      this.a.b.E.h(null);
      i1 = this.a.b;
      i1.E = null;
      e1.t0((View)i1.H);
    }
  }
  
  static class j {
    static Context a(Context param1Context, Configuration param1Configuration) {
      return param1Context.createConfigurationContext(param1Configuration);
    }
    
    static void b(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      int i = param1Configuration1.densityDpi;
      int k = param1Configuration2.densityDpi;
      if (i != k)
        param1Configuration3.densityDpi = k; 
    }
    
    static void c(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLayoutDirection(param1Locale);
    }
    
    static void d(Configuration param1Configuration, Locale param1Locale) {
      param1Configuration.setLocale(param1Locale);
    }
  }
  
  static class k {
    static boolean a(PowerManager param1PowerManager) {
      return param1PowerManager.isPowerSaveMode();
    }
    
    static String b(Locale param1Locale) {
      return param1Locale.toLanguageTag();
    }
  }
  
  static class l {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      LocaleList localeList1 = k.a(param1Configuration1);
      LocaleList localeList2 = k.a(param1Configuration2);
      if (!n.a(localeList1, localeList2)) {
        m.a(param1Configuration3, localeList2);
        param1Configuration3.locale = param1Configuration2.locale;
      } 
    }
    
    static androidx.core.os.g b(Configuration param1Configuration) {
      return androidx.core.os.g.c(l.a(k.a(param1Configuration)));
    }
    
    public static void c(androidx.core.os.g param1g) {
      j.a(g.a(param1g.h()));
    }
    
    static void d(Configuration param1Configuration, androidx.core.os.g param1g) {
      m.a(param1Configuration, g.a(param1g.h()));
    }
  }
  
  static class m {
    static void a(Configuration param1Configuration1, Configuration param1Configuration2, Configuration param1Configuration3) {
      if ((o.a(param1Configuration1) & 0x3) != (o.a(param1Configuration2) & 0x3))
        p.a(param1Configuration3, o.a(param1Configuration3) | o.a(param1Configuration2) & 0x3); 
      if ((o.a(param1Configuration1) & 0xC) != (o.a(param1Configuration2) & 0xC))
        p.a(param1Configuration3, o.a(param1Configuration3) | o.a(param1Configuration2) & 0xC); 
    }
  }
  
  static class n {
    static OnBackInvokedDispatcher a(Activity param1Activity) {
      return param1Activity.getOnBackInvokedDispatcher();
    }
    
    static OnBackInvokedCallback b(Object param1Object, i param1i) {
      Objects.requireNonNull(param1i);
      q q = new q(param1i);
      ((OnBackInvokedDispatcher)param1Object).registerOnBackInvokedCallback(1000000, q);
      return q;
    }
    
    static void c(Object param1Object1, Object param1Object2) {
      param1Object2 = param1Object2;
      ((OnBackInvokedDispatcher)param1Object1).unregisterOnBackInvokedCallback((OnBackInvokedCallback)param1Object2);
    }
  }
  
  class o extends androidx.appcompat.view.k {
    private i.g h;
    
    private boolean i;
    
    private boolean j;
    
    private boolean k;
    
    o(i this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean b(Window.Callback param1Callback, KeyEvent param1KeyEvent) {
      try {
        this.j = true;
        return param1Callback.dispatchKeyEvent(param1KeyEvent);
      } finally {
        this.j = false;
      } 
    }
    
    public void c(Window.Callback param1Callback) {
      try {
        this.i = true;
        param1Callback.onContentChanged();
        return;
      } finally {
        this.i = false;
      } 
    }
    
    public void d(Window.Callback param1Callback, int param1Int, Menu param1Menu) {
      try {
        this.k = true;
        param1Callback.onPanelClosed(param1Int, param1Menu);
        return;
      } finally {
        this.k = false;
      } 
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return this.j ? a().dispatchKeyEvent(param1KeyEvent) : ((this.l.i0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent)));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.l.H0(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    void e(i.g param1g) {
      this.h = param1g;
    }
    
    final ActionMode f(ActionMode.Callback param1Callback) {
      androidx.appcompat.view.f.a a = new androidx.appcompat.view.f.a(this.l.q, param1Callback);
      androidx.appcompat.view.b b = this.l.Q((androidx.appcompat.view.b.a)a);
      return (b != null) ? a.e(b) : null;
    }
    
    public void onContentChanged() {
      if (this.i)
        a().onContentChanged(); 
    }
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof g)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public View onCreatePanelView(int param1Int) {
      i.g g1 = this.h;
      if (g1 != null) {
        View view = g1.onCreatePanelView(param1Int);
        if (view != null)
          return view; 
      } 
      return super.onCreatePanelView(param1Int);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.l.K0(param1Int);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      if (this.k) {
        a().onPanelClosed(param1Int, param1Menu);
        return;
      } 
      super.onPanelClosed(param1Int, param1Menu);
      this.l.L0(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      g g1;
      if (param1Menu instanceof g) {
        g1 = (g)param1Menu;
      } else {
        g1 = null;
      } 
      if (param1Int == 0 && g1 == null)
        return false; 
      boolean bool1 = true;
      if (g1 != null)
        g1.a0(true); 
      i.g g2 = this.h;
      if (g2 == null || !g2.a(param1Int))
        bool1 = false; 
      boolean bool2 = bool1;
      if (!bool1)
        bool2 = super.onPreparePanel(param1Int, param1View, param1Menu); 
      if (g1 != null)
        g1.a0(false); 
      return bool2;
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      i.u u = this.l.u0(0, true);
      if (u != null) {
        g g1 = u.j;
        if (g1 != null) {
          super.onProvideKeyboardShortcuts(param1List, (Menu)g1, param1Int);
          return;
        } 
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return (Build.VERSION.SDK_INT >= 23) ? null : (this.l.C0() ? f(param1Callback) : super.onWindowStartingActionMode(param1Callback));
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback, int param1Int) {
      return (!this.l.C0() || param1Int != 0) ? super.onWindowStartingActionMode(param1Callback, param1Int) : f(param1Callback);
    }
  }
  
  private class p extends q {
    private final PowerManager c;
    
    p(i this$0, Context param1Context) {
      super(this$0);
      this.c = (PowerManager)param1Context.getApplicationContext().getSystemService("power");
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
      return intentFilter;
    }
    
    public int c() {
      return i.k.a(this.c) ? 2 : 1;
    }
    
    public void d() {
      this.d.U();
    }
  }
  
  abstract class q {
    private BroadcastReceiver a;
    
    q(i this$0) {}
    
    void a() {
      BroadcastReceiver broadcastReceiver = this.a;
      if (broadcastReceiver != null) {
        try {
          this.b.q.unregisterReceiver(broadcastReceiver);
        } catch (IllegalArgumentException illegalArgumentException) {}
        this.a = null;
      } 
    }
    
    abstract IntentFilter b();
    
    abstract int c();
    
    abstract void d();
    
    void e() {
      a();
      IntentFilter intentFilter = b();
      if (intentFilter != null) {
        if (intentFilter.countActions() == 0)
          return; 
        if (this.a == null)
          this.a = new a(this); 
        this.b.q.registerReceiver(this.a, intentFilter);
      } 
    }
    
    class a extends BroadcastReceiver {
      a(i.q this$0) {}
      
      public void onReceive(Context param2Context, Intent param2Intent) {
        this.a.d();
      }
    }
  }
  
  class a extends BroadcastReceiver {
    a(i this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.d();
    }
  }
  
  private class r extends q {
    private final d0 c;
    
    r(i this$0, d0 param1d0) {
      super(this$0);
      this.c = param1d0;
    }
    
    IntentFilter b() {
      IntentFilter intentFilter = new IntentFilter();
      intentFilter.addAction("android.intent.action.TIME_SET");
      intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
      intentFilter.addAction("android.intent.action.TIME_TICK");
      return intentFilter;
    }
    
    public int c() {
      return this.c.d() ? 2 : 1;
    }
    
    public void d() {
      this.d.U();
    }
  }
  
  private static class s {
    static void a(ContextThemeWrapper param1ContextThemeWrapper, Configuration param1Configuration) {
      param1ContextThemeWrapper.applyOverrideConfiguration(param1Configuration);
    }
  }
  
  private class t extends ContentFrameLayout {
    public t(i this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean b(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > getWidth() + 5 || param1Int2 > getHeight() + 5);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.o.i0(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && b((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.o.c0(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(g.a.b(getContext(), param1Int));
    }
  }
  
  protected static final class u {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    g j;
    
    androidx.appcompat.view.menu.e k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    public boolean p;
    
    boolean q;
    
    boolean r;
    
    Bundle s;
    
    u(int param1Int) {
      this.a = param1Int;
      this.q = false;
    }
    
    androidx.appcompat.view.menu.n a(androidx.appcompat.view.menu.m.a param1a) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        androidx.appcompat.view.menu.e e1 = new androidx.appcompat.view.menu.e(this.l, f.g.j);
        this.k = e1;
        e1.h(param1a);
        this.j.b((androidx.appcompat.view.menu.m)this.k);
      } 
      return this.k.b(this.g);
    }
    
    public boolean b() {
      View view = this.h;
      boolean bool = false;
      if (view == null)
        return false; 
      if (this.i != null)
        return true; 
      if (this.k.a().getCount() > 0)
        bool = true; 
      return bool;
    }
    
    void c(g param1g) {
      g g1 = this.j;
      if (param1g == g1)
        return; 
      if (g1 != null)
        g1.O((androidx.appcompat.view.menu.m)this.k); 
      this.j = param1g;
      if (param1g != null) {
        androidx.appcompat.view.menu.e e1 = this.k;
        if (e1 != null)
          param1g.b((androidx.appcompat.view.menu.m)e1); 
      } 
    }
    
    void d(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(f.a.a, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0)
        theme.applyStyle(i, true); 
      theme.resolveAttribute(f.a.F, typedValue, true);
      i = typedValue.resourceId;
      if (i != 0) {
        theme.applyStyle(i, true);
      } else {
        theme.applyStyle(f.i.b, true);
      } 
      androidx.appcompat.view.d d = new androidx.appcompat.view.d(param1Context, 0);
      d.getTheme().setTo(theme);
      this.l = (Context)d;
      TypedArray typedArray = d.obtainStyledAttributes(f.j.y0);
      this.b = typedArray.getResourceId(f.j.B0, 0);
      this.f = typedArray.getResourceId(f.j.A0, 0);
      typedArray.recycle();
    }
  }
  
  private final class v implements androidx.appcompat.view.menu.m.a {
    v(i this$0) {}
    
    public void c(g param1g, boolean param1Boolean) {
      boolean bool;
      g g1 = param1g.D();
      if (g1 != param1g) {
        bool = true;
      } else {
        bool = false;
      } 
      i i1 = this.g;
      if (bool)
        param1g = g1; 
      i.u u = i1.n0((Menu)param1g);
      if (u != null) {
        if (bool) {
          this.g.Z(u.a, u, (Menu)g1);
          this.g.d0(u, true);
          return;
        } 
        this.g.d0(u, param1Boolean);
      } 
    }
    
    public boolean d(g param1g) {
      if (param1g == param1g.D()) {
        i i1 = this.g;
        if (i1.M) {
          Window.Callback callback = i1.w0();
          if (callback != null && !this.g.X)
            callback.onMenuOpened(108, (Menu)param1g); 
        } 
      } 
      return true;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */