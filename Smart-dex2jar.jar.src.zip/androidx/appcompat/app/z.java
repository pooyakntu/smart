package androidx.appcompat.app;

import androidx.core.os.g;
import java.util.LinkedHashSet;
import java.util.Locale;

final class z {
  private static g a(g paramg1, g paramg2) {
    LinkedHashSet<Locale> linkedHashSet = new LinkedHashSet();
    for (int i = 0; i < paramg1.g() + paramg2.g(); i++) {
      Locale locale;
      if (i < paramg1.g()) {
        locale = paramg1.d(i);
      } else {
        locale = paramg2.d(i - paramg1.g());
      } 
      if (locale != null)
        linkedHashSet.add(locale); 
    } 
    return g.a(linkedHashSet.<Locale>toArray(new Locale[linkedHashSet.size()]));
  }
  
  static g b(g paramg1, g paramg2) {
    return (paramg1 == null || paramg1.f()) ? g.e() : a(paramg1, paramg2);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */