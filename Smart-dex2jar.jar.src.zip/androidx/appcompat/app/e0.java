package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.view.g;
import androidx.appcompat.view.h;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.p2;
import androidx.appcompat.widget.s1;
import androidx.core.view.e1;
import androidx.core.view.e3;
import androidx.core.view.f3;
import androidx.core.view.g3;
import androidx.core.view.h3;
import f.f;
import f.j;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class e0 extends a implements ActionBarOverlayLayout.d {
  private static final Interpolator E = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator F = (Interpolator)new DecelerateInterpolator();
  
  boolean A;
  
  final f3 B = (f3)new a(this);
  
  final f3 C = (f3)new b(this);
  
  final h3 D = new c(this);
  
  Context a;
  
  private Context b;
  
  private Activity c;
  
  ActionBarOverlayLayout d;
  
  ActionBarContainer e;
  
  s1 f;
  
  ActionBarContextView g;
  
  View h;
  
  p2 i;
  
  private ArrayList<Object> j = new ArrayList();
  
  private int k = -1;
  
  private boolean l;
  
  d m;
  
  androidx.appcompat.view.b n;
  
  androidx.appcompat.view.b.a o;
  
  private boolean p;
  
  private ArrayList<a.b> q = new ArrayList<a.b>();
  
  private boolean r;
  
  private int s = 0;
  
  boolean t = true;
  
  boolean u;
  
  boolean v;
  
  private boolean w;
  
  private boolean x = true;
  
  h y;
  
  private boolean z;
  
  public e0(Activity paramActivity, boolean paramBoolean) {
    this.c = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    E(view);
    if (!paramBoolean)
      this.h = view.findViewById(16908290); 
  }
  
  public e0(Dialog paramDialog) {
    E(paramDialog.getWindow().getDecorView());
  }
  
  private s1 B(View paramView) {
    String str;
    if (paramView instanceof s1)
      return (s1)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    if (paramView != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    stringBuilder.append(str);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void D() {
    if (this.w) {
      this.w = false;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(false); 
      M(false);
    } 
  }
  
  private void E(View paramView) {
    ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout)paramView.findViewById(f.p);
    this.d = actionBarOverlayLayout;
    if (actionBarOverlayLayout != null)
      actionBarOverlayLayout.setActionBarVisibilityCallback(this); 
    this.f = B(paramView.findViewById(f.a));
    this.g = (ActionBarContextView)paramView.findViewById(f.f);
    ActionBarContainer actionBarContainer = (ActionBarContainer)paramView.findViewById(f.c);
    this.e = actionBarContainer;
    s1 s11 = this.f;
    if (s11 != null && this.g != null && actionBarContainer != null) {
      boolean bool;
      this.a = s11.getContext();
      if ((this.f.s() & 0x4) != 0) {
        i = 1;
      } else {
        i = 0;
      } 
      if (i)
        this.l = true; 
      androidx.appcompat.view.a a1 = androidx.appcompat.view.a.b(this.a);
      if (a1.a() || i) {
        bool = true;
      } else {
        bool = false;
      } 
      J(bool);
      H(a1.g());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, j.a, f.a.c, 0);
      if (typedArray.getBoolean(j.k, false))
        I(true); 
      int i = typedArray.getDimensionPixelSize(j.i, 0);
      if (i != 0)
        G(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void H(boolean paramBoolean) {
    this.r = paramBoolean;
    if (!paramBoolean) {
      this.f.i(null);
      this.e.setTabContainer(this.i);
    } else {
      this.e.setTabContainer(null);
      this.f.i(this.i);
    } 
    int i = C();
    boolean bool = true;
    if (i == 2) {
      i = 1;
    } else {
      i = 0;
    } 
    p2 p21 = this.i;
    if (p21 != null) {
      ActionBarOverlayLayout actionBarOverlayLayout1;
      if (i != 0) {
        p21.setVisibility(0);
        actionBarOverlayLayout1 = this.d;
        if (actionBarOverlayLayout1 != null)
          e1.t0((View)actionBarOverlayLayout1); 
      } else {
        actionBarOverlayLayout1.setVisibility(8);
      } 
    } 
    s1 s11 = this.f;
    if (!this.r && i != 0) {
      paramBoolean = true;
    } else {
      paramBoolean = false;
    } 
    s11.v(paramBoolean);
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (!this.r && i != 0) {
      paramBoolean = bool;
    } else {
      paramBoolean = false;
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(paramBoolean);
  }
  
  private boolean K() {
    return e1.a0((View)this.e);
  }
  
  private void L() {
    if (!this.w) {
      this.w = true;
      ActionBarOverlayLayout actionBarOverlayLayout = this.d;
      if (actionBarOverlayLayout != null)
        actionBarOverlayLayout.setShowingForActionMode(true); 
      M(false);
    } 
  }
  
  private void M(boolean paramBoolean) {
    if (x(this.u, this.v, this.w)) {
      if (!this.x) {
        this.x = true;
        A(paramBoolean);
        return;
      } 
    } else if (this.x) {
      this.x = false;
      z(paramBoolean);
    } 
  }
  
  static boolean x(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  public void A(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    this.e.setVisibility(0);
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setTranslationY(0.0F);
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      this.e.setTranslationY(f1);
      h1 = new h();
      e3 e3 = e1.e((View)this.e).m(0.0F);
      e3.k(this.D);
      h1.c(e3);
      if (this.t) {
        View view = this.h;
        if (view != null) {
          view.setTranslationY(f1);
          h1.c(e1.e(this.h).m(0.0F));
        } 
      } 
      h1.f(F);
      h1.e(250L);
      h1.g(this.C);
      this.y = h1;
      h1.h();
    } else {
      this.e.setAlpha(1.0F);
      this.e.setTranslationY(0.0F);
      if (this.t) {
        View view = this.h;
        if (view != null)
          view.setTranslationY(0.0F); 
      } 
      this.C.b(null);
    } 
    ActionBarOverlayLayout actionBarOverlayLayout = this.d;
    if (actionBarOverlayLayout != null)
      e1.t0((View)actionBarOverlayLayout); 
  }
  
  public int C() {
    return this.f.n();
  }
  
  public void F(int paramInt1, int paramInt2) {
    int i = this.f.s();
    if ((paramInt2 & 0x4) != 0)
      this.l = true; 
    this.f.k(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  public void G(float paramFloat) {
    e1.G0((View)this.e, paramFloat);
  }
  
  public void I(boolean paramBoolean) {
    if (!paramBoolean || this.d.w()) {
      this.A = paramBoolean;
      this.d.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void J(boolean paramBoolean) {
    this.f.r(paramBoolean);
  }
  
  public void a() {
    if (this.v) {
      this.v = false;
      M(true);
    } 
  }
  
  public void b() {}
  
  public void c(boolean paramBoolean) {
    this.t = paramBoolean;
  }
  
  public void d() {
    if (!this.v) {
      this.v = true;
      M(true);
    } 
  }
  
  public void e() {
    h h1 = this.y;
    if (h1 != null) {
      h1.a();
      this.y = null;
    } 
  }
  
  public void f(int paramInt) {
    this.s = paramInt;
  }
  
  public boolean h() {
    s1 s11 = this.f;
    if (s11 != null && s11.j()) {
      this.f.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.p)
      return; 
    this.p = paramBoolean;
    int j = this.q.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.q.get(i)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.f.s();
  }
  
  public Context k() {
    if (this.b == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(f.a.g, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.b = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.b = this.a;
      } 
    } 
    return this.b;
  }
  
  public void m(Configuration paramConfiguration) {
    H(androidx.appcompat.view.a.b(this.a).g());
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    d d1 = this.m;
    if (d1 == null)
      return false; 
    Menu menu = d1.e();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void r(boolean paramBoolean) {
    if (!this.l)
      s(paramBoolean); 
  }
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    F(bool, 4);
  }
  
  public void t(boolean paramBoolean) {
    this.z = paramBoolean;
    if (!paramBoolean) {
      h h1 = this.y;
      if (h1 != null)
        h1.a(); 
    } 
  }
  
  public void u(CharSequence paramCharSequence) {
    this.f.setWindowTitle(paramCharSequence);
  }
  
  public androidx.appcompat.view.b v(androidx.appcompat.view.b.a parama) {
    d d2 = this.m;
    if (d2 != null)
      d2.c(); 
    this.d.setHideOnContentScrollEnabled(false);
    this.g.k();
    d d1 = new d(this, this.g.getContext(), parama);
    if (d1.t()) {
      this.m = d1;
      d1.k();
      this.g.h(d1);
      w(true);
      return d1;
    } 
    return null;
  }
  
  public void w(boolean paramBoolean) {
    if (paramBoolean) {
      L();
    } else {
      D();
    } 
    if (K()) {
      e3 e31;
      e3 e32;
      if (paramBoolean) {
        e32 = this.f.o(4, 100L);
        e31 = this.g.f(0, 200L);
      } else {
        e31 = this.f.o(0, 200L);
        e32 = this.g.f(8, 100L);
      } 
      h h1 = new h();
      h1.d(e32, e31);
      h1.h();
      return;
    } 
    if (paramBoolean) {
      this.f.setVisibility(4);
      this.g.setVisibility(0);
      return;
    } 
    this.f.setVisibility(0);
    this.g.setVisibility(8);
  }
  
  void y() {
    androidx.appcompat.view.b.a a1 = this.o;
    if (a1 != null) {
      a1.a(this.n);
      this.n = null;
      this.o = null;
    } 
  }
  
  public void z(boolean paramBoolean) {
    h h1 = this.y;
    if (h1 != null)
      h1.a(); 
    if (this.s == 0 && (this.z || paramBoolean)) {
      this.e.setAlpha(1.0F);
      this.e.setTransitioning(true);
      h1 = new h();
      float f2 = -this.e.getHeight();
      float f1 = f2;
      if (paramBoolean) {
        int[] arrayOfInt = new int[2];
        arrayOfInt[0] = 0;
        arrayOfInt[1] = 0;
        this.e.getLocationInWindow(arrayOfInt);
        f1 = f2 - arrayOfInt[1];
      } 
      e3 e3 = e1.e((View)this.e).m(f1);
      e3.k(this.D);
      h1.c(e3);
      if (this.t) {
        View view = this.h;
        if (view != null)
          h1.c(e1.e(view).m(f1)); 
      } 
      h1.f(E);
      h1.e(250L);
      h1.g(this.B);
      this.y = h1;
      h1.h();
      return;
    } 
    this.B.b(null);
  }
  
  class a extends g3 {
    a(e0 this$0) {}
    
    public void b(View param1View) {
      e0 e01 = this.a;
      if (e01.t) {
        View view = e01.h;
        if (view != null) {
          view.setTranslationY(0.0F);
          this.a.e.setTranslationY(0.0F);
        } 
      } 
      this.a.e.setVisibility(8);
      this.a.e.setTransitioning(false);
      e01 = this.a;
      e01.y = null;
      e01.y();
      ActionBarOverlayLayout actionBarOverlayLayout = this.a.d;
      if (actionBarOverlayLayout != null)
        e1.t0((View)actionBarOverlayLayout); 
    }
  }
  
  class b extends g3 {
    b(e0 this$0) {}
    
    public void b(View param1View) {
      e0 e01 = this.a;
      e01.y = null;
      e01.e.requestLayout();
    }
  }
  
  class c implements h3 {
    c(e0 this$0) {}
    
    public void a(View param1View) {
      ((View)this.a.e.getParent()).invalidate();
    }
  }
  
  public class d extends androidx.appcompat.view.b implements g.a {
    private final Context i;
    
    private final g j;
    
    private androidx.appcompat.view.b.a k;
    
    private WeakReference<View> l;
    
    public d(e0 this$0, Context param1Context, androidx.appcompat.view.b.a param1a) {
      this.i = param1Context;
      this.k = param1a;
      g g1 = (new g(param1Context)).S(1);
      this.j = g1;
      g1.R(this);
    }
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      androidx.appcompat.view.b.a a1 = this.k;
      return (a1 != null) ? a1.d(this, param1MenuItem) : false;
    }
    
    public void b(g param1g) {
      if (this.k == null)
        return; 
      k();
      this.m.g.l();
    }
    
    public void c() {
      e0 e01 = this.m;
      if (e01.m != this)
        return; 
      if (!e0.x(e01.u, e01.v, false)) {
        e01 = this.m;
        e01.n = this;
        e01.o = this.k;
      } else {
        this.k.a(this);
      } 
      this.k = null;
      this.m.w(false);
      this.m.g.g();
      e01 = this.m;
      e01.d.setHideOnContentScrollEnabled(e01.A);
      this.m.m = null;
    }
    
    public View d() {
      WeakReference<View> weakReference = this.l;
      return (weakReference != null) ? weakReference.get() : null;
    }
    
    public Menu e() {
      return (Menu)this.j;
    }
    
    public MenuInflater f() {
      return (MenuInflater)new g(this.i);
    }
    
    public CharSequence g() {
      return this.m.g.getSubtitle();
    }
    
    public CharSequence i() {
      return this.m.g.getTitle();
    }
    
    public void k() {
      if (this.m.m != this)
        return; 
      this.j.d0();
      try {
        this.k.c(this, (Menu)this.j);
        return;
      } finally {
        this.j.c0();
      } 
    }
    
    public boolean l() {
      return this.m.g.j();
    }
    
    public void m(View param1View) {
      this.m.g.setCustomView(param1View);
      this.l = new WeakReference<View>(param1View);
    }
    
    public void n(int param1Int) {
      o(this.m.a.getResources().getString(param1Int));
    }
    
    public void o(CharSequence param1CharSequence) {
      this.m.g.setSubtitle(param1CharSequence);
    }
    
    public void q(int param1Int) {
      r(this.m.a.getResources().getString(param1Int));
    }
    
    public void r(CharSequence param1CharSequence) {
      this.m.g.setTitle(param1CharSequence);
    }
    
    public void s(boolean param1Boolean) {
      super.s(param1Boolean);
      this.m.g.setTitleOptional(param1Boolean);
    }
    
    public boolean t() {
      this.j.d0();
      try {
        return this.k.b(this, (Menu)this.j);
      } finally {
        this.j.c0();
      } 
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\e0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */