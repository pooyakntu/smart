package androidx.appcompat.app;

import android.content.res.Resources;
import android.os.Build;
import android.util.LongSparseArray;
import java.lang.reflect.Field;
import java.util.Map;

class a0 {
  private static Field a;
  
  private static boolean b;
  
  private static Class<?> c;
  
  private static boolean d;
  
  private static Field e;
  
  private static boolean f;
  
  private static Field g;
  
  private static boolean h;
  
  static void a(Resources paramResources) {
    int i = Build.VERSION.SDK_INT;
    if (i >= 28)
      return; 
    if (i >= 24) {
      d(paramResources);
      return;
    } 
    if (i >= 23) {
      c(paramResources);
      return;
    } 
    b(paramResources);
  }
  
  private static void b(Resources paramResources) {
    if (!b) {
      try {
        Field field1 = Resources.class.getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      b = true;
    } 
    Field field = a;
    if (field != null) {
      try {
        Map map = (Map)field.get(paramResources);
      } catch (IllegalAccessException illegalAccessException) {
        illegalAccessException = null;
      } 
      if (illegalAccessException != null)
        illegalAccessException.clear(); 
    } 
  }
  
  private static void c(Resources paramResources) {
    if (!b) {
      try {
        Field field1 = Resources.class.getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      b = true;
    } 
    Field field = a;
    if (field != null)
      try {
        Object object = field.get(paramResources);
        if (object == null)
          return; 
        e(object);
        return;
      } catch (IllegalAccessException illegalAccessException) {} 
    paramResources = null;
    if (paramResources == null)
      return; 
    e(paramResources);
  }
  
  private static void d(Resources paramResources) {
    if (!h) {
      try {
        Field field = Resources.class.getDeclaredField("mResourcesImpl");
        g = field;
        field.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      h = true;
    } 
    Field field1 = g;
    if (field1 == null)
      return; 
    Field field2 = null;
    try {
      object = field1.get(paramResources);
    } catch (IllegalAccessException object) {
      object = null;
    } 
    if (object == null)
      return; 
    if (!b) {
      try {
        field1 = object.getClass().getDeclaredField("mDrawableCache");
        a = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      b = true;
    } 
    Field field3 = a;
    field1 = field2;
    if (field3 != null)
      try {
        Object object1 = field3.get(object);
      } catch (IllegalAccessException illegalAccessException) {
        field1 = field2;
      }  
    if (field1 != null)
      e(field1); 
  }
  
  private static void e(Object paramObject) {
    if (!d) {
      try {
        c = Class.forName("android.content.res.ThemedResourceCache");
      } catch (ClassNotFoundException classNotFoundException) {}
      d = true;
    } 
    Class<?> clazz = c;
    if (clazz == null)
      return; 
    if (!f) {
      try {
        Field field1 = clazz.getDeclaredField("mUnthemedEntries");
        e = field1;
        field1.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {}
      f = true;
    } 
    Field field = e;
    if (field == null)
      return; 
    try {
      paramObject = field.get(paramObject);
    } catch (IllegalAccessException illegalAccessException) {
      illegalAccessException = null;
    } 
    if (illegalAccessException != null)
      a.a((LongSparseArray)illegalAccessException); 
  }
  
  static class a {
    static void a(LongSparseArray param1LongSparseArray) {
      param1LongSparseArray.clear();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\a0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */