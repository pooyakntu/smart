package androidx.appcompat.app;

import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import java.util.ArrayDeque;
import java.util.Queue;
import java.util.concurrent.Executor;

class x {
  static void a(Context paramContext, String paramString) {
    // Byte code:
    //   0: aload_1
    //   1: ldc ''
    //   3: invokevirtual equals : (Ljava/lang/Object;)Z
    //   6: ifeq -> 17
    //   9: aload_0
    //   10: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   12: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   15: pop
    //   16: return
    //   17: aload_0
    //   18: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   20: iconst_0
    //   21: invokevirtual openFileOutput : (Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   24: astore_0
    //   25: invokestatic newSerializer : ()Lorg/xmlpull/v1/XmlSerializer;
    //   28: astore_2
    //   29: aload_2
    //   30: aload_0
    //   31: aconst_null
    //   32: invokeinterface setOutput : (Ljava/io/OutputStream;Ljava/lang/String;)V
    //   37: aload_2
    //   38: ldc 'UTF-8'
    //   40: getstatic java/lang/Boolean.TRUE : Ljava/lang/Boolean;
    //   43: invokeinterface startDocument : (Ljava/lang/String;Ljava/lang/Boolean;)V
    //   48: aload_2
    //   49: aconst_null
    //   50: ldc 'locales'
    //   52: invokeinterface startTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   57: pop
    //   58: aload_2
    //   59: aconst_null
    //   60: ldc 'application_locales'
    //   62: aload_1
    //   63: invokeinterface attribute : (Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   68: pop
    //   69: aload_2
    //   70: aconst_null
    //   71: ldc 'locales'
    //   73: invokeinterface endTag : (Ljava/lang/String;Ljava/lang/String;)Lorg/xmlpull/v1/XmlSerializer;
    //   78: pop
    //   79: aload_2
    //   80: invokeinterface endDocument : ()V
    //   85: new java/lang/StringBuilder
    //   88: dup
    //   89: invokespecial <init> : ()V
    //   92: astore_2
    //   93: aload_2
    //   94: ldc 'Storing App Locales : app-locales: '
    //   96: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: pop
    //   100: aload_2
    //   101: aload_1
    //   102: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: pop
    //   106: aload_2
    //   107: ldc ' persisted successfully.'
    //   109: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   112: pop
    //   113: aload_0
    //   114: ifnull -> 154
    //   117: aload_0
    //   118: invokevirtual close : ()V
    //   121: return
    //   122: astore_1
    //   123: goto -> 155
    //   126: new java/lang/StringBuilder
    //   129: dup
    //   130: invokespecial <init> : ()V
    //   133: astore_2
    //   134: aload_2
    //   135: ldc 'Storing App Locales : Failed to persist app-locales: '
    //   137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: pop
    //   141: aload_2
    //   142: aload_1
    //   143: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   146: pop
    //   147: aload_0
    //   148: ifnull -> 154
    //   151: goto -> 117
    //   154: return
    //   155: aload_0
    //   156: ifnull -> 163
    //   159: aload_0
    //   160: invokevirtual close : ()V
    //   163: aload_1
    //   164: athrow
    //   165: ldc 'Storing App Locales : FileNotFoundException: Cannot open file %s for writing '
    //   167: iconst_1
    //   168: anewarray java/lang/Object
    //   171: dup
    //   172: iconst_0
    //   173: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   175: aastore
    //   176: invokestatic format : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   179: pop
    //   180: return
    //   181: astore_0
    //   182: goto -> 165
    //   185: astore_2
    //   186: goto -> 126
    //   189: astore_0
    //   190: return
    //   191: astore_0
    //   192: goto -> 163
    // Exception table:
    //   from	to	target	type
    //   17	25	181	java/io/FileNotFoundException
    //   29	113	185	java/lang/Exception
    //   29	113	122	finally
    //   117	121	189	java/io/IOException
    //   126	147	122	finally
    //   159	163	191	java/io/IOException
  }
  
  static String b(Context paramContext) {
    // Byte code:
    //   0: ldc ''
    //   2: astore #4
    //   4: aload_0
    //   5: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   7: invokevirtual openFileInput : (Ljava/lang/String;)Ljava/io/FileInputStream;
    //   10: astore #6
    //   12: invokestatic newPullParser : ()Lorg/xmlpull/v1/XmlPullParser;
    //   15: astore #5
    //   17: aload #5
    //   19: aload #6
    //   21: ldc 'UTF-8'
    //   23: invokeinterface setInput : (Ljava/io/InputStream;Ljava/lang/String;)V
    //   28: aload #5
    //   30: invokeinterface getDepth : ()I
    //   35: istore_1
    //   36: aload #5
    //   38: invokeinterface next : ()I
    //   43: istore_2
    //   44: aload #4
    //   46: astore_3
    //   47: iload_2
    //   48: iconst_1
    //   49: if_icmpeq -> 100
    //   52: iload_2
    //   53: iconst_3
    //   54: if_icmpne -> 213
    //   57: aload #4
    //   59: astore_3
    //   60: aload #5
    //   62: invokeinterface getDepth : ()I
    //   67: iload_1
    //   68: if_icmple -> 100
    //   71: goto -> 213
    //   74: aload #5
    //   76: invokeinterface getName : ()Ljava/lang/String;
    //   81: ldc 'locales'
    //   83: invokevirtual equals : (Ljava/lang/Object;)Z
    //   86: ifeq -> 36
    //   89: aload #5
    //   91: aconst_null
    //   92: ldc 'application_locales'
    //   94: invokeinterface getAttributeValue : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   99: astore_3
    //   100: aload_3
    //   101: astore #5
    //   103: aload #6
    //   105: ifnull -> 153
    //   108: aload #6
    //   110: invokevirtual close : ()V
    //   113: aload_3
    //   114: astore #5
    //   116: goto -> 153
    //   119: aload_3
    //   120: astore #5
    //   122: goto -> 153
    //   125: astore_0
    //   126: aload #6
    //   128: ifnull -> 136
    //   131: aload #6
    //   133: invokevirtual close : ()V
    //   136: aload_0
    //   137: athrow
    //   138: aload #4
    //   140: astore #5
    //   142: aload #6
    //   144: ifnull -> 153
    //   147: aload #4
    //   149: astore_3
    //   150: goto -> 108
    //   153: aload #5
    //   155: invokevirtual isEmpty : ()Z
    //   158: ifne -> 186
    //   161: new java/lang/StringBuilder
    //   164: dup
    //   165: invokespecial <init> : ()V
    //   168: astore_0
    //   169: aload_0
    //   170: ldc 'Reading app Locales : Locales read from file: androidx.appcompat.app.AppCompatDelegate.application_locales_record_file , appLocales: '
    //   172: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   175: pop
    //   176: aload_0
    //   177: aload #5
    //   179: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   182: pop
    //   183: aload #5
    //   185: areturn
    //   186: aload_0
    //   187: ldc 'androidx.appcompat.app.AppCompatDelegate.application_locales_record_file'
    //   189: invokevirtual deleteFile : (Ljava/lang/String;)Z
    //   192: pop
    //   193: aload #5
    //   195: areturn
    //   196: astore_0
    //   197: ldc ''
    //   199: areturn
    //   200: astore_3
    //   201: goto -> 138
    //   204: astore #4
    //   206: goto -> 119
    //   209: astore_3
    //   210: goto -> 136
    //   213: iload_2
    //   214: iconst_3
    //   215: if_icmpeq -> 36
    //   218: iload_2
    //   219: iconst_4
    //   220: if_icmpne -> 74
    //   223: goto -> 36
    // Exception table:
    //   from	to	target	type
    //   4	12	196	java/io/FileNotFoundException
    //   12	36	200	org/xmlpull/v1/XmlPullParserException
    //   12	36	200	java/io/IOException
    //   12	36	125	finally
    //   36	44	200	org/xmlpull/v1/XmlPullParserException
    //   36	44	200	java/io/IOException
    //   36	44	125	finally
    //   60	71	200	org/xmlpull/v1/XmlPullParserException
    //   60	71	200	java/io/IOException
    //   60	71	125	finally
    //   74	100	200	org/xmlpull/v1/XmlPullParserException
    //   74	100	200	java/io/IOException
    //   74	100	125	finally
    //   108	113	204	java/io/IOException
    //   131	136	209	java/io/IOException
  }
  
  static void c(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 33) {
      ComponentName componentName = new ComponentName(paramContext, "androidx.appcompat.app.AppLocalesMetadataHolderService");
      if (paramContext.getPackageManager().getComponentEnabledSetting(componentName) != 1) {
        if (h.k().f()) {
          String str = b(paramContext);
          Object object = paramContext.getSystemService("locale");
          if (object != null)
            h.b.b(object, h.a.a(str)); 
        } 
        paramContext.getPackageManager().setComponentEnabledSetting(componentName, 1, 1);
      } 
    } 
  }
  
  static class a implements Executor {
    private final Object g = new Object();
    
    final Queue<Runnable> h = new ArrayDeque<Runnable>();
    
    final Executor i;
    
    Runnable j;
    
    a(Executor param1Executor) {
      this.i = param1Executor;
    }
    
    protected void c() {
      synchronized (this.g) {
        Runnable runnable = this.h.poll();
        this.j = runnable;
        if (runnable != null)
          this.i.execute(runnable); 
        return;
      } 
    }
    
    public void execute(Runnable param1Runnable) {
      synchronized (this.g) {
        this.h.add(new w(this, param1Runnable));
        if (this.j == null)
          c(); 
        return;
      } 
    }
  }
  
  static class b implements Executor {
    public void execute(Runnable param1Runnable) {
      (new Thread(param1Runnable)).start();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */