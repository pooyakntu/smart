package androidx.appcompat.app;

import android.app.Dialog;
import android.os.Bundle;
import androidx.fragment.app.d;

public class t extends d {
  public Dialog onCreateDialog(Bundle paramBundle) {
    return (Dialog)new s(getContext(), getTheme());
  }
  
  public void setupDialog(Dialog paramDialog, int paramInt) {
    if (paramDialog instanceof s) {
      s s = (s)paramDialog;
      if (paramInt != 1 && paramInt != 2) {
        if (paramInt != 3)
          return; 
        paramDialog.getWindow().addFlags(24);
      } 
      s.g(1);
      return;
    } 
    super.setupDialog(paramDialog, paramInt);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */