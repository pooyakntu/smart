package androidx.appcompat.app;

import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

public final class v extends Service {
  public static ServiceInfo a(Context paramContext) throws PackageManager.NameNotFoundException {
    char c;
    if (Build.VERSION.SDK_INT >= 24) {
      c = a.a() | 0x80;
    } else {
      c = 'ʀ';
    } 
    return paramContext.getPackageManager().getServiceInfo(new ComponentName(paramContext, v.class), c);
  }
  
  public IBinder onBind(Intent paramIntent) {
    throw new UnsupportedOperationException();
  }
  
  private static class a {
    static int a() {
      return 512;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\v.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */