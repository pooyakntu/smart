package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h3;
import androidx.core.os.g;
import java.lang.ref.WeakReference;
import java.util.Iterator;

public abstract class h {
  static x.a g = new x.a(new x.b());
  
  private static int h = -100;
  
  private static g i = null;
  
  private static g j = null;
  
  private static Boolean k = null;
  
  private static boolean l = false;
  
  private static final androidx.collection.b<WeakReference<h>> m = new androidx.collection.b();
  
  private static final Object n = new Object();
  
  private static final Object o = new Object();
  
  static void F(h paramh) {
    synchronized (n) {
      G(paramh);
      return;
    } 
  }
  
  private static void G(h paramh) {
    synchronized (n) {
      Iterator<WeakReference<h>> iterator = m.iterator();
      while (iterator.hasNext()) {
        h h1 = ((WeakReference<h>)iterator.next()).get();
        if (h1 == paramh || h1 == null)
          iterator.remove(); 
      } 
      return;
    } 
  }
  
  public static void I(boolean paramBoolean) {
    h3.c(paramBoolean);
  }
  
  static void R(Context paramContext) {
    if (!v(paramContext))
      return; 
    if (androidx.core.os.a.c()) {
      if (!l) {
        g.execute(new f(paramContext));
        return;
      } 
    } else {
      synchronized (o) {
        g g1 = i;
        if (g1 == null) {
          if (j == null)
            j = g.c(x.b(paramContext)); 
          if (j.f())
            return; 
          i = j;
        } else if (!g1.equals(j)) {
          g1 = i;
          j = g1;
          x.a(paramContext, g1.h());
        } 
        return;
      } 
    } 
  }
  
  static void d(h paramh) {
    synchronized (n) {
      G(paramh);
      m.add(new WeakReference<h>(paramh));
      return;
    } 
  }
  
  public static h h(Activity paramActivity, e parame) {
    return new i(paramActivity, parame);
  }
  
  public static h i(Dialog paramDialog, e parame) {
    return new i(paramDialog, parame);
  }
  
  public static g k() {
    if (androidx.core.os.a.c()) {
      Object object = p();
      if (object != null)
        return g.i(b.a(object)); 
    } else {
      g g1 = i;
      if (g1 != null)
        return g1; 
    } 
    return g.e();
  }
  
  public static int m() {
    return h;
  }
  
  static Object p() {
    Iterator<WeakReference<h>> iterator = m.iterator();
    while (iterator.hasNext()) {
      h h1 = ((WeakReference<h>)iterator.next()).get();
      if (h1 != null) {
        Context context = h1.l();
        if (context != null)
          return context.getSystemService("locale"); 
      } 
    } 
    return null;
  }
  
  static g r() {
    return i;
  }
  
  static boolean v(Context paramContext) {
    if (k == null)
      try {
        Bundle bundle = (v.a(paramContext)).metaData;
        if (bundle != null)
          k = Boolean.valueOf(bundle.getBoolean("autoStoreLocales")); 
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        k = Boolean.FALSE;
      }  
    return k.booleanValue();
  }
  
  public abstract void A(Bundle paramBundle);
  
  public abstract void B();
  
  public abstract void C(Bundle paramBundle);
  
  public abstract void D();
  
  public abstract void E();
  
  public abstract boolean H(int paramInt);
  
  public abstract void J(int paramInt);
  
  public abstract void K(View paramView);
  
  public abstract void L(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  public void M(OnBackInvokedDispatcher paramOnBackInvokedDispatcher) {}
  
  public abstract void N(Toolbar paramToolbar);
  
  public void O(int paramInt) {}
  
  public abstract void P(CharSequence paramCharSequence);
  
  public abstract androidx.appcompat.view.b Q(androidx.appcompat.view.b.a parama);
  
  public abstract void e(View paramView, ViewGroup.LayoutParams paramLayoutParams);
  
  @Deprecated
  public void f(Context paramContext) {}
  
  public Context g(Context paramContext) {
    f(paramContext);
    return paramContext;
  }
  
  public abstract <T extends View> T j(int paramInt);
  
  public Context l() {
    return null;
  }
  
  public abstract b n();
  
  public int o() {
    return -100;
  }
  
  public abstract MenuInflater q();
  
  public abstract a s();
  
  public abstract void t();
  
  public abstract void u();
  
  public abstract void x(Configuration paramConfiguration);
  
  public abstract void y(Bundle paramBundle);
  
  public abstract void z();
  
  static class a {
    static LocaleList a(String param1String) {
      return g.a(param1String);
    }
  }
  
  static class b {
    static LocaleList a(Object param1Object) {
      return ((LocaleManager)param1Object).getApplicationLocales();
    }
    
    static void b(Object param1Object, LocaleList param1LocaleList) {
      ((LocaleManager)param1Object).setApplicationLocales(param1LocaleList);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */