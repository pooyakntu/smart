package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import androidx.core.content.i;
import java.util.Calendar;

class d0 {
  private static d0 d;
  
  private final Context a;
  
  private final LocationManager b;
  
  private final a c = new a();
  
  d0(Context paramContext, LocationManager paramLocationManager) {
    this.a = paramContext;
    this.b = paramLocationManager;
  }
  
  static d0 a(Context paramContext) {
    if (d == null) {
      paramContext = paramContext.getApplicationContext();
      d = new d0(paramContext, (LocationManager)paramContext.getSystemService("location"));
    } 
    return d;
  }
  
  @SuppressLint({"MissingPermission"})
  private Location b() {
    Location location1;
    int i = i.b(this.a, "android.permission.ACCESS_COARSE_LOCATION");
    Location location2 = null;
    if (i == 0) {
      location1 = c("network");
    } else {
      location1 = null;
    } 
    if (i.b(this.a, "android.permission.ACCESS_FINE_LOCATION") == 0)
      location2 = c("gps"); 
    if (location2 != null && location1 != null) {
      Location location = location1;
      if (location2.getTime() > location1.getTime())
        location = location2; 
      return location;
    } 
    if (location2 != null)
      location1 = location2; 
    return location1;
  }
  
  private Location c(String paramString) {
    try {
      if (this.b.isProviderEnabled(paramString))
        return this.b.getLastKnownLocation(paramString); 
    } catch (Exception exception) {}
    return null;
  }
  
  private boolean e() {
    return (this.c.b > System.currentTimeMillis());
  }
  
  private void f(Location paramLocation) {
    boolean bool;
    a a1 = this.c;
    long l1 = System.currentTimeMillis();
    c0 c0 = c0.b();
    c0.a(l1 - 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    c0.a(l1, paramLocation.getLatitude(), paramLocation.getLongitude());
    if (c0.c == 1) {
      bool = true;
    } else {
      bool = false;
    } 
    long l2 = c0.b;
    long l3 = c0.a;
    c0.a(l1 + 86400000L, paramLocation.getLatitude(), paramLocation.getLongitude());
    long l4 = c0.b;
    if (l2 == -1L || l3 == -1L) {
      l1 = 43200000L + l1;
    } else {
      if (l1 > l3) {
        l1 = l4 + 0L;
      } else if (l1 > l2) {
        l1 = l3 + 0L;
      } else {
        l1 = l2 + 0L;
      } 
      l1 += 60000L;
    } 
    a1.a = bool;
    a1.b = l1;
  }
  
  boolean d() {
    a a1 = this.c;
    if (e())
      return a1.a; 
    Location location = b();
    if (location != null) {
      f(location);
      return a1.a;
    } 
    int i = Calendar.getInstance().get(11);
    return (i < 6 || i >= 22);
  }
  
  private static class a {
    boolean a;
    
    long b;
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\d0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */