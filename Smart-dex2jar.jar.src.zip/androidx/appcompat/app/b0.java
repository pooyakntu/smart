package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.view.menu.m;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.a3;
import androidx.appcompat.widget.s1;
import androidx.core.util.h;
import androidx.core.view.e1;
import java.util.ArrayList;

class b0 extends a {
  final s1 a;
  
  final Window.Callback b;
  
  final i.g c;
  
  boolean d;
  
  private boolean e;
  
  private boolean f;
  
  private ArrayList<a.b> g = new ArrayList<a.b>();
  
  private final Runnable h = new a(this);
  
  private final Toolbar.h i;
  
  b0(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    b b = new b(this);
    this.i = b;
    h.g(paramToolbar);
    a3 a3 = new a3(paramToolbar, false);
    this.a = (s1)a3;
    this.b = (Window.Callback)h.g(paramCallback);
    a3.setWindowCallback(paramCallback);
    paramToolbar.setOnMenuItemClickListener(b);
    a3.setWindowTitle(paramCharSequence);
    this.c = new e(this);
  }
  
  private Menu w() {
    if (!this.e) {
      this.a.p(new c(this), new d(this));
      this.e = true;
    } 
    return this.a.l();
  }
  
  public boolean g() {
    return this.a.f();
  }
  
  public boolean h() {
    if (this.a.j()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void i(boolean paramBoolean) {
    if (paramBoolean == this.f)
      return; 
    this.f = paramBoolean;
    int j = this.g.size();
    for (int i = 0; i < j; i++)
      ((a.b)this.g.get(i)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public int j() {
    return this.a.s();
  }
  
  public Context k() {
    return this.a.getContext();
  }
  
  public boolean l() {
    this.a.q().removeCallbacks(this.h);
    e1.o0((View)this.a.q(), this.h);
    return true;
  }
  
  public void m(Configuration paramConfiguration) {
    super.m(paramConfiguration);
  }
  
  void n() {
    this.a.q().removeCallbacks(this.h);
  }
  
  public boolean o(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = w();
    if (menu != null) {
      if (paramKeyEvent != null) {
        i = paramKeyEvent.getDeviceId();
      } else {
        i = -1;
      } 
      int i = KeyCharacterMap.load(i).getKeyboardType();
      boolean bool = true;
      if (i == 1)
        bool = false; 
      menu.setQwertyMode(bool);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean p(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      q(); 
    return true;
  }
  
  public boolean q() {
    return this.a.g();
  }
  
  public void r(boolean paramBoolean) {}
  
  public void s(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    y(bool, 4);
  }
  
  public void t(boolean paramBoolean) {}
  
  public void u(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  void x() {
    g g1;
    null = w();
    if (null instanceof g) {
      g1 = (g)null;
    } else {
      g1 = null;
    } 
    if (g1 != null)
      g1.d0(); 
    try {
      null.clear();
      if (!this.b.onCreatePanelMenu(0, null) || !this.b.onPreparePanel(0, null, null))
        null.clear(); 
      return;
    } finally {
      if (g1 != null)
        g1.c0(); 
    } 
  }
  
  public void y(int paramInt1, int paramInt2) {
    int i = this.a.s();
    this.a.k(paramInt1 & paramInt2 | paramInt2 & i);
  }
  
  class a implements Runnable {
    a(b0 this$0) {}
    
    public void run() {
      this.g.x();
    }
  }
  
  class b implements Toolbar.h {
    b(b0 this$0) {}
    
    public boolean onMenuItemClick(MenuItem param1MenuItem) {
      return this.a.b.onMenuItemSelected(0, param1MenuItem);
    }
  }
  
  private final class c implements m.a {
    private boolean g;
    
    c(b0 this$0) {}
    
    public void c(g param1g, boolean param1Boolean) {
      if (this.g)
        return; 
      this.g = true;
      this.h.a.h();
      this.h.b.onPanelClosed(108, (Menu)param1g);
      this.g = false;
    }
    
    public boolean d(g param1g) {
      this.h.b.onMenuOpened(108, (Menu)param1g);
      return true;
    }
  }
  
  private final class d implements g.a {
    d(b0 this$0) {}
    
    public boolean a(g param1g, MenuItem param1MenuItem) {
      return false;
    }
    
    public void b(g param1g) {
      if (this.g.a.b()) {
        this.g.b.onPanelClosed(108, (Menu)param1g);
        return;
      } 
      if (this.g.b.onPreparePanel(0, null, (Menu)param1g))
        this.g.b.onMenuOpened(108, (Menu)param1g); 
    }
  }
  
  private class e implements i.g {
    e(b0 this$0) {}
    
    public boolean a(int param1Int) {
      if (param1Int == 0) {
        b0 b01 = this.a;
        if (!b01.d) {
          b01.a.c();
          this.a.d = true;
        } 
      } 
      return false;
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.getContext()) : null;
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\b0.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */