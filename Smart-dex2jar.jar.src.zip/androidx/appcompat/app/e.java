package androidx.appcompat.app;

import androidx.appcompat.view.b;

public interface e {
  void onSupportActionModeFinished(b paramb);
  
  void onSupportActionModeStarted(b paramb);
  
  b onWindowStartingSupportActionMode(b.a parama);
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */