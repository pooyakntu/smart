package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.l;
import androidx.activity.n;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.h3;
import androidx.core.app.p1;
import androidx.core.app.q;
import androidx.core.os.g;
import androidx.fragment.app.e;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ViewModelStoreOwner;
import androidx.lifecycle.ViewTreeLifecycleOwner;
import androidx.lifecycle.ViewTreeViewModelStoreOwner;
import p0.e;

public class d extends e implements e, p1.a {
  private static final String DELEGATE_TAG = "androidx:appcompat";
  
  private h mDelegate;
  
  private Resources mResources;
  
  public d() {
    initDelegate();
  }
  
  public d(int paramInt) {
    super(paramInt);
    initDelegate();
  }
  
  private void initDelegate() {
    getSavedStateRegistry().h("androidx:appcompat", new a(this));
    addOnContextAvailableListener(new b(this));
  }
  
  private void initViewTreeOwners() {
    ViewTreeLifecycleOwner.set(getWindow().getDecorView(), (LifecycleOwner)this);
    ViewTreeViewModelStoreOwner.set(getWindow().getDecorView(), (ViewModelStoreOwner)this);
    e.a(getWindow().getDecorView(), (p0.d)this);
    n.a(getWindow().getDecorView(), (l)this);
  }
  
  private boolean performMenuItemShortcut(KeyEvent paramKeyEvent) {
    if (Build.VERSION.SDK_INT < 26 && !paramKeyEvent.isCtrlPressed() && !KeyEvent.metaStateHasNoModifiers(paramKeyEvent.getMetaState()) && paramKeyEvent.getRepeatCount() == 0 && !KeyEvent.isModifierKey(paramKeyEvent.getKeyCode())) {
      Window window = getWindow();
      if (window != null && window.getDecorView() != null && window.getDecorView().dispatchKeyShortcutEvent(paramKeyEvent))
        return true; 
    } 
    return false;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().e(paramView, paramLayoutParams);
  }
  
  protected void attachBaseContext(Context paramContext) {
    super.attachBaseContext(getDelegate().g(paramContext));
  }
  
  public void closeOptionsMenu() {
    a a1 = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.g()))
      super.closeOptionsMenu(); 
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    a a1 = getSupportActionBar();
    return (i == 82 && a1 != null && a1.p(paramKeyEvent)) ? true : super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return getDelegate().j(paramInt);
  }
  
  public h getDelegate() {
    if (this.mDelegate == null)
      this.mDelegate = h.h((Activity)this, this); 
    return this.mDelegate;
  }
  
  public b getDrawerToggleDelegate() {
    return getDelegate().n();
  }
  
  public MenuInflater getMenuInflater() {
    return getDelegate().q();
  }
  
  public Resources getResources() {
    if (this.mResources == null && h3.d())
      this.mResources = (Resources)new h3((Context)this, super.getResources()); 
    Resources resources2 = this.mResources;
    Resources resources1 = resources2;
    if (resources2 == null)
      resources1 = super.getResources(); 
    return resources1;
  }
  
  public a getSupportActionBar() {
    return getDelegate().s();
  }
  
  public Intent getSupportParentActivityIntent() {
    return q.a((Activity)this);
  }
  
  public void invalidateOptionsMenu() {
    getDelegate().u();
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    getDelegate().x(paramConfiguration);
    if (this.mResources != null) {
      paramConfiguration = super.getResources().getConfiguration();
      DisplayMetrics displayMetrics = super.getResources().getDisplayMetrics();
      this.mResources.updateConfiguration(paramConfiguration, displayMetrics);
    } 
  }
  
  public void onContentChanged() {
    onSupportContentChanged();
  }
  
  public void onCreateSupportNavigateUpTaskStack(p1 paramp1) {
    paramp1.b((Activity)this);
  }
  
  protected void onDestroy() {
    super.onDestroy();
    getDelegate().z();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return performMenuItemShortcut(paramKeyEvent) ? true : super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onLocalesChanged(g paramg) {}
  
  public final boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    if (super.onMenuItemSelected(paramInt, paramMenuItem))
      return true; 
    a a1 = getSupportActionBar();
    return (paramMenuItem.getItemId() == 16908332 && a1 != null && (a1.j() & 0x4) != 0) ? onSupportNavigateUp() : false;
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return super.onMenuOpened(paramInt, paramMenu);
  }
  
  protected void onNightModeChanged(int paramInt) {}
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    super.onPanelClosed(paramInt, paramMenu);
  }
  
  protected void onPostCreate(Bundle paramBundle) {
    super.onPostCreate(paramBundle);
    getDelegate().A(paramBundle);
  }
  
  protected void onPostResume() {
    super.onPostResume();
    getDelegate().B();
  }
  
  public void onPrepareSupportNavigateUpTaskStack(p1 paramp1) {}
  
  protected void onStart() {
    super.onStart();
    getDelegate().D();
  }
  
  protected void onStop() {
    super.onStop();
    getDelegate().E();
  }
  
  public void onSupportActionModeFinished(androidx.appcompat.view.b paramb) {}
  
  public void onSupportActionModeStarted(androidx.appcompat.view.b paramb) {}
  
  @Deprecated
  public void onSupportContentChanged() {}
  
  public boolean onSupportNavigateUp() {
    Intent intent = getSupportParentActivityIntent();
    if (intent != null) {
      if (supportShouldUpRecreateTask(intent)) {
        p1 p1 = p1.d((Context)this);
        onCreateSupportNavigateUpTaskStack(p1);
        onPrepareSupportNavigateUpTaskStack(p1);
        p1.e();
        try {
          androidx.core.app.b.n((Activity)this);
        } catch (IllegalStateException illegalStateException) {
          finish();
        } 
      } else {
        supportNavigateUpTo((Intent)illegalStateException);
      } 
      return true;
    } 
    return false;
  }
  
  protected void onTitleChanged(CharSequence paramCharSequence, int paramInt) {
    super.onTitleChanged(paramCharSequence, paramInt);
    getDelegate().P(paramCharSequence);
  }
  
  public androidx.appcompat.view.b onWindowStartingSupportActionMode(androidx.appcompat.view.b.a parama) {
    return null;
  }
  
  public void openOptionsMenu() {
    a a1 = getSupportActionBar();
    if (getWindow().hasFeature(0) && (a1 == null || !a1.q()))
      super.openOptionsMenu(); 
  }
  
  public void setContentView(int paramInt) {
    initViewTreeOwners();
    getDelegate().J(paramInt);
  }
  
  public void setContentView(View paramView) {
    initViewTreeOwners();
    getDelegate().K(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    initViewTreeOwners();
    getDelegate().L(paramView, paramLayoutParams);
  }
  
  public void setSupportActionBar(Toolbar paramToolbar) {
    getDelegate().N(paramToolbar);
  }
  
  @Deprecated
  public void setSupportProgress(int paramInt) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminate(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarIndeterminateVisibility(boolean paramBoolean) {}
  
  @Deprecated
  public void setSupportProgressBarVisibility(boolean paramBoolean) {}
  
  public void setTheme(int paramInt) {
    super.setTheme(paramInt);
    getDelegate().O(paramInt);
  }
  
  public androidx.appcompat.view.b startSupportActionMode(androidx.appcompat.view.b.a parama) {
    return getDelegate().Q(parama);
  }
  
  public void supportInvalidateOptionsMenu() {
    getDelegate().u();
  }
  
  public void supportNavigateUpTo(Intent paramIntent) {
    q.e((Activity)this, paramIntent);
  }
  
  public boolean supportRequestWindowFeature(int paramInt) {
    return getDelegate().H(paramInt);
  }
  
  public boolean supportShouldUpRecreateTask(Intent paramIntent) {
    return q.f((Activity)this, paramIntent);
  }
  
  class a implements androidx.savedstate.a.c {
    a(d this$0) {}
    
    public Bundle saveState() {
      Bundle bundle = new Bundle();
      this.a.getDelegate().C(bundle);
      return bundle;
    }
  }
  
  class b implements d.b {
    b(d this$0) {}
    
    public void a(Context param1Context) {
      h h = this.a.getDelegate();
      h.t();
      h.y(this.a.getSavedStateRegistry().b("androidx:appcompat"));
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */