package androidx.appcompat.app;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.activity.f;
import androidx.appcompat.view.b;
import androidx.core.view.t;
import f.a;

public class s extends f implements e {
  private h i;
  
  private final t.a j = new r(this);
  
  public s(Context paramContext, int paramInt) {
    super(paramContext, e(paramContext, paramInt));
    h h1 = d();
    h1.O(e(paramContext, paramInt));
    h1.y(null);
  }
  
  private static int e(Context paramContext, int paramInt) {
    int i = paramInt;
    if (paramInt == 0) {
      TypedValue typedValue = new TypedValue();
      paramContext.getTheme().resolveAttribute(a.z, typedValue, true);
      i = typedValue.resourceId;
    } 
    return i;
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    d().e(paramView, paramLayoutParams);
  }
  
  public h d() {
    if (this.i == null)
      this.i = h.i((Dialog)this, this); 
    return this.i;
  }
  
  public void dismiss() {
    super.dismiss();
    d().z();
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    View view = getWindow().getDecorView();
    return t.e(this.j, view, (Window.Callback)this, paramKeyEvent);
  }
  
  boolean f(KeyEvent paramKeyEvent) {
    return super.dispatchKeyEvent(paramKeyEvent);
  }
  
  public <T extends View> T findViewById(int paramInt) {
    return d().j(paramInt);
  }
  
  public boolean g(int paramInt) {
    return d().H(paramInt);
  }
  
  public void invalidateOptionsMenu() {
    d().u();
  }
  
  protected void onCreate(Bundle paramBundle) {
    d().t();
    super.onCreate(paramBundle);
    d().y(paramBundle);
  }
  
  protected void onStop() {
    super.onStop();
    d().E();
  }
  
  public void onSupportActionModeFinished(b paramb) {}
  
  public void onSupportActionModeStarted(b paramb) {}
  
  public b onWindowStartingSupportActionMode(b.a parama) {
    return null;
  }
  
  public void setContentView(int paramInt) {
    d().J(paramInt);
  }
  
  public void setContentView(View paramView) {
    d().K(paramView);
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    d().L(paramView, paramLayoutParams);
  }
  
  public void setTitle(int paramInt) {
    super.setTitle(paramInt);
    d().P(getContext().getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    super.setTitle(paramCharSequence);
    d().P(paramCharSequence);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\app\s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */