package androidx.appcompat.view.menu;

import android.content.DialogInterface;
import android.os.IBinder;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.appcompat.app.c;
import f.g;

class h implements DialogInterface.OnKeyListener, DialogInterface.OnClickListener, DialogInterface.OnDismissListener, m.a {
  private g g;
  
  private c h;
  
  e i;
  
  private m.a j;
  
  public h(g paramg) {
    this.g = paramg;
  }
  
  public void a() {
    c c1 = this.h;
    if (c1 != null)
      c1.dismiss(); 
  }
  
  public void b(IBinder paramIBinder) {
    g g1 = this.g;
    c.a a1 = new c.a(g1.u());
    e e1 = new e(a1.b(), g.j);
    this.i = e1;
    e1.h(this);
    this.g.b(this.i);
    a1.c(this.i.a(), this);
    View view = g1.y();
    if (view != null) {
      a1.d(view);
    } else {
      a1.e(g1.w()).h(g1.x());
    } 
    a1.f(this);
    c c1 = a1.a();
    this.h = c1;
    c1.setOnDismissListener(this);
    WindowManager.LayoutParams layoutParams = this.h.getWindow().getAttributes();
    layoutParams.type = 1003;
    if (paramIBinder != null)
      layoutParams.token = paramIBinder; 
    layoutParams.flags |= 0x20000;
    this.h.show();
  }
  
  public void c(g paramg, boolean paramBoolean) {
    if (paramBoolean || paramg == this.g)
      a(); 
    m.a a1 = this.j;
    if (a1 != null)
      a1.c(paramg, paramBoolean); 
  }
  
  public boolean d(g paramg) {
    m.a a1 = this.j;
    return (a1 != null) ? a1.d(paramg) : false;
  }
  
  public void onClick(DialogInterface paramDialogInterface, int paramInt) {
    this.g.L((MenuItem)this.i.a().getItem(paramInt), 0);
  }
  
  public void onDismiss(DialogInterface paramDialogInterface) {
    this.i.c(this.g, true);
  }
  
  public boolean onKey(DialogInterface paramDialogInterface, int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 82 || paramInt == 4) {
      KeyEvent.DispatcherState dispatcherState;
      if (paramKeyEvent.getAction() == 0 && paramKeyEvent.getRepeatCount() == 0) {
        Window window = this.h.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            dispatcherState = view.getKeyDispatcherState();
            if (dispatcherState != null) {
              dispatcherState.startTracking(paramKeyEvent, this);
              return true;
            } 
          } 
        } 
      } else if (paramKeyEvent.getAction() == 1 && !paramKeyEvent.isCanceled()) {
        Window window = this.h.getWindow();
        if (window != null) {
          View view = window.getDecorView();
          if (view != null) {
            KeyEvent.DispatcherState dispatcherState1 = view.getKeyDispatcherState();
            if (dispatcherState1 != null && dispatcherState1.isTracking(paramKeyEvent)) {
              this.g.e(true);
              dispatcherState.dismiss();
              return true;
            } 
          } 
        } 
      } 
    } 
    return this.g.performShortcut(paramInt, paramKeyEvent, 0);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */