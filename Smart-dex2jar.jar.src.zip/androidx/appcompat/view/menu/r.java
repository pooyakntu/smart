package androidx.appcompat.view.menu;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

public class r extends g implements SubMenu {
  private g B;
  
  private i C;
  
  public r(Context paramContext, g paramg, i parami) {
    super(paramContext);
    this.B = paramg;
    this.C = parami;
  }
  
  public g D() {
    return this.B.D();
  }
  
  public boolean F() {
    return this.B.F();
  }
  
  public boolean G() {
    return this.B.G();
  }
  
  public boolean H() {
    return this.B.H();
  }
  
  public void R(g.a parama) {
    this.B.R(parama);
  }
  
  public Menu e0() {
    return (Menu)this.B;
  }
  
  public boolean f(i parami) {
    return this.B.f(parami);
  }
  
  public MenuItem getItem() {
    return (MenuItem)this.C;
  }
  
  boolean h(g paramg, MenuItem paramMenuItem) {
    return (super.h(paramg, paramMenuItem) || this.B.h(paramg, paramMenuItem));
  }
  
  public boolean k(i parami) {
    return this.B.k(parami);
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.B.setGroupDividerEnabled(paramBoolean);
  }
  
  public SubMenu setHeaderIcon(int paramInt) {
    return (SubMenu)U(paramInt);
  }
  
  public SubMenu setHeaderIcon(Drawable paramDrawable) {
    return (SubMenu)V(paramDrawable);
  }
  
  public SubMenu setHeaderTitle(int paramInt) {
    return (SubMenu)X(paramInt);
  }
  
  public SubMenu setHeaderTitle(CharSequence paramCharSequence) {
    return (SubMenu)Y(paramCharSequence);
  }
  
  public SubMenu setHeaderView(View paramView) {
    return (SubMenu)Z(paramView);
  }
  
  public SubMenu setIcon(int paramInt) {
    this.C.setIcon(paramInt);
    return this;
  }
  
  public SubMenu setIcon(Drawable paramDrawable) {
    this.C.setIcon(paramDrawable);
    return this;
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.B.setQwertyMode(paramBoolean);
  }
  
  public String t() {
    boolean bool;
    i i1 = this.C;
    if (i1 != null) {
      bool = i1.getItemId();
    } else {
      bool = false;
    } 
    if (!bool)
      return null; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(super.t());
    stringBuilder.append(":");
    stringBuilder.append(bool);
    return stringBuilder.toString();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */