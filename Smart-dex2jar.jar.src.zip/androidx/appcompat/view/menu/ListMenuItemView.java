package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import androidx.appcompat.widget.x2;
import androidx.core.view.e1;
import f.a;
import f.f;
import f.g;
import f.j;

public class ListMenuItemView extends LinearLayout implements n.a, AbsListView.SelectionBoundsAdjuster {
  private i g;
  
  private ImageView h;
  
  private RadioButton i;
  
  private TextView j;
  
  private CheckBox k;
  
  private TextView l;
  
  private ImageView m;
  
  private ImageView n;
  
  private LinearLayout o;
  
  private Drawable p;
  
  private int q;
  
  private Context r;
  
  private boolean s;
  
  private Drawable t;
  
  private boolean u;
  
  private LayoutInflater v;
  
  private boolean w;
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, a.D);
  }
  
  public ListMenuItemView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet);
    x2 x2 = x2.v(getContext(), paramAttributeSet, j.T1, paramInt, 0);
    this.p = x2.g(j.V1);
    this.q = x2.n(j.U1, -1);
    this.s = x2.a(j.W1, false);
    this.r = paramContext;
    this.t = x2.g(j.X1);
    Resources.Theme theme = paramContext.getTheme();
    paramInt = a.A;
    TypedArray typedArray = theme.obtainStyledAttributes(null, new int[] { 16843049 }, paramInt, 0);
    this.u = typedArray.hasValue(0);
    x2.w();
    typedArray.recycle();
  }
  
  private void a(View paramView) {
    b(paramView, -1);
  }
  
  private void b(View paramView, int paramInt) {
    LinearLayout linearLayout = this.o;
    if (linearLayout != null) {
      linearLayout.addView(paramView, paramInt);
      return;
    } 
    addView(paramView, paramInt);
  }
  
  private void e() {
    CheckBox checkBox = (CheckBox)getInflater().inflate(g.h, (ViewGroup)this, false);
    this.k = checkBox;
    a((View)checkBox);
  }
  
  private void f() {
    ImageView imageView = (ImageView)getInflater().inflate(g.i, (ViewGroup)this, false);
    this.h = imageView;
    b((View)imageView, 0);
  }
  
  private void g() {
    RadioButton radioButton = (RadioButton)getInflater().inflate(g.k, (ViewGroup)this, false);
    this.i = radioButton;
    a((View)radioButton);
  }
  
  private LayoutInflater getInflater() {
    if (this.v == null)
      this.v = LayoutInflater.from(getContext()); 
    return this.v;
  }
  
  private void setSubMenuArrowVisible(boolean paramBoolean) {
    ImageView imageView = this.m;
    if (imageView != null) {
      byte b;
      if (paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void adjustListItemSelectionBounds(Rect paramRect) {
    ImageView imageView = this.n;
    if (imageView != null && imageView.getVisibility() == 0) {
      LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)this.n.getLayoutParams();
      paramRect.top += this.n.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    } 
  }
  
  public boolean c() {
    return false;
  }
  
  public void d(i parami, int paramInt) {
    this.g = parami;
    if (parami.isVisible()) {
      paramInt = 0;
    } else {
      paramInt = 8;
    } 
    setVisibility(paramInt);
    setTitle(parami.i(this));
    setCheckable(parami.isCheckable());
    h(parami.A(), parami.g());
    setIcon(parami.getIcon());
    setEnabled(parami.isEnabled());
    setSubMenuArrowVisible(parami.hasSubMenu());
    setContentDescription(parami.getContentDescription());
  }
  
  public i getItemData() {
    return this.g;
  }
  
  public void h(boolean paramBoolean, char paramChar) {
    if (paramBoolean && this.g.A()) {
      paramChar = Character.MIN_VALUE;
    } else {
      paramChar = '\b';
    } 
    if (paramChar == '\000')
      this.l.setText(this.g.h()); 
    if (this.l.getVisibility() != paramChar)
      this.l.setVisibility(paramChar); 
  }
  
  protected void onFinishInflate() {
    super.onFinishInflate();
    e1.B0((View)this, this.p);
    TextView textView = (TextView)findViewById(f.M);
    this.j = textView;
    int j = this.q;
    if (j != -1)
      textView.setTextAppearance(this.r, j); 
    this.l = (TextView)findViewById(f.F);
    ImageView imageView = (ImageView)findViewById(f.I);
    this.m = imageView;
    if (imageView != null)
      imageView.setImageDrawable(this.t); 
    this.n = (ImageView)findViewById(f.r);
    this.o = (LinearLayout)findViewById(f.l);
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (this.h != null && this.s) {
      ViewGroup.LayoutParams layoutParams = getLayoutParams();
      LinearLayout.LayoutParams layoutParams1 = (LinearLayout.LayoutParams)this.h.getLayoutParams();
      int j = layoutParams.height;
      if (j > 0 && layoutParams1.width <= 0)
        layoutParams1.width = j; 
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  public void setCheckable(boolean paramBoolean) {
    CheckBox checkBox;
    RadioButton radioButton;
    if (!paramBoolean && this.i == null && this.k == null)
      return; 
    if (this.g.m()) {
      if (this.i == null)
        g(); 
      RadioButton radioButton1 = this.i;
      CheckBox checkBox1 = this.k;
    } else {
      if (this.k == null)
        e(); 
      checkBox = this.k;
      radioButton = this.i;
    } 
    if (paramBoolean) {
      checkBox.setChecked(this.g.isChecked());
      if (checkBox.getVisibility() != 0)
        checkBox.setVisibility(0); 
      if (radioButton != null && radioButton.getVisibility() != 8) {
        radioButton.setVisibility(8);
        return;
      } 
    } else {
      checkBox = this.k;
      if (checkBox != null)
        checkBox.setVisibility(8); 
      RadioButton radioButton1 = this.i;
      if (radioButton1 != null)
        radioButton1.setVisibility(8); 
    } 
  }
  
  public void setChecked(boolean paramBoolean) {
    CheckBox checkBox;
    if (this.g.m()) {
      if (this.i == null)
        g(); 
      RadioButton radioButton = this.i;
    } else {
      if (this.k == null)
        e(); 
      checkBox = this.k;
    } 
    checkBox.setChecked(paramBoolean);
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.w = paramBoolean;
    this.s = paramBoolean;
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    ImageView imageView = this.n;
    if (imageView != null) {
      byte b;
      if (!this.u && paramBoolean) {
        b = 0;
      } else {
        b = 8;
      } 
      imageView.setVisibility(b);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    boolean bool;
    if (this.g.z() || this.w) {
      bool = true;
    } else {
      bool = false;
    } 
    if (!bool && !this.s)
      return; 
    ImageView imageView = this.h;
    if (imageView == null && paramDrawable == null && !this.s)
      return; 
    if (imageView == null)
      f(); 
    if (paramDrawable != null || this.s) {
      imageView = this.h;
      if (!bool)
        paramDrawable = null; 
      imageView.setImageDrawable(paramDrawable);
      if (this.h.getVisibility() != 0)
        this.h.setVisibility(0); 
      return;
    } 
    this.h.setVisibility(8);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    if (paramCharSequence != null) {
      this.j.setText(paramCharSequence);
      if (this.j.getVisibility() != 0) {
        this.j.setVisibility(0);
        return;
      } 
    } else if (this.j.getVisibility() != 8) {
      this.j.setVisibility(8);
    } 
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\ListMenuItemView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */