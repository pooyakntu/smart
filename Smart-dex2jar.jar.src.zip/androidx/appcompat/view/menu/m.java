package androidx.appcompat.view.menu;

import android.content.Context;

public interface m {
  void c(g paramg, boolean paramBoolean);
  
  void d(boolean paramBoolean);
  
  boolean e();
  
  boolean f(g paramg, i parami);
  
  boolean g(g paramg, i parami);
  
  void h(a parama);
  
  void i(Context paramContext, g paramg);
  
  boolean k(r paramr);
  
  public static interface a {
    void c(g param1g, boolean param1Boolean);
    
    boolean d(g param1g);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */