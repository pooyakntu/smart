package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

public abstract class b implements m {
  protected Context g;
  
  protected Context h;
  
  protected g i;
  
  protected LayoutInflater j;
  
  protected LayoutInflater k;
  
  private m.a l;
  
  private int m;
  
  private int n;
  
  protected n o;
  
  private int p;
  
  public b(Context paramContext, int paramInt1, int paramInt2) {
    this.g = paramContext;
    this.j = LayoutInflater.from(paramContext);
    this.m = paramInt1;
    this.n = paramInt2;
  }
  
  protected void a(View paramView, int paramInt) {
    ViewGroup viewGroup = (ViewGroup)paramView.getParent();
    if (viewGroup != null)
      viewGroup.removeView(paramView); 
    ((ViewGroup)this.o).addView(paramView, paramInt);
  }
  
  public abstract void b(i parami, n.a parama);
  
  public void c(g paramg, boolean paramBoolean) {
    m.a a1 = this.l;
    if (a1 != null)
      a1.c(paramg, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    ViewGroup viewGroup = (ViewGroup)this.o;
    if (viewGroup == null)
      return; 
    g g1 = this.i;
    int i = 0;
    if (g1 != null) {
      g1.r();
      ArrayList<i> arrayList = this.i.E();
      int k = arrayList.size();
      int j = 0;
      for (i = 0; j < k; i = i1) {
        i i2 = arrayList.get(j);
        int i1 = i;
        if (q(i, i2)) {
          View view1 = viewGroup.getChildAt(i);
          if (view1 instanceof n.a) {
            i i3 = ((n.a)view1).getItemData();
          } else {
            g1 = null;
          } 
          View view2 = n(i2, view1, viewGroup);
          if (i2 != g1) {
            view2.setPressed(false);
            view2.jumpDrawablesToCurrentState();
          } 
          if (view2 != view1)
            a(view2, i); 
          i1 = i + 1;
        } 
        j++;
      } 
    } 
    while (i < viewGroup.getChildCount()) {
      if (!l(viewGroup, i))
        i++; 
    } 
  }
  
  public boolean f(g paramg, i parami) {
    return false;
  }
  
  public boolean g(g paramg, i parami) {
    return false;
  }
  
  public void h(m.a parama) {
    this.l = parama;
  }
  
  public void i(Context paramContext, g paramg) {
    this.h = paramContext;
    this.k = LayoutInflater.from(paramContext);
    this.i = paramg;
  }
  
  public n.a j(ViewGroup paramViewGroup) {
    return (n.a)this.j.inflate(this.n, paramViewGroup, false);
  }
  
  public boolean k(r paramr) {
    m.a a1 = this.l;
    if (a1 != null) {
      g g1;
      if (paramr == null)
        g1 = this.i; 
      return a1.d(g1);
    } 
    return false;
  }
  
  protected boolean l(ViewGroup paramViewGroup, int paramInt) {
    paramViewGroup.removeViewAt(paramInt);
    return true;
  }
  
  public m.a m() {
    return this.l;
  }
  
  public View n(i parami, View paramView, ViewGroup paramViewGroup) {
    n.a a1;
    if (paramView instanceof n.a) {
      a1 = (n.a)paramView;
    } else {
      a1 = j(paramViewGroup);
    } 
    b(parami, a1);
    return (View)a1;
  }
  
  public n o(ViewGroup paramViewGroup) {
    if (this.o == null) {
      n n1 = (n)this.j.inflate(this.m, paramViewGroup, false);
      this.o = n1;
      n1.b(this.i);
      d(true);
    } 
    return this.o;
  }
  
  public void p(int paramInt) {
    this.p = paramInt;
  }
  
  public abstract boolean q(int paramInt, i parami);
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */