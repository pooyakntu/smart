package androidx.appcompat.view.menu;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import androidx.core.view.y2;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import u.a;

public class g implements a {
  private static final int[] A = new int[] { 1, 4, 5, 3, 2, 0 };
  
  private final Context a;
  
  private final Resources b;
  
  private boolean c;
  
  private boolean d;
  
  private a e;
  
  private ArrayList<i> f;
  
  private ArrayList<i> g;
  
  private boolean h;
  
  private ArrayList<i> i;
  
  private ArrayList<i> j;
  
  private boolean k;
  
  private int l = 0;
  
  private ContextMenu.ContextMenuInfo m;
  
  CharSequence n;
  
  Drawable o;
  
  View p;
  
  private boolean q = false;
  
  private boolean r = false;
  
  private boolean s = false;
  
  private boolean t = false;
  
  private boolean u = false;
  
  private ArrayList<i> v = new ArrayList<i>();
  
  private CopyOnWriteArrayList<WeakReference<m>> w = new CopyOnWriteArrayList<WeakReference<m>>();
  
  private i x;
  
  private boolean y = false;
  
  private boolean z;
  
  public g(Context paramContext) {
    this.a = paramContext;
    this.b = paramContext.getResources();
    this.f = new ArrayList<i>();
    this.g = new ArrayList<i>();
    this.h = true;
    this.i = new ArrayList<i>();
    this.j = new ArrayList<i>();
    this.k = true;
    b0(true);
  }
  
  private static int B(int paramInt) {
    int j = (0xFFFF0000 & paramInt) >> 16;
    if (j >= 0) {
      int[] arrayOfInt = A;
      if (j < arrayOfInt.length)
        return paramInt & 0xFFFF | arrayOfInt[j] << 16; 
    } 
    throw new IllegalArgumentException("order does not contain a valid category.");
  }
  
  private void N(int paramInt, boolean paramBoolean) {
    if (paramInt >= 0) {
      if (paramInt >= this.f.size())
        return; 
      this.f.remove(paramInt);
      if (paramBoolean)
        K(true); 
    } 
  }
  
  private void W(int paramInt1, CharSequence paramCharSequence, int paramInt2, Drawable paramDrawable, View paramView) {
    Resources resources = C();
    if (paramView != null) {
      this.p = paramView;
      this.n = null;
      this.o = null;
    } else {
      if (paramInt1 > 0) {
        this.n = resources.getText(paramInt1);
      } else if (paramCharSequence != null) {
        this.n = paramCharSequence;
      } 
      if (paramInt2 > 0) {
        this.o = androidx.core.content.a.e(u(), paramInt2);
      } else if (paramDrawable != null) {
        this.o = paramDrawable;
      } 
      this.p = null;
    } 
    K(false);
  }
  
  private void b0(boolean paramBoolean) {
    if (paramBoolean) {
      int j = (this.b.getConfiguration()).keyboard;
      paramBoolean = true;
      if (j != 1 && y2.f(ViewConfiguration.get(this.a), this.a)) {
        this.d = paramBoolean;
        return;
      } 
    } 
    paramBoolean = false;
    this.d = paramBoolean;
  }
  
  private i g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, CharSequence paramCharSequence, int paramInt5) {
    return new i(this, paramInt1, paramInt2, paramInt3, paramInt4, paramCharSequence, paramInt5);
  }
  
  private void i(boolean paramBoolean) {
    if (this.w.isEmpty())
      return; 
    d0();
    for (WeakReference<m> weakReference : this.w) {
      m m = weakReference.get();
      if (m == null) {
        this.w.remove(weakReference);
        continue;
      } 
      m.d(paramBoolean);
    } 
    c0();
  }
  
  private boolean j(r paramr, m paramm) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    if (paramm != null)
      bool1 = paramm.k(paramr); 
    for (WeakReference<m> weakReference : this.w) {
      m m1 = weakReference.get();
      if (m1 == null) {
        this.w.remove(weakReference);
        continue;
      } 
      if (!bool1)
        bool1 = m1.k(paramr); 
    } 
    return bool1;
  }
  
  private static int n(ArrayList<i> paramArrayList, int paramInt) {
    for (int j = paramArrayList.size() - 1; j >= 0; j--) {
      if (((i)paramArrayList.get(j)).f() <= paramInt)
        return j + 1; 
    } 
    return 0;
  }
  
  boolean A() {
    return this.t;
  }
  
  Resources C() {
    return this.b;
  }
  
  public g D() {
    return this;
  }
  
  public ArrayList<i> E() {
    if (!this.h)
      return this.g; 
    this.g.clear();
    int k = this.f.size();
    for (int j = 0; j < k; j++) {
      i i1 = this.f.get(j);
      if (i1.isVisible())
        this.g.add(i1); 
    } 
    this.h = false;
    this.k = true;
    return this.g;
  }
  
  public boolean F() {
    return this.y;
  }
  
  boolean G() {
    return this.c;
  }
  
  public boolean H() {
    return this.d;
  }
  
  void I(i parami) {
    this.k = true;
    K(true);
  }
  
  void J(i parami) {
    this.h = true;
    K(true);
  }
  
  public void K(boolean paramBoolean) {
    if (!this.q) {
      if (paramBoolean) {
        this.h = true;
        this.k = true;
      } 
      i(paramBoolean);
      return;
    } 
    this.r = true;
    if (paramBoolean)
      this.s = true; 
  }
  
  public boolean L(MenuItem paramMenuItem, int paramInt) {
    return M(paramMenuItem, null, paramInt);
  }
  
  public boolean M(MenuItem paramMenuItem, m paramm, int paramInt) {
    i i1 = (i)paramMenuItem;
    if (i1 != null) {
      boolean bool;
      boolean bool1;
      if (!i1.isEnabled())
        return false; 
      boolean bool2 = i1.k();
      androidx.core.view.b b = i1.b();
      if (b != null && b.a()) {
        bool = true;
      } else {
        bool = false;
      } 
      if (i1.j()) {
        bool2 |= i1.expandActionView();
        bool1 = bool2;
        if (bool2) {
          e(true);
          return bool2;
        } 
      } else {
        if (i1.hasSubMenu() || bool) {
          if ((paramInt & 0x4) == 0)
            e(false); 
          if (!i1.hasSubMenu())
            i1.x(new r(u(), this, i1)); 
          r r = (r)i1.getSubMenu();
          if (bool)
            b.f(r); 
          bool2 |= j(r, paramm);
          boolean bool3 = bool2;
          if (!bool2) {
            e(true);
            bool3 = bool2;
          } 
          return bool3;
        } 
        bool1 = bool2;
        if ((paramInt & 0x1) == 0) {
          e(true);
          return bool2;
        } 
      } 
      return bool1;
    } 
    return false;
  }
  
  public void O(m paramm) {
    for (WeakReference<m> weakReference : this.w) {
      m m1 = weakReference.get();
      if (m1 == null || m1 == paramm)
        this.w.remove(weakReference); 
    } 
  }
  
  public void P(Bundle paramBundle) {
    if (paramBundle == null)
      return; 
    SparseArray sparseArray = paramBundle.getSparseParcelableArray(t());
    int k = size();
    int j;
    for (j = 0; j < k; j++) {
      MenuItem menuItem = getItem(j);
      View view = menuItem.getActionView();
      if (view != null && view.getId() != -1)
        view.restoreHierarchyState(sparseArray); 
      if (menuItem.hasSubMenu())
        ((r)menuItem.getSubMenu()).P(paramBundle); 
    } 
    j = paramBundle.getInt("android:menu:expandedactionview");
    if (j > 0) {
      MenuItem menuItem = findItem(j);
      if (menuItem != null)
        menuItem.expandActionView(); 
    } 
  }
  
  public void Q(Bundle paramBundle) {
    int k = size();
    SparseArray sparseArray = null;
    int j = 0;
    while (j < k) {
      MenuItem menuItem = getItem(j);
      View view = menuItem.getActionView();
      SparseArray sparseArray1 = sparseArray;
      if (view != null) {
        sparseArray1 = sparseArray;
        if (view.getId() != -1) {
          SparseArray sparseArray2 = sparseArray;
          if (sparseArray == null)
            sparseArray2 = new SparseArray(); 
          view.saveHierarchyState(sparseArray2);
          sparseArray1 = sparseArray2;
          if (menuItem.isActionViewExpanded()) {
            paramBundle.putInt("android:menu:expandedactionview", menuItem.getItemId());
            sparseArray1 = sparseArray2;
          } 
        } 
      } 
      if (menuItem.hasSubMenu())
        ((r)menuItem.getSubMenu()).Q(paramBundle); 
      j++;
      sparseArray = sparseArray1;
    } 
    if (sparseArray != null)
      paramBundle.putSparseParcelableArray(t(), sparseArray); 
  }
  
  public void R(a parama) {
    this.e = parama;
  }
  
  public g S(int paramInt) {
    this.l = paramInt;
    return this;
  }
  
  void T(MenuItem paramMenuItem) {
    int k = paramMenuItem.getGroupId();
    int m = this.f.size();
    d0();
    for (int j = 0; j < m; j++) {
      i i1 = this.f.get(j);
      if (i1.getGroupId() == k && i1.m() && i1.isCheckable()) {
        boolean bool;
        if (i1 == paramMenuItem) {
          bool = true;
        } else {
          bool = false;
        } 
        i1.s(bool);
      } 
    } 
    c0();
  }
  
  protected g U(int paramInt) {
    W(0, null, paramInt, null, null);
    return this;
  }
  
  protected g V(Drawable paramDrawable) {
    W(0, null, 0, paramDrawable, null);
    return this;
  }
  
  protected g X(int paramInt) {
    W(paramInt, null, 0, null, null);
    return this;
  }
  
  protected g Y(CharSequence paramCharSequence) {
    W(0, paramCharSequence, 0, null, null);
    return this;
  }
  
  protected g Z(View paramView) {
    W(0, null, 0, null, paramView);
    return this;
  }
  
  protected MenuItem a(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    int j = B(paramInt3);
    i i1 = g(paramInt1, paramInt2, paramInt3, j, paramCharSequence, this.l);
    ContextMenu.ContextMenuInfo contextMenuInfo = this.m;
    if (contextMenuInfo != null)
      i1.v(contextMenuInfo); 
    ArrayList<i> arrayList = this.f;
    arrayList.add(n(arrayList, j), i1);
    K(true);
    return (MenuItem)i1;
  }
  
  public void a0(boolean paramBoolean) {
    this.z = paramBoolean;
  }
  
  public MenuItem add(int paramInt) {
    return a(0, 0, 0, this.b.getString(paramInt));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return a(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public MenuItem add(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    return a(paramInt1, paramInt2, paramInt3, paramCharSequence);
  }
  
  public MenuItem add(CharSequence paramCharSequence) {
    return a(0, 0, 0, paramCharSequence);
  }
  
  public int addIntentOptions(int paramInt1, int paramInt2, int paramInt3, ComponentName paramComponentName, Intent[] paramArrayOfIntent, Intent paramIntent, int paramInt4, MenuItem[] paramArrayOfMenuItem) {
    byte b1;
    PackageManager packageManager = this.a.getPackageManager();
    byte b2 = 0;
    List<ResolveInfo> list = packageManager.queryIntentActivityOptions(paramComponentName, paramArrayOfIntent, paramIntent, 0);
    if (list != null) {
      b1 = list.size();
    } else {
      b1 = 0;
    } 
    int j = b2;
    if ((paramInt4 & 0x1) == 0) {
      removeGroup(paramInt1);
      j = b2;
    } 
    while (j < b1) {
      ResolveInfo resolveInfo = list.get(j);
      paramInt4 = resolveInfo.specificIndex;
      if (paramInt4 < 0) {
        intent = paramIntent;
      } else {
        intent = paramArrayOfIntent[paramInt4];
      } 
      Intent intent = new Intent(intent);
      ActivityInfo activityInfo = resolveInfo.activityInfo;
      intent.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
      MenuItem menuItem = add(paramInt1, paramInt2, paramInt3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent);
      if (paramArrayOfMenuItem != null) {
        paramInt4 = resolveInfo.specificIndex;
        if (paramInt4 >= 0)
          paramArrayOfMenuItem[paramInt4] = menuItem; 
      } 
      j++;
    } 
    return b1;
  }
  
  public SubMenu addSubMenu(int paramInt) {
    return addSubMenu(0, 0, 0, this.b.getString(paramInt));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    return addSubMenu(paramInt1, paramInt2, paramInt3, this.b.getString(paramInt4));
  }
  
  public SubMenu addSubMenu(int paramInt1, int paramInt2, int paramInt3, CharSequence paramCharSequence) {
    i i1 = (i)a(paramInt1, paramInt2, paramInt3, paramCharSequence);
    r r = new r(this.a, this, i1);
    i1.x(r);
    return r;
  }
  
  public SubMenu addSubMenu(CharSequence paramCharSequence) {
    return addSubMenu(0, 0, 0, paramCharSequence);
  }
  
  public void b(m paramm) {
    c(paramm, this.a);
  }
  
  public void c(m paramm, Context paramContext) {
    this.w.add(new WeakReference<m>(paramm));
    paramm.i(paramContext, this);
    this.k = true;
  }
  
  public void c0() {
    this.q = false;
    if (this.r) {
      this.r = false;
      K(this.s);
    } 
  }
  
  public void clear() {
    i i1 = this.x;
    if (i1 != null)
      f(i1); 
    this.f.clear();
    K(true);
  }
  
  public void clearHeader() {
    this.o = null;
    this.n = null;
    this.p = null;
    K(false);
  }
  
  public void close() {
    e(true);
  }
  
  public void d() {
    a a1 = this.e;
    if (a1 != null)
      a1.b(this); 
  }
  
  public void d0() {
    if (!this.q) {
      this.q = true;
      this.r = false;
      this.s = false;
    } 
  }
  
  public final void e(boolean paramBoolean) {
    if (this.u)
      return; 
    this.u = true;
    for (WeakReference<m> weakReference : this.w) {
      m m = weakReference.get();
      if (m == null) {
        this.w.remove(weakReference);
        continue;
      } 
      m.c(this, paramBoolean);
    } 
    this.u = false;
  }
  
  public boolean f(i parami) {
    boolean bool3 = this.w.isEmpty();
    boolean bool1 = false;
    boolean bool2 = false;
    if (!bool3) {
      if (this.x != parami)
        return false; 
      d0();
      Iterator<WeakReference<m>> iterator = this.w.iterator();
      bool1 = bool2;
      while (true) {
        bool2 = bool1;
        if (iterator.hasNext()) {
          WeakReference<m> weakReference = iterator.next();
          m m = weakReference.get();
          if (m == null) {
            this.w.remove(weakReference);
            continue;
          } 
          bool2 = m.f(this, parami);
          bool1 = bool2;
          if (bool2)
            break; 
          continue;
        } 
        break;
      } 
      c0();
      bool1 = bool2;
      if (bool2) {
        this.x = null;
        bool1 = bool2;
      } 
    } 
    return bool1;
  }
  
  public MenuItem findItem(int paramInt) {
    int k = size();
    for (int j = 0; j < k; j++) {
      i i1 = this.f.get(j);
      if (i1.getItemId() == paramInt)
        return (MenuItem)i1; 
      if (i1.hasSubMenu()) {
        MenuItem menuItem = i1.getSubMenu().findItem(paramInt);
        if (menuItem != null)
          return menuItem; 
      } 
    } 
    return null;
  }
  
  public MenuItem getItem(int paramInt) {
    return (MenuItem)this.f.get(paramInt);
  }
  
  boolean h(g paramg, MenuItem paramMenuItem) {
    a a1 = this.e;
    return (a1 != null && a1.a(paramg, paramMenuItem));
  }
  
  public boolean hasVisibleItems() {
    if (this.z)
      return true; 
    int k = size();
    for (int j = 0; j < k; j++) {
      if (((i)this.f.get(j)).isVisible())
        return true; 
    } 
    return false;
  }
  
  public boolean isShortcutKey(int paramInt, KeyEvent paramKeyEvent) {
    return (p(paramInt, paramKeyEvent) != null);
  }
  
  public boolean k(i parami) {
    boolean bool2 = this.w.isEmpty();
    boolean bool1 = false;
    if (bool2)
      return false; 
    d0();
    Iterator<WeakReference<m>> iterator = this.w.iterator();
    while (true) {
      bool2 = bool1;
      if (iterator.hasNext()) {
        WeakReference<m> weakReference = iterator.next();
        m m = weakReference.get();
        if (m == null) {
          this.w.remove(weakReference);
          continue;
        } 
        bool2 = m.g(this, parami);
        bool1 = bool2;
        if (bool2)
          break; 
        continue;
      } 
      break;
    } 
    c0();
    if (bool2)
      this.x = parami; 
    return bool2;
  }
  
  public int l(int paramInt) {
    return m(paramInt, 0);
  }
  
  public int m(int paramInt1, int paramInt2) {
    int k = size();
    int j = paramInt2;
    if (paramInt2 < 0)
      j = 0; 
    while (j < k) {
      if (((i)this.f.get(j)).getGroupId() == paramInt1)
        return j; 
      j++;
    } 
    return -1;
  }
  
  public int o(int paramInt) {
    int k = size();
    for (int j = 0; j < k; j++) {
      if (((i)this.f.get(j)).getItemId() == paramInt)
        return j; 
    } 
    return -1;
  }
  
  i p(int paramInt, KeyEvent paramKeyEvent) {
    ArrayList<i> arrayList = this.v;
    arrayList.clear();
    q(arrayList, paramInt, paramKeyEvent);
    if (arrayList.isEmpty())
      return null; 
    int k = paramKeyEvent.getMetaState();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    paramKeyEvent.getKeyData(keyData);
    int m = arrayList.size();
    if (m == 1)
      return arrayList.get(0); 
    boolean bool = G();
    for (int j = 0; j < m; j++) {
      char c;
      i i1 = arrayList.get(j);
      if (bool) {
        c = i1.getAlphabeticShortcut();
      } else {
        c = i1.getNumericShortcut();
      } 
      char[] arrayOfChar = keyData.meta;
      if ((c == arrayOfChar[0] && (k & 0x2) == 0) || (c == arrayOfChar[2] && (k & 0x2) != 0) || (bool && c == '\b' && paramInt == 67))
        return i1; 
    } 
    return null;
  }
  
  public boolean performIdentifierAction(int paramInt1, int paramInt2) {
    return L(findItem(paramInt1), paramInt2);
  }
  
  public boolean performShortcut(int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    boolean bool;
    i i1 = p(paramInt1, paramKeyEvent);
    if (i1 != null) {
      bool = L((MenuItem)i1, paramInt2);
    } else {
      bool = false;
    } 
    if ((paramInt2 & 0x2) != 0)
      e(true); 
    return bool;
  }
  
  void q(List<i> paramList, int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = G();
    int k = paramKeyEvent.getModifiers();
    KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
    if (!paramKeyEvent.getKeyData(keyData) && paramInt != 67)
      return; 
    int m = this.f.size();
    int j;
    for (j = 0; j < m; j++) {
      char c;
      int n;
      i i1 = this.f.get(j);
      if (i1.hasSubMenu())
        ((g)i1.getSubMenu()).q(paramList, paramInt, paramKeyEvent); 
      if (bool) {
        c = i1.getAlphabeticShortcut();
      } else {
        c = i1.getNumericShortcut();
      } 
      if (bool) {
        n = i1.getAlphabeticModifiers();
      } else {
        n = i1.getNumericModifiers();
      } 
      if ((k & 0x1100F) == (n & 0x1100F)) {
        n = 1;
      } else {
        n = 0;
      } 
      if (n != 0 && c != '\000') {
        char[] arrayOfChar = keyData.meta;
        if ((c == arrayOfChar[0] || c == arrayOfChar[2] || (bool && c == '\b' && paramInt == 67)) && i1.isEnabled())
          paramList.add(i1); 
      } 
    } 
  }
  
  public void r() {
    ArrayList<i> arrayList = E();
    if (!this.k)
      return; 
    Iterator<WeakReference<m>> iterator = this.w.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= m.e()) {
      WeakReference<m> weakReference = iterator.next();
      m m = weakReference.get();
      if (m == null) {
        this.w.remove(weakReference);
        continue;
      } 
    } 
    if (bool) {
      this.i.clear();
      this.j.clear();
      int j = arrayList.size();
      bool = false;
      while (bool < j) {
        i i1 = arrayList.get(bool);
        if (i1.l()) {
          this.i.add(i1);
        } else {
          this.j.add(i1);
        } 
        int k = bool + 1;
      } 
    } else {
      this.i.clear();
      this.j.clear();
      this.j.addAll(E());
    } 
    this.k = false;
  }
  
  public void removeGroup(int paramInt) {
    int j = l(paramInt);
    if (j >= 0) {
      int m = this.f.size();
      for (int k = 0; k < m - j && ((i)this.f.get(j)).getGroupId() == paramInt; k++)
        N(j, false); 
      K(true);
    } 
  }
  
  public void removeItem(int paramInt) {
    N(o(paramInt), true);
  }
  
  public ArrayList<i> s() {
    r();
    return this.i;
  }
  
  public void setGroupCheckable(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    int k = this.f.size();
    int j;
    for (j = 0; j < k; j++) {
      i i1 = this.f.get(j);
      if (i1.getGroupId() == paramInt) {
        i1.t(paramBoolean2);
        i1.setCheckable(paramBoolean1);
      } 
    } 
  }
  
  public void setGroupDividerEnabled(boolean paramBoolean) {
    this.y = paramBoolean;
  }
  
  public void setGroupEnabled(int paramInt, boolean paramBoolean) {
    int k = this.f.size();
    for (int j = 0; j < k; j++) {
      i i1 = this.f.get(j);
      if (i1.getGroupId() == paramInt)
        i1.setEnabled(paramBoolean); 
    } 
  }
  
  public void setGroupVisible(int paramInt, boolean paramBoolean) {
    int k = this.f.size();
    int j = 0;
    boolean bool;
    for (bool = false; j < k; bool = bool1) {
      i i1 = this.f.get(j);
      boolean bool1 = bool;
      if (i1.getGroupId() == paramInt) {
        bool1 = bool;
        if (i1.y(paramBoolean))
          bool1 = true; 
      } 
      j++;
    } 
    if (bool)
      K(true); 
  }
  
  public void setQwertyMode(boolean paramBoolean) {
    this.c = paramBoolean;
    K(false);
  }
  
  public int size() {
    return this.f.size();
  }
  
  protected String t() {
    return "android:menu:actionviewstates";
  }
  
  public Context u() {
    return this.a;
  }
  
  public i v() {
    return this.x;
  }
  
  public Drawable w() {
    return this.o;
  }
  
  public CharSequence x() {
    return this.n;
  }
  
  public View y() {
    return this.p;
  }
  
  public ArrayList<i> z() {
    r();
    return this.j;
  }
  
  public static interface a {
    boolean a(g param1g, MenuItem param1MenuItem);
    
    void b(g param1g);
  }
  
  public static interface b {
    boolean a(i param1i);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */