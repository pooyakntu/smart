package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.widget.k2;
import androidx.core.view.e1;
import f.d;
import f.g;

final class q extends k implements PopupWindow.OnDismissListener, View.OnKeyListener {
  private static final int B = g.m;
  
  private boolean A;
  
  private final Context h;
  
  private final g i;
  
  private final f j;
  
  private final boolean k;
  
  private final int l;
  
  private final int m;
  
  private final int n;
  
  final k2 o;
  
  final ViewTreeObserver.OnGlobalLayoutListener p = new a(this);
  
  private final View.OnAttachStateChangeListener q = new b(this);
  
  private PopupWindow.OnDismissListener r;
  
  private View s;
  
  View t;
  
  private m.a u;
  
  ViewTreeObserver v;
  
  private boolean w;
  
  private boolean x;
  
  private int y;
  
  private int z = 0;
  
  public q(Context paramContext, g paramg, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.h = paramContext;
    this.i = paramg;
    this.k = paramBoolean;
    this.j = new f(paramg, LayoutInflater.from(paramContext), paramBoolean, B);
    this.m = paramInt1;
    this.n = paramInt2;
    Resources resources = paramContext.getResources();
    this.l = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(d.d));
    this.s = paramView;
    this.o = new k2(paramContext, null, paramInt1, paramInt2);
    paramg.c(this, paramContext);
  }
  
  private boolean z() {
    if (a())
      return true; 
    if (!this.w) {
      boolean bool;
      View view = this.s;
      if (view == null)
        return false; 
      this.t = view;
      this.o.K(this);
      this.o.L(this);
      this.o.J(true);
      view = this.t;
      if (this.v == null) {
        bool = true;
      } else {
        bool = false;
      } 
      ViewTreeObserver viewTreeObserver = view.getViewTreeObserver();
      this.v = viewTreeObserver;
      if (bool)
        viewTreeObserver.addOnGlobalLayoutListener(this.p); 
      view.addOnAttachStateChangeListener(this.q);
      this.o.D(view);
      this.o.G(this.z);
      if (!this.x) {
        this.y = k.o((ListAdapter)this.j, null, this.h, this.l);
        this.x = true;
      } 
      this.o.F(this.y);
      this.o.I(2);
      this.o.H(n());
      this.o.b();
      ListView listView = this.o.j();
      listView.setOnKeyListener(this);
      if (this.A && this.i.x() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.h).inflate(g.l, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.i.x()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.o.p((ListAdapter)this.j);
      this.o.b();
      return true;
    } 
    return false;
  }
  
  public boolean a() {
    return (!this.w && this.o.a());
  }
  
  public void b() {
    if (z())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void c(g paramg, boolean paramBoolean) {
    if (paramg != this.i)
      return; 
    dismiss();
    m.a a1 = this.u;
    if (a1 != null)
      a1.c(paramg, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    this.x = false;
    f f1 = this.j;
    if (f1 != null)
      f1.notifyDataSetChanged(); 
  }
  
  public void dismiss() {
    if (a())
      this.o.dismiss(); 
  }
  
  public boolean e() {
    return false;
  }
  
  public void h(m.a parama) {
    this.u = parama;
  }
  
  public ListView j() {
    return this.o.j();
  }
  
  public boolean k(r paramr) {
    if (paramr.hasVisibleItems()) {
      l l = new l(this.h, paramr, this.t, this.k, this.m, this.n);
      l.j(this.u);
      l.g(k.x(paramr));
      l.i(this.r);
      this.r = null;
      this.i.e(false);
      int j = this.o.d();
      int m = this.o.o();
      int i = j;
      if ((Gravity.getAbsoluteGravity(this.z, e1.G(this.s)) & 0x7) == 5)
        i = j + this.s.getWidth(); 
      if (l.n(i, m)) {
        m.a a1 = this.u;
        if (a1 != null)
          a1.d(paramr); 
        return true;
      } 
    } 
    return false;
  }
  
  public void l(g paramg) {}
  
  public void onDismiss() {
    this.w = true;
    this.i.close();
    ViewTreeObserver viewTreeObserver = this.v;
    if (viewTreeObserver != null) {
      if (!viewTreeObserver.isAlive())
        this.v = this.t.getViewTreeObserver(); 
      this.v.removeGlobalOnLayoutListener(this.p);
      this.v = null;
    } 
    this.t.removeOnAttachStateChangeListener(this.q);
    PopupWindow.OnDismissListener onDismissListener = this.r;
    if (onDismissListener != null)
      onDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void p(View paramView) {
    this.s = paramView;
  }
  
  public void r(boolean paramBoolean) {
    this.j.d(paramBoolean);
  }
  
  public void s(int paramInt) {
    this.z = paramInt;
  }
  
  public void t(int paramInt) {
    this.o.f(paramInt);
  }
  
  public void u(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.r = paramOnDismissListener;
  }
  
  public void v(boolean paramBoolean) {
    this.A = paramBoolean;
  }
  
  public void w(int paramInt) {
    this.o.l(paramInt);
  }
  
  class a implements ViewTreeObserver.OnGlobalLayoutListener {
    a(q this$0) {}
    
    public void onGlobalLayout() {
      if (this.g.a() && !this.g.o.B()) {
        View view = this.g.t;
        if (view == null || !view.isShown()) {
          this.g.dismiss();
          return;
        } 
        this.g.o.b();
        return;
      } 
    }
  }
  
  class b implements View.OnAttachStateChangeListener {
    b(q this$0) {}
    
    public void onViewAttachedToWindow(View param1View) {}
    
    public void onViewDetachedFromWindow(View param1View) {
      ViewTreeObserver viewTreeObserver = this.g.v;
      if (viewTreeObserver != null) {
        if (!viewTreeObserver.isAlive())
          this.g.v = param1View.getViewTreeObserver(); 
        q q1 = this.g;
        q1.v.removeGlobalOnLayoutListener(q1.p);
      } 
      param1View.removeOnAttachStateChangeListener(this);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */