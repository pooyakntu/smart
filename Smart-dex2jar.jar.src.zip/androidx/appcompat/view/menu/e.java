package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import f.g;
import java.util.ArrayList;

public class e implements m, AdapterView.OnItemClickListener {
  Context g;
  
  LayoutInflater h;
  
  g i;
  
  ExpandedMenuView j;
  
  int k;
  
  int l;
  
  int m;
  
  private m.a n;
  
  a o;
  
  public e(int paramInt1, int paramInt2) {
    this.m = paramInt1;
    this.l = paramInt2;
  }
  
  public e(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.g = paramContext;
    this.h = LayoutInflater.from(paramContext);
  }
  
  public ListAdapter a() {
    if (this.o == null)
      this.o = new a(this); 
    return (ListAdapter)this.o;
  }
  
  public n b(ViewGroup paramViewGroup) {
    if (this.j == null) {
      this.j = (ExpandedMenuView)this.h.inflate(g.g, paramViewGroup, false);
      if (this.o == null)
        this.o = new a(this); 
      this.j.setAdapter((ListAdapter)this.o);
      this.j.setOnItemClickListener(this);
    } 
    return this.j;
  }
  
  public void c(g paramg, boolean paramBoolean) {
    m.a a1 = this.n;
    if (a1 != null)
      a1.c(paramg, paramBoolean); 
  }
  
  public void d(boolean paramBoolean) {
    a a1 = this.o;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean e() {
    return false;
  }
  
  public boolean f(g paramg, i parami) {
    return false;
  }
  
  public boolean g(g paramg, i parami) {
    return false;
  }
  
  public void h(m.a parama) {
    this.n = parama;
  }
  
  public void i(Context paramContext, g paramg) {
    ContextThemeWrapper contextThemeWrapper;
    if (this.l != 0) {
      contextThemeWrapper = new ContextThemeWrapper(paramContext, this.l);
      this.g = (Context)contextThemeWrapper;
      this.h = LayoutInflater.from((Context)contextThemeWrapper);
    } else if (this.g != null) {
      this.g = (Context)contextThemeWrapper;
      if (this.h == null)
        this.h = LayoutInflater.from((Context)contextThemeWrapper); 
    } 
    this.i = paramg;
    a a1 = this.o;
    if (a1 != null)
      a1.notifyDataSetChanged(); 
  }
  
  public boolean k(r paramr) {
    if (!paramr.hasVisibleItems())
      return false; 
    (new h(paramr)).b(null);
    m.a a1 = this.n;
    if (a1 != null)
      a1.d(paramr); 
    return true;
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.i.M((MenuItem)this.o.b(paramInt), this, 0);
  }
  
  private class a extends BaseAdapter {
    private int g = -1;
    
    public a(e this$0) {
      a();
    }
    
    void a() {
      i i = this.h.i.v();
      if (i != null) {
        ArrayList<i> arrayList = this.h.i.z();
        int k = arrayList.size();
        for (int j = 0; j < k; j++) {
          if ((i)arrayList.get(j) == i) {
            this.g = j;
            return;
          } 
        } 
      } 
      this.g = -1;
    }
    
    public i b(int param1Int) {
      ArrayList<i> arrayList = this.h.i.z();
      int i = param1Int + this.h.k;
      int j = this.g;
      param1Int = i;
      if (j >= 0) {
        param1Int = i;
        if (i >= j)
          param1Int = i + 1; 
      } 
      return arrayList.get(param1Int);
    }
    
    public int getCount() {
      int i = this.h.i.z().size() - this.h.k;
      return (this.g < 0) ? i : (i - 1);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = param1View;
      if (param1View == null) {
        e e1 = this.h;
        view = e1.h.inflate(e1.m, param1ViewGroup, false);
      } 
      ((n.a)view).d(b(param1Int), 0);
      return view;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */