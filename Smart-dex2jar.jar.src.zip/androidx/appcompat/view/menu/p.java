package androidx.appcompat.view.menu;

import android.widget.ListView;

public interface p {
  boolean a();
  
  void b();
  
  void dismiss();
  
  ListView j();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */