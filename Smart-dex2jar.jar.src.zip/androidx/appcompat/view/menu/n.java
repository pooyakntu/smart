package androidx.appcompat.view.menu;

public interface n {
  void b(g paramg);
  
  public static interface a {
    boolean c();
    
    void d(i param1i, int param1Int);
    
    i getItemData();
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\menu\n.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */