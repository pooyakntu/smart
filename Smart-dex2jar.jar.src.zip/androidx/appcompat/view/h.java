package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.e3;
import androidx.core.view.f3;
import androidx.core.view.g3;
import java.util.ArrayList;
import java.util.Iterator;

public class h {
  final ArrayList<e3> a = new ArrayList<e3>();
  
  private long b = -1L;
  
  private Interpolator c;
  
  f3 d;
  
  private boolean e;
  
  private final g3 f = new a(this);
  
  public void a() {
    if (!this.e)
      return; 
    Iterator<e3> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((e3)iterator.next()).c(); 
    this.e = false;
  }
  
  void b() {
    this.e = false;
  }
  
  public h c(e3 parame3) {
    if (!this.e)
      this.a.add(parame3); 
    return this;
  }
  
  public h d(e3 parame31, e3 parame32) {
    this.a.add(parame31);
    parame32.j(parame31.d());
    this.a.add(parame32);
    return this;
  }
  
  public h e(long paramLong) {
    if (!this.e)
      this.b = paramLong; 
    return this;
  }
  
  public h f(Interpolator paramInterpolator) {
    if (!this.e)
      this.c = paramInterpolator; 
    return this;
  }
  
  public h g(f3 paramf3) {
    if (!this.e)
      this.d = paramf3; 
    return this;
  }
  
  public void h() {
    if (this.e)
      return; 
    for (e3 e3 : this.a) {
      long l = this.b;
      if (l >= 0L)
        e3.f(l); 
      Interpolator interpolator = this.c;
      if (interpolator != null)
        e3.g(interpolator); 
      if (this.d != null)
        e3.h((f3)this.f); 
      e3.l();
    } 
    this.e = true;
  }
  
  class a extends g3 {
    private boolean a = false;
    
    private int b = 0;
    
    a(h this$0) {}
    
    public void b(View param1View) {
      int i = this.b + 1;
      this.b = i;
      if (i == this.c.a.size()) {
        f3 f3 = this.c.d;
        if (f3 != null)
          f3.b(null); 
        d();
      } 
    }
    
    public void c(View param1View) {
      if (this.a)
        return; 
      this.a = true;
      f3 f3 = this.c.d;
      if (f3 != null)
        f3.c(null); 
    }
    
    void d() {
      this.b = 0;
      this.a = false;
      this.c.b();
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */