package androidx.appcompat.view;

import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SearchEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import java.util.List;

public class k implements Window.Callback {
  final Window.Callback g;
  
  public k(Window.Callback paramCallback) {
    if (paramCallback != null) {
      this.g = paramCallback;
      return;
    } 
    throw new IllegalArgumentException("Window callback may not be null");
  }
  
  public final Window.Callback a() {
    return this.g;
  }
  
  public boolean dispatchGenericMotionEvent(MotionEvent paramMotionEvent) {
    return this.g.dispatchGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return this.g.dispatchKeyEvent(paramKeyEvent);
  }
  
  public boolean dispatchKeyShortcutEvent(KeyEvent paramKeyEvent) {
    return this.g.dispatchKeyShortcutEvent(paramKeyEvent);
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return this.g.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent);
  }
  
  public boolean dispatchTouchEvent(MotionEvent paramMotionEvent) {
    return this.g.dispatchTouchEvent(paramMotionEvent);
  }
  
  public boolean dispatchTrackballEvent(MotionEvent paramMotionEvent) {
    return this.g.dispatchTrackballEvent(paramMotionEvent);
  }
  
  public void onActionModeFinished(ActionMode paramActionMode) {
    this.g.onActionModeFinished(paramActionMode);
  }
  
  public void onActionModeStarted(ActionMode paramActionMode) {
    this.g.onActionModeStarted(paramActionMode);
  }
  
  public void onAttachedToWindow() {
    this.g.onAttachedToWindow();
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu) {
    return this.g.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreatePanelView(int paramInt) {
    return this.g.onCreatePanelView(paramInt);
  }
  
  public void onDetachedFromWindow() {
    this.g.onDetachedFromWindow();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem) {
    return this.g.onMenuItemSelected(paramInt, paramMenuItem);
  }
  
  public boolean onMenuOpened(int paramInt, Menu paramMenu) {
    return this.g.onMenuOpened(paramInt, paramMenu);
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu) {
    this.g.onPanelClosed(paramInt, paramMenu);
  }
  
  public void onPointerCaptureChanged(boolean paramBoolean) {
    c.a(this.g, paramBoolean);
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu) {
    return this.g.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> paramList, Menu paramMenu, int paramInt) {
    b.a(this.g, paramList, paramMenu, paramInt);
  }
  
  public boolean onSearchRequested() {
    return this.g.onSearchRequested();
  }
  
  public boolean onSearchRequested(SearchEvent paramSearchEvent) {
    return a.a(this.g, paramSearchEvent);
  }
  
  public void onWindowAttributesChanged(WindowManager.LayoutParams paramLayoutParams) {
    this.g.onWindowAttributesChanged(paramLayoutParams);
  }
  
  public void onWindowFocusChanged(boolean paramBoolean) {
    this.g.onWindowFocusChanged(paramBoolean);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback) {
    return this.g.onWindowStartingActionMode(paramCallback);
  }
  
  public ActionMode onWindowStartingActionMode(ActionMode.Callback paramCallback, int paramInt) {
    return a.b(this.g, paramCallback, paramInt);
  }
  
  static class a {
    static boolean a(Window.Callback param1Callback, SearchEvent param1SearchEvent) {
      return i.a(param1Callback, param1SearchEvent);
    }
    
    static ActionMode b(Window.Callback param1Callback, ActionMode.Callback param1Callback1, int param1Int) {
      return j.a(param1Callback, param1Callback1, param1Int);
    }
  }
  
  static class b {
    static void a(Window.Callback param1Callback, List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      l.a(param1Callback, param1List, param1Menu, param1Int);
    }
  }
  
  static class c {
    static void a(Window.Callback param1Callback, boolean param1Boolean) {
      m.a(param1Callback, param1Boolean);
    }
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\k.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */