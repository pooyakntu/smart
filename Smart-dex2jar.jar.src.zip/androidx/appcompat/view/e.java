package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.g;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

public class e extends b implements g.a {
  private Context i;
  
  private ActionBarContextView j;
  
  private b.a k;
  
  private WeakReference<View> l;
  
  private boolean m;
  
  private boolean n;
  
  private g o;
  
  public e(Context paramContext, ActionBarContextView paramActionBarContextView, b.a parama, boolean paramBoolean) {
    this.i = paramContext;
    this.j = paramActionBarContextView;
    this.k = parama;
    g g1 = (new g(paramActionBarContextView.getContext())).S(1);
    this.o = g1;
    g1.R(this);
    this.n = paramBoolean;
  }
  
  public boolean a(g paramg, MenuItem paramMenuItem) {
    return this.k.d(this, paramMenuItem);
  }
  
  public void b(g paramg) {
    k();
    this.j.l();
  }
  
  public void c() {
    if (this.m)
      return; 
    this.m = true;
    this.k.a(this);
  }
  
  public View d() {
    WeakReference<View> weakReference = this.l;
    return (weakReference != null) ? weakReference.get() : null;
  }
  
  public Menu e() {
    return (Menu)this.o;
  }
  
  public MenuInflater f() {
    return new g(this.j.getContext());
  }
  
  public CharSequence g() {
    return this.j.getSubtitle();
  }
  
  public CharSequence i() {
    return this.j.getTitle();
  }
  
  public void k() {
    this.k.c(this, (Menu)this.o);
  }
  
  public boolean l() {
    return this.j.j();
  }
  
  public void m(View paramView) {
    this.j.setCustomView(paramView);
    if (paramView != null) {
      WeakReference<View> weakReference = new WeakReference<View>(paramView);
    } else {
      paramView = null;
    } 
    this.l = (WeakReference<View>)paramView;
  }
  
  public void n(int paramInt) {
    o(this.i.getString(paramInt));
  }
  
  public void o(CharSequence paramCharSequence) {
    this.j.setSubtitle(paramCharSequence);
  }
  
  public void q(int paramInt) {
    r(this.i.getString(paramInt));
  }
  
  public void r(CharSequence paramCharSequence) {
    this.j.setTitle(paramCharSequence);
  }
  
  public void s(boolean paramBoolean) {
    super.s(paramBoolean);
    this.j.setTitleOptional(paramBoolean);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */