package androidx.appcompat.view;

@Deprecated
public interface c {
  void onActionViewCollapsed();
  
  void onActionViewExpanded();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\appcompat\view\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */