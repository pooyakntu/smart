package androidx.concurrent.futures;

public final class c<V> extends a<V> {
  public static <V> c<V> q() {
    return new c<V>();
  }
  
  public boolean o(V paramV) {
    return super.o(paramV);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\androidx\concurrent\futures\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */