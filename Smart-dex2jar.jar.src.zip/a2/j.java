package a2;

import com.google.auto.value.AutoValue;
import java.util.List;
import u3.a;
import w3.d;

@AutoValue
public abstract class j {
  public static j a(List<m> paramList) {
    return new d(paramList);
  }
  
  public static a b() {
    return (new d()).j(b.a).k(true).i();
  }
  
  public abstract List<m> c();
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a2\j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */