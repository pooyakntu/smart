package a2;

import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.Builder;

@AutoValue
public abstract class a {
  public static a a() {
    return new c.b();
  }
  
  public abstract String b();
  
  public abstract String c();
  
  public abstract String d();
  
  public abstract String e();
  
  public abstract String f();
  
  public abstract String g();
  
  public abstract String h();
  
  public abstract String i();
  
  public abstract String j();
  
  public abstract String k();
  
  public abstract String l();
  
  public abstract Integer m();
  
  @Builder
  public static abstract class a {
    public abstract a a();
    
    public abstract a b(String param1String);
    
    public abstract a c(String param1String);
    
    public abstract a d(String param1String);
    
    public abstract a e(String param1String);
    
    public abstract a f(String param1String);
    
    public abstract a g(String param1String);
    
    public abstract a h(String param1String);
    
    public abstract a i(String param1String);
    
    public abstract a j(String param1String);
    
    public abstract a k(String param1String);
    
    public abstract a l(String param1String);
    
    public abstract a m(Integer param1Integer);
  }
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a2\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */