package a4;

import com.google.android.gms.common.annotation.KeepForSdk;
import com.google.android.gms.tasks.Task;

@KeepForSdk
public interface a {
  @KeepForSdk
  Task<String> a();
  
  @KeepForSdk
  void b(a parama);
  
  @KeepForSdk
  String c();
  
  @KeepForSdk
  public static interface a {}
}


/* Location:              C:\Users\Pooya\Desktop\smartpek\Smart-dex2jar.jar!\a4\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */